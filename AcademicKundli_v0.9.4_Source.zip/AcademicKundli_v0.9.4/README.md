# AcademicKundli v0.9.4 — Android source

**Developed by Aryan Gaur**

An incremental update to the existing SIM+ Campus v0.9.3 Android project. It retains the previous Gradle package/application ID (`com.campus.simplus`), the SIM/AKTU integration, legacy data keys, attendance forecasts, result scanning, encrypted Excel roster and PDF export. Do **not** change the application ID unless you want a fresh installation with no automatic upgrade path.

## Changes

- **Branding:** AcademicKundli title, in-app header, onboarding splash, native collection splash, About page, footer, Android label and notification-friendly icons. SVG master and PNG favicons/launcher images use indigo and gold with a cap, 12-house Kundli and star.
- **Starred Students:** Star/unstar control on each profile. Saved snapshots are scoped under the primary user's ID and stored in the Android WebView's private local storage, with Last updated and separate attendance/result availability. Opening a starred student is **offline only**, with no automatic network request. Tapping Refresh is the only way to re-fetch a starred snapshot. Unstar requires confirmation and removes starred data; secondary student's scoped cache is also removed. Primary academic records themselves are intentionally retained (unstar is not full account deletion).
- **First-time capture:** Starring the primary user starts one collection attempt through the existing official ERP workflow when semester start is known; it may ask for CAPTCHA. Existing locally fetched data is captured immediately, and the snapshot is refreshed on successful completion. Failed/unavailable official data remains clearly marked unavailable and is not synthesized. Starring a different student saves existing locally authorized data only — **another student's ERP cannot be fetched using the primary user's session**.
- **Primary user:** Bound to the student roll/student key selected for first official login/collection, and persisted locally across activity recreation. Viewing other roster rows uses read-only previews without changing the ERP session, cookies or the roster's selected identity. A banner offers Back to my profile. Settings, portal sync, PDF export, results capture, edits and other ERP actions are disabled in preview mode both in JavaScript and the native bridge. Log out to remove the primary binding and clear the ERP session cookies, then select another ID and sign in again.

## Build

Prerequisites: JDK 17, Android SDK Platform 35, Build Tools 35.0.0, Gradle 8.10.2.

```bash
# From the repository root
gradle --no-daemon :app:assembleDebug
# output: app/build/outputs/apk/debug/app-debug.apk
```

Or run `.github/workflows/build-android.yml` on GitHub Actions. It installs SDK 35, checks JavaScript and runs the regression suite before assembling an APK. The archive contains **source**, not a precompiled APK.

## Checks

```bash
for f in app/src/main/assets/*.js; do node --check "$f"; done
for f in tests/*.js; do node "$f"; done
```

The regression suite includes the primary ID lock, one-time star collection, offline open, read-only native-call restrictions, and unstar behavior. A real Android device and real authenticated official portals are still needed to verify actual attendance/results ingestion and splash/launcher behavior after compiling.

## Privacy and limitations

- This is **not** an official college or AKTU app. Official source pages are authoritative.
- No CAPTCHA bypass, guessed data or other-student login reuse. The official login/verification screen is used when required.
- Read-only preview can display locally stored roster information or already authorized snapshots, but cannot retrieve private ERP records for a different user without that user's own authentication in a new primary session.
- Starred snapshots are stored on-device in app-private WebView localStorage (not on a server). WebView localStorage is not encrypted separately; avoid sharing an unlocked phone/app backup. The Excel roster uses the existing encrypted native storage.
- Existing `simplus:` storage namespaces are retained intentionally for backward compatibility. `academickundli:` namespaces are used for new starred data.
