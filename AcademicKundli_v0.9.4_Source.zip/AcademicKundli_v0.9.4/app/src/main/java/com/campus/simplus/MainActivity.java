package com.campus.simplus;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ProgressBar;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;

import org.json.JSONTokener;
import org.json.JSONObject;
import org.json.JSONArray;
import android.webkit.WebResourceError;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


/**
 * Unofficial student companion. ERP auth stays in an ordinary, first-party WebView.
 * The JavaScript bridge exists ONLY on the bundled, local app UI, never on ERP pages.
 * No passwords, cookie values, CAPTCHA responses or hidden login endpoints are read.
 */
public class MainActivity extends Activity {
    private static final String LOGIN = "https://glbg.servergi.com:8072/ISIMGLB/Login";
    private static final String ERP = "https://glbg.servergi.com:8072/ISIMGLB/home";
    private static final String TODAY = "https://glbg.servergi.com:8072/ISIMGLB/Student/TodayAttendence";
    private static final String STUDENT_OFFICIAL="https://glbg.servergi.com:8072/ISIMGLB/Student/StudentOfficial";
    private boolean importExtend=false;
    private boolean collecting=false;
    private String collectionStage="idle";
    private int collectionSerial=0;
    private int aktuNavigationSerial=0;
    private boolean aktuMainFrameLoaded=false;
    private android.widget.ProgressBar browserProgress;
    private String collectionAttendanceDate="";
    private String pendingFrom = null, pendingTo = null;
    // A protected college route is never requested until the official Login
    // screen has produced a verified authenticated college page.
    private String afterCollegeLogin = null;
    private String mostRecentCollegeRoute = ERP;
    private boolean collegeSessionReady = false;
    private int authenticationGeneration = 0;
    private final Handler main = new Handler(Looper.getMainLooper());
    private WebView appView, erpView;
    private AcademicFeatures academics;
    private LinearLayout browserContainer;
    private TextView browserTitle;
    private FrameLayout collectionCover;
    private Button browserBackButton,browserStopButton,browserCaptureButton;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 309;
    private static final int ROSTER_REQUEST = 310;
    private StudentRosterStore rosterStore;
    // Primary user is bound to the ID selected for the official ERP sign-in.
    // Viewer selection NEVER changes this identity or its authenticated cookies.
    private String primaryKey="";
    private boolean viewOnly=false;
    private String keyOf(JSONObject student){
        if(student==null)return "";
        String key=student.optString("studentKey", "").trim();
        if(!key.isEmpty())return key;
        String roll=student.optString("roll", "").trim().toLowerCase(Locale.ROOT);
        return roll.isEmpty()?"": "roll:"+roll;
    }
    private boolean primaryAuthorized(){
        return !viewOnly && !primaryKey.isEmpty() && primaryKey.equals(keyOf(rosterStore.selected()));
    }
    private void bindPrimary(){
        if(!primaryKey.isEmpty())return;
        String key=keyOf(rosterStore.selected());
        if(key.isEmpty()){message("Select your own student ID before signing in");return;}
        primaryKey=key;
        getSharedPreferences("academickundli-session",0).edit().putString("primaryKey",key).apply();
        sendRoster("onRosterSelected");
    }
    private void previewRoster(int index){
        if(primaryKey.isEmpty()){chooseRosterStudent(index);return;}
        if(collecting||autoActive){message("Finish current academic collection before switching views");return;}
        JSONObject person=rosterStore.at(index);
        if(person==null){message("Student not found in roster");return;}
        if(primaryKey.equals(keyOf(person))){endRosterPreview();return;}
        viewOnly=true;
        if(academics!=null)academics.stopScan("Read-only student preview");
        // Keep the original ERP login and cookies intact.
        appView.evaluateJavascript("window.onPreviewStudent("+person.toString()+");",null);
    }
    private void endRosterPreview(){
        viewOnly=false;
        sendRoster("onRosterSelected");
    }
    private void logoutPrimary(){
        if(viewOnly){message("Back to your profile before logging out");return;}
        if(autoActive)stopAuto("Signed out");
        collecting=false;collegeSessionReady=false;afterCollegeLogin=null;
        primaryKey="";authenticationGeneration++;
        if(academics!=null){academics.stopScan("Signed out");academics.setSimTemporaryPassword("");}
        getSharedPreferences("academickundli-session",0).edit().remove("primaryKey").apply();
        CookieManager.getInstance().removeAllCookies(removed -> {
            CookieManager.getInstance().flush();
            erpView.loadUrl("about:blank");
            browserContainer.setVisibility(View.GONE);
            appView.evaluateJavascript("window.onLoggedOut();",null);
        });
    }
    private final ArrayList<String[]> autoWindows = new ArrayList<>();
    private boolean autoActive = false, autoBusy = false, awaitingLoginNotice = false;
    private String autoStage = "ensure";
    private int autoIndex = 0, autoAttempts = 0, autoScheduleToken = 0;
    private String automationScript;
    private static final int MAX_READ_ATTEMPTS = 14;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        rosterStore = new StudentRosterStore(this);
        primaryKey=getSharedPreferences("academickundli-session",0).getString("primaryKey","");
        if(!primaryKey.isEmpty()&&!primaryKey.equals(keyOf(rosterStore.selected()))){
            // The roster may have been replaced outside an active session.
            primaryKey="";getSharedPreferences("academickundli-session",0).edit().remove("primaryKey").apply();
        }
        getWindow().setStatusBarColor(Color.rgb(11, 19, 39));
        getWindow().setNavigationBarColor(Color.rgb(11, 19, 39));

        FrameLayout root = new FrameLayout(this);
        appView = new WebView(this);
        setupWebView(appView);
        // Local JS interface cannot be reached by the college ERP.
        appView.addJavascriptInterface(new UiBridge(), "Native");
        appView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if(url != null && url.startsWith("file:///android_asset/")) {
                    sendRoster("onRosterLoaded");
                }
                super.onPageFinished(view,url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equalsIgnoreCase(u.getScheme())) return false;
                if ("https".equalsIgnoreCase(u.getScheme())) {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                }
                return true;
            }
        });
        root.addView(appView, new FrameLayout.LayoutParams(-1, -1));

        browserContainer = new LinearLayout(this);
        browserContainer.setOrientation(LinearLayout.VERTICAL);
        browserContainer.setBackgroundColor(Color.WHITE);
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(12), dp(9), dp(12), dp(9));
        toolbar.setBackgroundColor(Color.rgb(11, 19, 39));
        Button back = new Button(this);
        back.setText("← App");
        back.setAllCaps(false);
        back.setOnClickListener(v -> showApp());
        toolbar.addView(back, new LinearLayout.LayoutParams(dp(90), dp(48)));
        browserBackButton=back;
        browserProgress=new android.widget.ProgressBar(this);
        browserProgress.setIndeterminate(true);
        browserProgress.setVisibility(View.GONE);
        toolbar.addView(browserProgress,new LinearLayout.LayoutParams(dp(24),dp(48)));
        browserTitle = new TextView(this);
        browserTitle.setText("Official SIM ERP");
        browserTitle.setTextColor(Color.WHITE);
        browserTitle.setTextSize(15);
        browserTitle.setPadding(dp(7), dp(13), dp(0), 0);
        toolbar.addView(browserTitle, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button cancelSync = new Button(this);
        cancelSync.setText("Stop");
        cancelSync.setAllCaps(false);
        cancelSync.setOnClickListener(v -> {
            if(collecting && "aktu".equals(collectionStage)){
                skipAktuAndOpenDashboard("AKTU verification skipped. You can retry One View from Results.");
            }else{
                cancelFullCollection();
                stopAuto("Sync stopped; saved records kept.");
                if(academics!=null)academics.stopScan("Exam scan stopped; previously captured results retained.");
            }
        });
        toolbar.addView(cancelSync, new LinearLayout.LayoutParams(dp(65), dp(48)));
        browserStopButton=cancelSync;
        Button capture = new Button(this);
        capture.setText("Capture");
        capture.setAllCaps(false);
        capture.setOnClickListener(v -> { if(academics!=null && academics.canCapture())academics.captureCurrent(); else captureErp(); });
        toolbar.addView(capture, new LinearLayout.LayoutParams(dp(100), dp(48)));
        browserCaptureButton=capture;
        browserContainer.addView(toolbar);

        erpView = new WebView(this);
        setupWebView(erpView);
        erpView.getSettings().setAllowFileAccess(false);
        erpView.getSettings().setSupportMultipleWindows(false);
        erpView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        erpView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_REQUEST);
                    return true;
                } catch (Exception ex) {
                    fileCallback = null;
                    return false;
                }
            }
        });
        erpView.setDownloadListener((url, agent, disposition, mimetype, length) -> {
            try {
                // Browser handles sensitive payment/download flows: no cookie copying.
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                Toast.makeText(this, "Opening ERP download in browser", Toast.LENGTH_SHORT).show();
            } catch (Exception ex) { Toast.makeText(this, "Unable to open download", Toast.LENGTH_LONG).show(); }
        });
        erpView.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, android.graphics.Bitmap icon) {
                Uri uri = Uri.parse(url);
                if(collecting)collectionPresentation(false);
                if(collecting && "aktu".equals(collectionStage) && AcademicFeatures.isAktu(uri)){
                    aktuMainFrameLoaded=false;
                    final int nav=++aktuNavigationSerial, collectionId=collectionSerial;
                    // Do not time out an already loaded CAPTCHA page while a human solves it.
                    main.postDelayed(()->{
                        if(collecting && collectionId==collectionSerial && nav==aktuNavigationSerial
                                && "aktu".equals(collectionStage) && !aktuMainFrameLoaded){
                            skipAktuAndOpenDashboard("AKTU One View did not load. Saved SIM details are available; retry from Results.");
                        }
                    },35000);
                }
                if(academics!=null&&AcademicFeatures.isCollege(uri))academics.onCollegePageStarted(url);
                if (isProtectedCollegePath(uri)) mostRecentCollegeRoute = url;
                if (isLoginPath(uri) && collegeSessionReady) {
                    collegeSessionReady = false;
                    if (afterCollegeLogin == null) afterCollegeLogin = autoActive ? TODAY : mostRecentCollegeRoute;
                    if (academics != null) academics.onLoginRequired();
                }
                super.onPageStarted(view,url,icon);
            }
            @Override public void onPageFinished(WebView view, String url) {
                if(collecting)browserTitle.setText("Collecting: "+collectionStage.replace('-', ' '));
                else browserTitle.setText(url.contains("ExamResult") ? "College exam results" : (url.contains("Course") ? "Academic profile" : (url.contains("aktu.ac.in") ? "AKTU One View" : (url.contains("TodayAttendence") ? "Today\u0027s Attendance" : "Official SIM ERP"))));
                Uri uri = Uri.parse(url);
                if (AcademicFeatures.isCollege(uri)) {
                    if (academics != null) academics.onPageFinished(url);
                    verifyCollegeAuthentication(url);
                } else if (AcademicFeatures.isAktu(uri) && academics != null) {
                    aktuMainFrameLoaded=true;
                    academics.onPageFinished(url);
                    // Some IIS servers serve an HTML error page while onPageFinished
                    // still fires. Never expose a 503 page as a CAPTCHA challenge.
                    if(collecting && "aktu".equals(collectionStage)){
                        final int serial=collectionSerial;
                        view.evaluateJavascript("(function(){var t=((document.title||'')+' '+(document.body?.innerText||'').slice(0,700));return /service\\s+unavailable|http\\s+error\\s+50[0234]/i.test(t);})()", raw->{
                            if(!collecting||serial!=collectionSerial||!"aktu".equals(collectionStage))return;
                            if("true".equals(raw))skipAktuAndOpenDashboard("AKTU One View is temporarily unavailable. Saved SIM data remain accessible; retry from Results.");
                            else collectionPresentation(true);
                        });
                    }
                }
                if(collecting&&isLoginPath(uri))collectionPresentation(true);
                super.onPageFinished(view, url);
            }
            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, android.webkit.WebResourceResponse response){
                if(request.isForMainFrame() && AcademicFeatures.isAktu(request.getUrl()) && response.getStatusCode()>=500){
                    handleAktuUnavailable("HTTP " + response.getStatusCode());
                }
                super.onReceivedHttpError(view,request,response);
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if(request.isForMainFrame() && AcademicFeatures.isAktu(request.getUrl())){
                    handleAktuUnavailable("network error");
                }
                if (request.isForMainFrame() && AcademicFeatures.isCollege(request.getUrl())) {
                    collegeSessionReady = false;
                }
                if (autoActive && request.isForMainFrame()) {
                    stopAuto("ERP page could not load. Check network or campus-server availability.");
                }
                super.onReceivedError(view,request,error);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri target = request.getUrl();
                String scheme = target.getScheme();
                // Keep only the official college host in the authenticated WebView.
                // External sites (including payment gateways) open in the device browser.
                if (AcademicFeatures.isCollege(target) || AcademicFeatures.isAktu(target)) return false;
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, target)); }
                    catch (Exception ignored) { }
                    return true;
                }
                if ("intent".equalsIgnoreCase(scheme)) return true;
                try { startActivity(new Intent(Intent.ACTION_VIEW, request.getUrl())); }
                catch (Exception ignored) { }
                return true;
            }
        });
        browserContainer.addView(erpView, new LinearLayout.LayoutParams(-1, 0, 1));
        browserContainer.setVisibility(View.GONE);
        root.addView(browserContainer, new FrameLayout.LayoutParams(-1, -1));
        // Keep the real portal WebView visible and alive underneath a neutral
        // loading cover. Making it GONE would stop AKTU's result observer.
        makeCollectionCover(root);
        academics=new AcademicFeatures(this,erpView,appView,() -> browserContainer.setVisibility(View.VISIBLE),this::showApp,this::navigateCollege);
        if(rosterStore.selected()!=null)academics.useImportedStudent(rosterStore.selected());
        setContentView(root);
        appView.loadUrl("file:///android_asset/index.html");
    }

    private static GradientDrawable rounded(int color,int radius){
        GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(radius);return b;
    }
    private void makeCollectionCover(FrameLayout root){
        collectionCover=new FrameLayout(this);
        collectionCover.setBackgroundColor(Color.rgb(245,243,240));
        LinearLayout stack=new LinearLayout(this);
        stack.setGravity(Gravity.CENTER_HORIZONTAL);
        stack.setOrientation(LinearLayout.VERTICAL);
        stack.setPadding(dp(20),dp(32),dp(20),dp(32));
        android.widget.ImageView logo=new android.widget.ImageView(this);
        logo.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        try(java.io.InputStream input=getAssets().open("app-icon.png")){
            logo.setImageBitmap(android.graphics.BitmapFactory.decodeStream(input));
        }catch(Exception ignored){}
        stack.addView(logo,new LinearLayout.LayoutParams(dp(80),dp(80)));
        TextView brand=new TextView(this);brand.setText("AcademicKundli");brand.setGravity(Gravity.CENTER);
        brand.setTextSize(23);brand.setTypeface(null,android.graphics.Typeface.BOLD);brand.setTextColor(Color.rgb(35,32,53));
        LinearLayout.LayoutParams title=new LinearLayout.LayoutParams(-1,dp(55));title.topMargin=dp(20);stack.addView(brand,title);
        ProgressBar progress=new ProgressBar(this);
        progress.setIndeterminate(true);
        progress.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(Color.rgb(82,68,233)));
        LinearLayout.LayoutParams spin=new LinearLayout.LayoutParams(dp(48),dp(48));spin.topMargin=dp(8);spin.bottomMargin=dp(22);stack.addView(progress,spin);
        TextView headline=new TextView(this);headline.setText("Preparing your campus");headline.setTextSize(19);
        headline.setGravity(Gravity.CENTER);headline.setTypeface(null,android.graphics.Typeface.BOLD);headline.setTextColor(Color.rgb(40,36,66));
        stack.addView(headline,new LinearLayout.LayoutParams(-1,dp(38)));
        TextView detail=new TextView(this);detail.setText("Collecting available records from the official portals.\nWe'll ask you to complete verification when needed.");
        detail.setTextSize(13);detail.setLineSpacing(dp(4),1);detail.setTextColor(Color.rgb(115,111,131));detail.setGravity(Gravity.CENTER);
        stack.addView(detail,new LinearLayout.LayoutParams(-1,-2));
        TextView credit=new TextView(this);credit.setText("Developed by Aryan Gaur");
        credit.setGravity(Gravity.CENTER);credit.setTextColor(Color.rgb(94,73,31));
        credit.setTextSize(12);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(30));
        cp.topMargin=dp(14);stack.addView(credit,cp);
        Button cancel=new Button(this);cancel.setText("Cancel connection");cancel.setAllCaps(false);
        cancel.setTextColor(Color.rgb(82,68,233));cancel.setBackground(rounded(Color.rgb(237,233,255),dp(14)));
        cancel.setOnClickListener(v->cancelFullCollection());
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(49));cp.topMargin=dp(28);stack.addView(cancel,cp);
        FrameLayout.LayoutParams container=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        container.leftMargin=dp(24);container.rightMargin=dp(24);
        collectionCover.addView(stack,container);
        collectionCover.setVisibility(View.GONE);
        root.addView(collectionCover,new FrameLayout.LayoutParams(-1,-1));
    }
    /** During collection, reveal the first-party page only for verification.
     * Both portal scripts and live DOM observers keep running underneath the cover. */
    private void collectionPresentation(boolean verification){
        if(!collecting)return;
        browserContainer.setVisibility(View.VISIBLE);
        if(collectionCover!=null)collectionCover.setVisibility(verification?View.GONE:View.VISIBLE);
        if(browserCaptureButton!=null)browserCaptureButton.setVisibility(View.GONE);
        if(browserBackButton!=null)browserBackButton.setVisibility(View.GONE);
        if(browserStopButton!=null){browserStopButton.setText("aktu".equals(collectionStage)?"Skip AKTU":"Cancel");browserStopButton.setVisibility(verification?View.VISIBLE:View.GONE);}
        if(browserTitle!=null&&verification)browserTitle.setText("Official verification · Complete and submit");
    }
    private void resetBrowserControls(){
        if(collectionCover!=null)collectionCover.setVisibility(View.GONE);
        if(browserCaptureButton!=null)browserCaptureButton.setVisibility(View.VISIBLE);
        if(browserBackButton!=null)browserBackButton.setVisibility(View.VISIBLE);
        if(browserStopButton!=null){browserStopButton.setText("Stop");browserStopButton.setVisibility(View.VISIBLE);}
    }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + .5f); }
    private void setupWebView(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        w.setBackgroundColor(Color.rgb(248, 250, 252));
        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);
    }
    /** First-party secure login; user solves the official CAPTCHA manually. */
    private void navigateCollege(String destination) {
        if(viewOnly){message("Read-only viewer cannot open ERP");return;}
        Uri uri = Uri.parse(destination);
        if (!AcademicFeatures.isCollege(uri)
                || !uri.getPath().startsWith("/ISIMGLB/")) {
            message("Only the official college SIM portal is allowed");
            return;
        }
        browserContainer.setVisibility(View.VISIBLE);
        if (!collegeSessionReady) {
            afterCollegeLogin = destination;
            browserTitle.setText("Sign in to SIM ERP · CAPTCHA required");
            String current = erpView.getUrl();
            if (current == null || !isLoginPath(Uri.parse(current))) {
                erpView.loadUrl(LOGIN);
            }
            return;
        }
        mostRecentCollegeRoute = destination;
        if (!destination.equals(erpView.getUrl())) erpView.loadUrl(destination);
        else verifyCollegeAuthentication(destination);
    }
    private static boolean isLoginPath(Uri uri) {
        return AcademicFeatures.isCollege(uri) && "/ISIMGLB/Login".equalsIgnoreCase(uri.getPath());
    }
    private static boolean isProtectedCollegePath(Uri uri) {
        return AcademicFeatures.isCollege(uri) && uri.getPath() != null
                && (uri.getPath().equalsIgnoreCase("/ISIMGLB/home")
                || uri.getPath().startsWith("/ISIMGLB/Student/"));
    }
    /** Confirmation comes from the rendered first-party page, not cookie guesses. */
    private void verifyCollegeAuthentication(String loadedUrl) {
        Uri uri = Uri.parse(loadedUrl);
        if (!AcademicFeatures.isCollege(uri)) return;
        final int generation = ++authenticationGeneration;
        // Do not read passwords, CAPTCHA responses, cookies, hidden fields or tokens.
        String probe = "(function(){const pw=!!document.querySelector('input[type=password]');"
                + "const body=(document.body?.innerText||'').slice(0,12000);"
                + "const loading=/web page not available|ERR_CONNECTION|HTTP ERROR|access denied/i.test(body);"
                + "const meaningful=body.trim().length>25 && /student|attendance|semester|dashboard|course|result/i.test(body);"
                + "return JSON.stringify({login:pw,ready:!pw&&!loading&&meaningful});})()";
        erpView.evaluateJavascript(probe, raw -> {
            if (generation != authenticationGeneration || !loadedUrl.equals(erpView.getUrl())) return;
            try {
                JSONObject result = new JSONObject((String) new JSONTokener(raw).nextValue());
                if (isLoginPath(uri) || result.optBoolean("login")) {
                    collegeSessionReady = false;
                    if (afterCollegeLogin == null && autoActive) afterCollegeLogin = TODAY;
                    if (academics != null) academics.onLoginRequired();
                    browserTitle.setText("SIM ERP Login · Enter CAPTCHA");
                    if(collecting)collectionPresentation(true);
                    if (autoActive) notifyApp("Sign in on the official Login page to resume sync",false);
                    if (!isLoginPath(uri)) {
                        // Some ERP configurations render the sign-in form within
                        // the requested protected route. Canonicalize to /Login.
                        if (afterCollegeLogin == null) afterCollegeLogin = loadedUrl;
                        erpView.loadUrl(LOGIN);
                    }
                    return;
                }
                if (!isProtectedCollegePath(uri) || !result.optBoolean("ready")) {
                    collegeSessionReady = false;
                    browserTitle.setText("ERP page not verified · check login");
                    return;
                }
                collegeSessionReady = true;
                if(collecting)collectionPresentation(false);
                mostRecentCollegeRoute = loadedUrl;
                String queued = afterCollegeLogin;
                afterCollegeLogin = null;
                if (queued != null && !queued.equals(loadedUrl)) {
                    navigateCollege(queued);
                    return;
                }
                if (academics != null) {
                    academics.onCollegeAuthenticated(loadedUrl);
                    academics.onPageFinished(loadedUrl);
                }
                if (!autoActive && pendingFrom != null && loadedUrl.toLowerCase(Locale.ROOT).contains("attend")) {
                    prefillDates(pendingFrom,pendingTo);
                }
                if (autoActive) scheduleAuto(900);
                if (collecting&&"course".equals(collectionStage)&&loadedUrl.toLowerCase(Locale.ROOT).contains("/course")) {
                    collectionStage="course-reading";
                    int serial=collectionSerial;
                    // AcademicFeatures auto-reads Course on page finished; preserve
                    // that WebView long enough for the authenticated capture.
                    main.postDelayed(()->{
                        if(collecting&&serial==collectionSerial&&"course-reading".equals(collectionStage))
                            startOfficialCollection();
                    },1950);
                }
                if (collecting&&"official".equals(collectionStage)&&loadedUrl.toLowerCase(Locale.ROOT).contains("studentofficial")) {
                    collectionStage="official-reading";
                    int serial=collectionSerial;
                    main.postDelayed(()->{
                        if(!collecting||collectionSerial!=serial||!"official-reading".equals(collectionStage))return;
                        academics.captureOfficialSection(success->{
                            if(!collecting||collectionSerial!=serial)return;
                            setCollectionProgress("official",success?"Section captured from StudentOfficial":"Section not published or unavailable; continuing",false);
                            startCollegeCollection();
                        });
                    },850);
                }
            } catch(Exception ignored) {
                collegeSessionReady = false;
                browserTitle.setText("Could not verify ERP login");
            }
        });
    }
    private void showToday() { navigateCollege(TODAY); }
    /** Fill only visible attendance date fields; do not submit forms or bypass CAPTCHA. */
    private void prefillDates(String from, String to) {
        if (from == null || to == null || !from.matches("\\d{4}-\\d{2}-\\d{2}") || !to.matches("\\d{4}-\\d{2}-\\d{2}")) return;
        String js = "(function(){const fields=[...document.querySelectorAll('input')].filter(e=>{if(e.disabled||e.type==='hidden')return false;const s=(e.name+' '+e.id+' '+(e.placeholder||'')).toLowerCase();return /date|from|to|start|end/.test(s)||e.type==='date'});" +
                "const from=fields.find(e=>/from|start/i.test(e.name+' '+e.id+' '+e.placeholder));" +
                "const to=fields.find(e=>/to|end/i.test(e.name+' '+e.id+' '+e.placeholder)&&e!==from);" +
                "if(!from||!to)return 'Dates must be entered in ERP manually';" +
                "function set(el,iso){const [y,m,d]=iso.split('-');const v=el.type==='date'?iso:(d+'/'+m+'/'+y);el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}" +
                "set(from,'"+from+"');set(to,'"+to+"');return 'Dates prefilled; generate the report, then tap Capture';})()";
        erpView.evaluateJavascript(js, response -> {
            if (response != null && !response.equals("null")) {
                try { message(new JSONTokener(response).nextValue().toString()); } catch (Exception ignored) { }
            }
        });
        pendingFrom = null; pendingTo = null;
    }
    private void showErp() { navigateCollege(ERP); }
    private void showApp() {
        if(collecting){collectionPresentation(false);return;}
        browserContainer.setVisibility(View.GONE);
        resetBrowserControls();
    }
    private void message(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    // Capture visible HTML table text only from the currently displayed, logged-in page.
    // ERP cookies/passwords are never collected. This may require per-ERP field mapping.
    private void captureErp() {
        Uri current = Uri.parse(erpView.getUrl() == null ? "" : erpView.getUrl());
        if (!"https".equalsIgnoreCase(current.getScheme())
                || !"glbg.servergi.com".equalsIgnoreCase(current.getHost())
                || current.getPort() != 8072) {
            message("Capture is only available on the official ERP site");
            return;
        }
        if (current.getPath() == null || !current.getPath().toLowerCase(java.util.Locale.ROOT).contains("attend")) {
            message("Open an attendance report before capturing");
            return;
        }
        String script = "(function(){" +
                "var tables=[...document.querySelectorAll('table')].slice(0,80).map(t=>[...t.querySelectorAll('tr')].slice(0,700).map(r=>[...r.querySelectorAll('th,td')].map(c=>(c.innerText||'').trim().slice(0,800))));" +
                "const now=new Date(),pageDate=[now.getFullYear(),String(now.getMonth()+1).padStart(2,'0'),String(now.getDate()).padStart(2,'0')].join('-');" +
                "return JSON.stringify({title:document.title||'',url:location.pathname,tables:tables,pageDate:pageDate,capturedAt:now.toISOString()});" +
                "})()";
        erpView.evaluateJavascript(script, raw -> {
            if (raw == null || "null".equals(raw)) { message("Page isn't ready"); return; }
            try {
                String decoded = (String) new JSONTokener(raw).nextValue();
                if (decoded == null || decoded.length() < 4) { message("No visible data"); return; }
                // JSONObject.quote ensures captured text cannot execute as injected script.
                appView.evaluateJavascript("window.receiveErpSnapshot(" + JSONObject.quote(decoded) + ");", null);
                showApp();
            } catch (Exception ex) { message("Cannot read this ERP page"); }
        });
    }

    private void sendRoster(String callback){
        try {
            JSONObject snap=rosterStore.snapshot();
            snap.put("primaryKey",primaryKey);
            String safe = snap.toString();
            appView.evaluateJavascript("window." + callback + "(" + safe + ");", null);
        }catch(Exception ex){message("Student roster cannot be displayed");}
    }
    private void collectionProgress(String stage,String message,boolean done){
        collectionStage=stage;
        if(collecting)collectionPresentation(false);
        if(browserProgress!=null)browserProgress.setVisibility(collecting&&!done?View.VISIBLE:View.GONE);
        if(browserTitle!=null&&collecting)browserTitle.setText(message.length()>48?message.substring(0,48)+"…":message);
        try{
            JSONObject update=new JSONObject().put("stage",stage).put("message",message)
                .put("done",done).put("active",collecting);
            appView.evaluateJavascript("window.onCollectionProgress("+update.toString()+");",null);
        }catch(Exception ignored){}
    }
    private void setCollectionProgress(String stage,String message,boolean done){collectionProgress(stage,message,done);}
    /** Fetch a single selected, authorized student's data in the existing
     * authenticated WebView, stopping for official human CAPTCHA challenges. */
    private void startFullCollection(String startDate,String optionalPassword){
        JSONObject student=rosterStore.selected();
        if(student==null){message("Select a student first");return;}
        if(viewOnly){message("Read-only student viewer cannot fetch records");return;}
        if(!primaryKey.isEmpty()&&!primaryAuthorized()){message("Sign out before changing the primary user");return;}
        if(collecting){message("A collection is already running");return;}
        try{
            SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);df.setLenient(false);
            Date chosen=df.parse(startDate);if(chosen==null||chosen.after(new Date()))throw new Exception("Invalid date");
        }catch(Exception e){message("Choose a valid semester start date");return;}
        bindPrimary();
        if(!primaryAuthorized())return;
        collecting=true;collectionSerial++;
        collectionPresentation(false);
        collectionAttendanceDate=startDate;collectionStage="attendance";
        if(academics!=null)academics.setSimTemporaryPassword(optionalPassword);
        collectionProgress("attendance","Attendance: sign in to SIM and solve CAPTCHA if asked",false);
        SimpleDateFormat df=new SimpleDateFormat("yyyy-MM-dd",Locale.US);
        startAutomaticSync(startDate,df.format(new Date()));
        if(!autoActive){cancelFullCollection();message("Attendance automation could not start");}
    }
    private void startCourseCollection(){
        if(!collecting)return;
        collectionProgress("course","Reading authenticated SIM Course details…",false);
        navigateCollege("https://glbg.servergi.com:8072/ISIMGLB/Student/Course");
    }
    private void startOfficialCollection(){
        if(!collecting)return;
        collectionProgress("official","Reading student Section from StudentOfficial…",false);
        navigateCollege(STUDENT_OFFICIAL);
    }
    private void startCollegeCollection(){
        if(!collecting)return;
        collectionProgress("college-results","Capturing every published SIM semester…",false);
        academics.setScanCompletion(reason->{
            if(!collecting||!"college-results".equals(collectionStage))return;
            collectionProgress("college-results",reason,false);
            startAktuCollection();
        });
        academics.scanCollegeResults();
    }
    private void startAktuCollection(){
        if(!collecting)return;
        aktuMainFrameLoaded=false;
        JSONObject student=rosterStore.selected();
        String roll=student==null?"":student.optString("roll","").replaceAll("[^0-9]","");
        if(roll.length()<8){finishFullCollection("SIM attendance and results processed. AKTU skipped: no university roll number issued.");return;}
        collectionProgress("aktu","AKTU: complete any official verification, then View Result",false);
        academics.setAktuCaptured(()->finishFullCollection("Collection complete. Check each source for unavailable records."));
        academics.openAktu(roll);
    }
    /** A university outage should never lock the student outside their saved campus data. */
    private void handleAktuUnavailable(String reason){
        if(collecting && "aktu".equals(collectionStage)){
            skipAktuAndOpenDashboard("AKTU One View unavailable ("+reason+"). Your saved SIM records are available; retry AKTU from Results.");
        }else if(!collecting){
            message("AKTU One View unavailable ("+reason+"). Retry later from Results.");
            if(academics!=null)academics.suspendAktuForOutage();
            erpView.stopLoading();
            showApp();
        }
    }
    private void skipAktuAndOpenDashboard(String reason){
        if(!collecting || !"aktu".equals(collectionStage))return;
        if(academics!=null)academics.suspendAktuForOutage();
        // The user may return to AKTU from Results. Do not erase completed SIM data.
        erpView.stopLoading();
        finishFullCollection(reason);
    }
    private void finishFullCollection(String message){
        if(!collecting)return;
        collecting=false;collectionSerial++;
        if(academics!=null)academics.setSimTemporaryPassword("");
        collectionProgress("complete",message,true);showApp();
    }
    private void cancelFullCollection(){
        if(!collecting)return;
        collecting=false;collectionSerial++;
        if(autoActive){autoActive=false;autoScheduleToken++;}
        if(academics!=null){academics.setSimTemporaryPassword("");academics.setAktuCaptured(null);academics.setScanCompletion(null);academics.stopScan("Collection stopped");}
        collectionProgress("cancelled","Collection stopped. Previously saved records remain.",true);
        showApp();
    }
    private void showRosterImport(boolean extend){
        if(viewOnly || (!extend&&!primaryKey.isEmpty())){message("Log out before replacing the primary roster");return;}
        importExtend=extend;
        Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        pick.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/octet-stream"});
        try{startActivityForResult(pick,ROSTER_REQUEST);}catch(Exception e){
            appView.evaluateJavascript("window.onRosterImportError('Android cannot open the document picker.');",null);
            message("No document picker available");
        }
    }
    private void chooseRosterStudent(int index){
        if(!primaryKey.isEmpty()){previewRoster(index);return;}
        try{
            int before=rosterStore.snapshot().optInt("selected",-1);
            JSONObject snap=rosterStore.choose(index);
            if(before!=index){
                cancelFullCollection();
                collegeSessionReady=false;afterCollegeLogin=null;mostRecentCollegeRoute=ERP;
                if(academics!=null){academics.stopScan("Student changed; previous scan stopped");academics.useImportedStudent(rosterStore.selected());}
                CookieManager.getInstance().removeAllCookies(null);
                CookieManager.getInstance().flush();
                erpView.loadUrl("about:blank");
            }
            appView.evaluateJavascript("window.onRosterSelected("+snap.toString()+");",null);
            if(before!=index)message("Student changed. Sign in to their SIM ERP account before fetching results.");
        }catch(Exception e){message("Cannot select student: "+e.getMessage());}
    }
    private void importRosterDocument(Uri uri){
        new Thread(()->{
            try{
                final boolean merge=importExtend;
                JSONObject oldStudent=rosterStore.selected();
                final String previousKey=oldStudent==null?"":oldStudent.optString("studentKey","");
                JSONObject parsed=rosterStore.importXlsx(uri,merge);
                JSONObject newStudent=rosterStore.selected();
                final boolean selectionChanged=!merge||newStudent==null||!previousKey.equals(newStudent.optString("studentKey",""));
                main.post(()->{
                    if(selectionChanged){
                        cancelFullCollection();collegeSessionReady=false;afterCollegeLogin=null;
                        CookieManager.getInstance().removeAllCookies(null);CookieManager.getInstance().flush();
                        erpView.loadUrl("about:blank");
                        if(academics!=null){academics.stopScan("Student roster imported");academics.useImportedStudent(rosterStore.selected());}
                    }
                    appView.evaluateJavascript("window.onRosterImported("+parsed.toString()+");",null);
                    message("Added "+parsed.optInt("added")+" student(s), skipped "+parsed.optInt("duplicatesSkipped")+" duplicates. Total "+rosterStore.count());
                });
            }catch(Exception e){
                String reason = e.getMessage()==null?"Unreadable Excel workbook":e.getMessage();
                main.post(()->{
                    appView.evaluateJavascript("window.onRosterImportError("+JSONObject.quote(reason)+");",null);
                    message("Excel import failed: "+reason);
                });
            }
        },"AcademicKundli-Roster-Import").start();
    }

    private final class UiBridge {
        @JavascriptInterface public void importRoster(){main.post(()->showRosterImport(false));}
        @JavascriptInterface public void extendRoster(){main.post(()->showRosterImport(true));}
        @JavascriptInterface public void startFullCollection(String startDate,String optionalPassword){
            main.post(()->MainActivity.this.startFullCollection(startDate,optionalPassword));
        }
        @JavascriptInterface public void cancelFullCollection(){main.post(()->MainActivity.this.cancelFullCollection());}
        @JavascriptInterface public void selectRosterStudent(int index){main.post(()->chooseRosterStudent(index));}
        @JavascriptInterface public void previewRosterStudent(int index){main.post(()->previewRoster(index));}
        @JavascriptInterface public void previewRosterStudentByKey(String key){main.post(()->{
            int index=rosterStore.indexOfKey(key);if(index<0)message("Student not found in roster");else previewRoster(index);
        });}
        @JavascriptInterface public void endRosterPreview(){main.post(()->MainActivity.this.endRosterPreview());}
        @JavascriptInterface public void logoutPrimary(){main.post(()->MainActivity.this.logoutPrimary());}
        @JavascriptInterface public void searchRosterStudents(String query){main.post(()->{String safe=query==null?"":query.substring(0,Math.min(80,query.length()));JSONObject found=rosterStore.search(safe,30);appView.evaluateJavascript("window.onRosterSearchResults("+found.toString()+");",null);});}
        @JavascriptInterface public void requestRoster(){main.post(()->sendRoster("onRosterLoaded"));}
        @JavascriptInterface public void showErp() { main.post(() -> {if(primaryAuthorized())MainActivity.this.showErp();else message("Primary login required");}); }
        @JavascriptInterface public void openCollegeResult(){main.post(() -> {if(primaryAuthorized())academics.openCollegeResult();else message("Primary login required");});}
        @JavascriptInterface public void openCourse(){main.post(() -> {if(primaryAuthorized())academics.openCourse();else message("Primary login required");});}
        @JavascriptInterface public void openAktu(String roll){main.post(() -> {if(primaryAuthorized())academics.openAktu(roll);else message("Primary login required");});}
        @JavascriptInterface public void prefillAktu(String roll){main.post(() -> {if(primaryAuthorized())academics.prefillAktu();else message("Primary login required");});}
        @JavascriptInterface public void captureCurrentResult(){main.post(() -> {if(primaryAuthorized())academics.captureCurrent();else message("Primary login required");});}
        @JavascriptInterface public void captureStudentProfile(){main.post(() -> {if(primaryAuthorized())academics.captureStudentProfile();else message("Primary login required");});}
        @JavascriptInterface public void scanCollegeResults(){main.post(() -> {if(primaryAuthorized())academics.scanCollegeResults();else message("Primary login required");});}
        @JavascriptInterface public void cacheStudentPhoto(String url){main.post(() -> {if(!primaryAuthorized())return;
            JSONObject active=rosterStore.selected();
            if(active!=null&&url!=null&&url.equals(active.optString("photoUrl","")))
                academics.cacheProfilePhoto(url);
        });}
        @JavascriptInterface public void exportCandidateReport(String json){main.post(() -> {if(primaryAuthorized())academics.exportCandidateReport(json,rosterStore.selected());});}
        @JavascriptInterface public void showToday() { main.post(() -> {if(primaryAuthorized())MainActivity.this.showToday();else message("Primary login required");}); }
        @JavascriptInterface public void showLogin() {
            main.post(() -> { if(!primaryAuthorized()){message("Primary login required");return;}collegeSessionReady=false; afterCollegeLogin=ERP;
                browserContainer.setVisibility(View.VISIBLE); erpView.loadUrl(LOGIN); });
        }
        @JavascriptInterface public void startAutoSync(String from, String to) {
            main.post(() -> {if(primaryAuthorized())startAutomaticSync(from,to);else message("Primary login required");});
        }
        @JavascriptInterface public void stopAutoSync() {
            main.post(() -> stopAuto("Sync stopped. You can resume later."));
        }
        @JavascriptInterface public void openErpRange(String from, String to) {
            // No undocumented API calls: show the official ERP and let the student select
            // this 30-day window there. Date-range batching in the app tracks all windows.
            main.post(() -> {
                if(!primaryAuthorized()){message("Primary login required");return;}
                pendingFrom = from; pendingTo = to;
                navigateCollege(TODAY);
                if (collegeSessionReady && erpView.getUrl()!=null && erpView.getUrl().toLowerCase(Locale.ROOT).contains("attend")) prefillDates(from, to);
                else message("Sign in on /ISIMGLB/Login, then attendance will open automatically");
            });
        }
    }

    // All requests run in the same WebView as the first-party, CAPTCHA-authenticated
    // session. Automation only clicks the attendance tab, the date inputs and Show;
    // it never reads login inputs or sends cookies or credentials anywhere.
    private void startAutomaticSync(String from, String to) {
        if (autoActive) { message("A sync is already running"); return; }
        autoWindows.clear();
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
            df.setLenient(false);
            df.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date fromDate = df.parse(from), toDate = df.parse(to);
            if (fromDate == null || toDate == null || fromDate.after(toDate) || toDate.after(new Date()))
                throw new IllegalArgumentException("Invalid semester date range");
            Calendar start = Calendar.getInstance(TimeZone.getTimeZone("UTC")); start.setTime(fromDate);
            while (!start.getTime().after(toDate) && autoWindows.size() < 240) {
                String a = df.format(start.getTime());
                Calendar end = (Calendar) start.clone(); end.add(Calendar.DATE, 29);
                if (end.getTime().after(toDate)) end.setTime(toDate);
                String b = df.format(end.getTime());
                autoWindows.add(new String[]{a,b});
                start.add(Calendar.DATE, 30);
            }
            if (autoWindows.isEmpty() || autoWindows.size() >= 240) throw new IllegalArgumentException("Date range is too long");
        } catch(Exception e) { message("Choose valid dates before syncing"); return; }
        autoIndex = 0; autoAttempts = 0; autoBusy = false; autoActive = true;
        awaitingLoginNotice = false; autoStage = "ensure";
        notifyApp("Starting automatic sync: " + autoWindows.size() + " intervals", false);
        navigateCollege(TODAY);
        if (collegeSessionReady) scheduleAuto(500);
    }

    private void stopAuto(String explanation) {
        if (!autoActive) return;
        autoActive = false; autoBusy = false; autoStage = "ensure";
        notifyApp(explanation, true);
        if(collecting&&"attendance".equals(collectionStage)) {
            collectionProgress("attendance","Attendance incomplete: "+explanation,false);
            main.postDelayed(this::startCourseCollection,1000);
        }
        message(explanation);
    }

    private boolean erpHost() {
        String u = erpView.getUrl(); if(u == null) return false;
        Uri uri = Uri.parse(u);
        return "https".equalsIgnoreCase(uri.getScheme())
                && "glbg.servergi.com".equalsIgnoreCase(uri.getHost()) && uri.getPort() == 8072;
    }

    private boolean attendancePage() {
        String u = erpView.getUrl();
        return u != null && u.toLowerCase(Locale.ROOT).matches(".*?/student/[^?#]*attend[^?#]*(?:[?#].*)?");
    }

    private void notifyApp(String message, boolean done) {
        JSONObject payload = new JSONObject();
        try {
            payload.put("message",message).put("done",done)
                   .put("index",autoIndex).put("total",autoWindows.size());
        } catch(Exception ignored){}
        if(appView!=null) appView.evaluateJavascript("window.onSyncStatus("+payload.toString()+");",null);
        if(browserTitle!=null)browserTitle.setText(message.length() > 43 ? message.substring(0,43)+"…" : message);
    }

    private void scheduleAuto(int delayMs) {
        if(!autoActive) return;
        int token = ++autoScheduleToken;
        main.postDelayed(() -> {
            if(autoActive && token == autoScheduleToken && !autoBusy) autoTick();
        }, delayMs);
    }

    private String getAutomationScript() throws Exception {
        if(automationScript != null) return automationScript;
        try(InputStream in=getAssets().open("erp_bot.js"); ByteArrayOutputStream buffer=new ByteArrayOutputStream()) {
            byte[] data=new byte[8192]; int n;
            while((n=in.read(data))!=-1) buffer.write(data,0,n);
            automationScript=buffer.toString("UTF-8");
            return automationScript;
        }
    }

    private void command(String action, JSONObject arguments, java.util.function.Consumer<JSONObject> callback) {
        if(!autoActive || !erpHost()) { stopAuto("ERP session is not on the official secure domain."); return; }
        String script;
        try { script=getAutomationScript().replace("'__ACTION__'",JSONObject.quote(action))
                    .replace("__PARAMS__",arguments == null?"{}":arguments.toString()); }
        catch(Exception ex) { stopAuto("Unable to load local attendance automation.");return; }
        autoBusy = true;
        erpView.evaluateJavascript(script, result -> {
            autoBusy = false;
            if(!autoActive) return;
            try {
                Object decoded=new JSONTokener(result).nextValue();
                JSONObject reply=new JSONObject((String)decoded);
                callback.accept(reply);
            } catch(Exception ex) {
                stopAuto("ERP layout could not be read. No attendance was fabricated.");
            }
        });
    }

    private void autoTick() {
        if(!autoActive || autoBusy) return;
        if (!collegeSessionReady) {
            if(afterCollegeLogin == null) afterCollegeLogin = TODAY;
            notifyApp("Waiting for official SIM login and manual CAPTCHA",false);
            // The WebView's onPageFinished will resume sync after successful auth.
            return;
        }
        if(!erpHost()) { navigateCollege(TODAY); return; }
        if(!attendancePage() && !"ensure".equals(autoStage)) autoStage = "ensure";
        if("ensure".equals(autoStage)) {
            command("probe",null,reply -> {
                String state=reply.optString("state");
                if("login".equals(state)) {
                    if(!awaitingLoginNotice){notifyApp("Solve CAPTCHA and log into ERP; sync will resume",false);awaitingLoginNotice=true;}
                    scheduleAuto(3000); return;
                }
                if(!attendancePage()) {
                    if(!awaitingLoginNotice) notifyApp("Opening the official attendance page…",false);
                    navigateCollege(TODAY);
                    scheduleAuto(2600); return;
                }
                awaitingLoginNotice = false; autoStage = "date-tab";
                scheduleAuto(300);
            });
            return;
        }
        if("date-tab".equals(autoStage)) {
            command("open-date",null,reply -> {
                if("login".equals(reply.optString("state"))){autoStage="ensure";scheduleAuto(2000);return;}
                if(!"clicked-tab".equals(reply.optString("state"))) {
                    stopAuto("Couldn't find Date Wise tab. ERP layout needs mapping.");return;
                }
                autoStage="fill";scheduleAuto(1300);
            }); return;
        }
        if(autoIndex>=autoWindows.size()) {
            autoActive=false; autoBusy=false;
            notifyApp("Sync completed: " + autoWindows.size() + " intervals",true);
            if(collecting&&"attendance".equals(collectionStage)){
                collectionProgress("attendance","Attendance synced across "+autoWindows.size()+" date windows",false);
                main.postDelayed(this::startCourseCollection,650);
            }else showApp();
            return;
        }
        String[] dates = autoWindows.get(autoIndex);
        JSONObject range=new JSONObject();
        try { range.put("from",dates[0]).put("to",dates[1]); }catch(Exception ignored){}
        if("fill".equals(autoStage)) {
            notifyApp("Fetching " + dates[0] + " to " + dates[1] + " ("+(autoIndex+1)+"/"+autoWindows.size()+")",false);
            command("fill-submit",range,reply -> {
                String state=reply.optString("state");
                if("login".equals(state)) {autoStage="ensure";scheduleAuto(2000);return;}
                if(!"submitted".equals(state)) {
                    if(autoAttempts++ < 2) {autoStage="date-tab";scheduleAuto(1300);}
                    else stopAuto("Date Wise form couldn't be submitted: " + state);
                    return;
                }
                autoAttempts=0;autoStage="read";scheduleAuto(2200);
            });return;
        }
        if("read".equals(autoStage)) {
            command("read",range,reply -> {
                String state=reply.optString("state");
                if("login".equals(state)) {autoStage="ensure";scheduleAuto(2000);return;}
                JSONObject snapshot=reply.optJSONObject("snapshot");
                if(snapshot != null && ("table".equals(state)||"empty".equals(state))) {
                    // Validate the actual returned rows *belong* to this requested
                    // window (and not a stale AJAX report from a previous one).
                    int matching = countRecordsInRange(snapshot,dates[0],dates[1]);
                    if(matching > 0 || "empty".equals(state)) {
                        appView.evaluateJavascript("window.receiveAutoWindow("+
                                JSONObject.quote(dates[0])+","+JSONObject.quote(dates[1])+","+
                                JSONObject.quote(snapshot.toString())+");",null);
                        autoIndex++;autoAttempts=0;autoStage="fill";
                        scheduleAuto(1200);return;
                    }
                }
                if(autoAttempts++ >= MAX_READ_ATTEMPTS) {
                    stopAuto("ERP didn't return verified attendance for "+dates[0]+" – "+dates[1]+". Inspect Date Wise in the app.");
                    return;
                }
                scheduleAuto(1800);
            });
        }
    }

    // Verifies there is at least one actual P/A/NM date-wise row in the interval.
    // Status totals and row deduplication are handled by the JS attendance engine.
    private int countRecordsInRange(JSONObject snapshot,String from,String to) {
        int count=0; JSONArray tables=snapshot.optJSONArray("tables");
        if(tables==null)return 0;
        for(int i=0;i<tables.length();i++) {
            JSONArray table=tables.optJSONArray(i);if(table==null)continue;
            int dateCol=-1,statusCol=-1;
            for(int j=0;j<table.length();j++) {
                JSONArray row=table.optJSONArray(j);if(row==null)continue;
                if(dateCol<0) {
                    for(int k=0;k<row.length();k++) {
                        String cell=row.optString(k).trim().toLowerCase(Locale.ROOT);
                        if(cell.equals("date"))dateCol=k;
                        if(cell.equals("status"))statusCol=k;
                    }
                    if(dateCol>=0&&statusCol>=0)continue;
                    dateCol=-1;statusCol=-1;continue;
                }
                if(row.length()<=Math.max(dateCol,statusCol))continue;
                String d=row.optString(dateCol).trim();
                if(d.matches("\\d{2}/\\d{2}/\\d{4}")) d=d.substring(6)+"-"+d.substring(3,5)+"-"+d.substring(0,2);
                if(d.compareTo(from)>=0 && d.compareTo(to)<=0) {
                    String status=row.optString(statusCol).trim().toUpperCase(Locale.ROOT);
                    if(status.equals("P")||status.equals("A")||status.equals("NM"))count++;
                }
            }
        }
        return count;
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (academics!=null && academics.onActivityResult(request,result,data))return;
        if (request == ROSTER_REQUEST) {
            if(result == RESULT_OK && data != null && data.getData()!=null){
                appView.evaluateJavascript("window.onRosterImportStarted();",null);
                importRosterDocument(data.getData());
            } else {
                appView.evaluateJavascript("window.onRosterPickerCancelled();",null);
            }
            return;
        }
        if (request == FILE_REQUEST && fileCallback != null) {
            Uri[] files = WebChromeClient.FileChooserParams.parseResult(result, data);
            fileCallback.onReceiveValue(files);
            fileCallback = null;
        }
    }
    @Override public void onBackPressed() {
        if (browserContainer.getVisibility() == View.VISIBLE) {
            if (erpView.canGoBack()) erpView.goBack(); else showApp();
        } else if (appView.canGoBack()) appView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        collecting=false;collectionSerial++;
        autoActive=false;
        if(academics!=null){academics.setSimTemporaryPassword("");academics.stop();}
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        appView.removeJavascriptInterface("Native");
        appView.destroy();
        erpView.destroy();
        super.onDestroy();
    }
}
