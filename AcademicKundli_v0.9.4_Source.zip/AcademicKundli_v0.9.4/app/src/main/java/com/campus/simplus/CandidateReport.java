package com.campus.simplus;

import android.graphics.Canvas;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Unofficial, compact academic report: one subject-code row per semester, with
 *  university and college assessments in separate columns. No DOB/attendance. */
public final class CandidateReport {
    private static final int W=595,H=842,M=30,R=W-M,MAXY=788;
    private static final int INK=Color.rgb(28,39,60), MUTED=Color.rgb(105,116,133),
            ACCENT=Color.rgb(60,78,173), LINE=Color.rgb(224,228,236), PALE=Color.rgb(241,243,250);
    private final PdfDocument doc=new PdfDocument();
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private PdfDocument.Page page;
    private Canvas canvas;
    private int y=38,pageNum=0;

    private CandidateReport(){}
    private static String clean(String s){if(s==null)return "";return s.replaceAll("[\\p{Cntrl}]"," ").replaceAll("\\s+"," ").trim();}
    private static String get(JSONObject obj,String name){return clean(obj==null?"":obj.optString(name,""));}
    private void write(String s,float x,float baseline,float pt,int color,boolean bold){
        paint.setColor(color);paint.setStyle(Paint.Style.FILL);paint.setTypeface(Typeface.create(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL));paint.setTextSize(pt);
        canvas.drawText(clean(s),x,baseline,paint);
    }
    private void rect(float l,float t,float r,float b,int color){paint.setColor(color);paint.setStyle(Paint.Style.FILL);canvas.drawRect(l,t,r,b,paint);}
    private String clip(String str,float width,float point){
        str=clean(str);paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(point);
        if(paint.measureText(str)<=width)return str;
        while(str.length()>1&&paint.measureText(str+"…")>width)str=str.substring(0,str.length()-1);
        return str+"…";
    }
    private ArrayList<String> lines(String str,float width,float pt,int maximum){
        ArrayList<String> out=new ArrayList<>();StringBuilder buf=new StringBuilder();
        for(String word:clean(str).split(" ")){if(word.isEmpty())continue;
            String candidate=buf.length()==0?word:buf+" "+word;
            paint.setTextSize(pt);
            if(paint.measureText(candidate)>width&&buf.length()>0){out.add(clip(buf.toString(),width,pt));buf=new StringBuilder(word);}
            else buf=new StringBuilder(candidate);
        }
        if(buf.length()>0)out.add(clip(buf.toString(),width,pt));
        if(out.size()>maximum){ArrayList<String> capped=new ArrayList<>(out.subList(0,maximum));capped.set(maximum-1,clip(capped.get(maximum-1)+"…",width,pt));return capped;}
        return out;
    }
    private void newPage(){
        if(page!=null)finish();
        page=doc.startPage(new PdfDocument.PageInfo.Builder(W,H,++pageNum).create());canvas=page.getCanvas();canvas.drawColor(Color.WHITE);y=35;
        rect(M,y,M+30,y+30,ACCENT);write("S+",M+6,y+20,13,Color.WHITE,true);
        write("ACADEMICKUNDLI  /  ACADEMIC RESULTS",M+39,y+13,11.5f,INK,true);
        write("Unofficial report • Roster details + saved exam records",M+39,y+27,7.6f,MUTED,false);
        y+=41;rect(M,y,R,y+1,LINE);y+=14;
    }
    private void finish(){if(page==null)return;rect(M,808,R,809,LINE);
        write("AKTU: university  |  ST1/ST2: sessionals  |  PUT: pre-university test",M,821,7.1f,MUTED,false);
        write("Page "+pageNum,R-37,821,7.1f,MUTED,false);doc.finishPage(page);page=null;
    }
    private void ensure(int height){if(page==null||y+height>MAXY)newPage();}
    private void labelValue(String label,String value,int col,int width){
        ensure(35);float x=M+col;
        write(label.toUpperCase(Locale.ROOT),x,y+8,7.5f,MUTED,true);
        write(clip(value.isEmpty()?"Not supplied":value,width,9.4f),x,y+23,9.4f,INK,false);
        y+=31;
    }
    private void pairValues(String a,String av,String b,String bv){
        ensure(37);int top=y;
        write(a.toUpperCase(Locale.ROOT),M+2,top+7,7.1f,MUTED,true);
        write(clip(av.isEmpty()?"Not supplied":av,248,9),M+2,top+22,9,INK,false);
        write(b.toUpperCase(Locale.ROOT),M+279,top+7,7.1f,MUTED,true);
        write(clip(bv.isEmpty()?"Not supplied":bv,243,9),M+279,top+22,9,INK,false);
        y+=34;
    }
    /** Wraps full address/URL text with no data loss; continues onto another page when necessary. */
    private void multilineField(String label,String text,float pt){
        ensure(30);write(label.toUpperCase(Locale.ROOT),M+2,y+10,7.2f,ACCENT,true);y+=17;
        text=clean(text);if(text.isEmpty())text="Not supplied";
        paint.setTypeface(Typeface.DEFAULT);paint.setTextSize(pt);
        while(!text.isEmpty()){
            ensure(13);int take=paint.breakText(text,true,R-M-10,null);
            if(take<=0)break;
            if(take<text.length()){
                int word=text.lastIndexOf(' ',take);if(word>take/2)take=word;
            }
            String line=text.substring(0,take).trim();
            if(!line.isEmpty()){write(line,M+3,y+9,pt,INK,false);y+=12;}
            text=text.substring(take).trim();
        }
        y+=9;
    }
    private void identity(JSONObject p,Bitmap portrait){
        ensure(50);write("COMPLETE STUDENT PROFILE",M,y+12,10.2f,ACCENT,true);y+=24;
        int photoTop=y,photoX=R-113;
        rect(photoX-2,photoTop-2,R+2,photoTop+131,PALE);
        if(portrait!=null){
            float width=portrait.getWidth(),height=portrait.getHeight();
            if(width>0&&height>0){
                float scale=Math.max(110f/width,128f/height);
                int croppedW=Math.max(1,Math.round(110f/scale)),croppedH=Math.max(1,Math.round(128f/scale));
                int x0=Math.max(0,(portrait.getWidth()-croppedW)/2),y0=Math.max(0,(portrait.getHeight()-croppedH)/2);
                paint.setColor(Color.WHITE);paint.setAlpha(255);paint.setStyle(Paint.Style.FILL);paint.setFilterBitmap(true);
                canvas.drawBitmap(portrait,new Rect(x0,y0,Math.min(portrait.getWidth(),x0+croppedW),Math.min(portrait.getHeight(),y0+croppedH)),new RectF(photoX,photoTop,photoX+110,photoTop+128),paint);
            }
        }else{
            write("PHOTO",photoX+38,photoTop+60,9,MUTED,true);
            write("UNAVAILABLE",photoX+22,photoTop+75,7.2f,MUTED,false);
        }
        write("NAME",M+2,y+8,7.6f,MUTED,true);
        write(clip(get(p,"name"),390,12),M+2,y+26,12,INK,true);y+=36;
        write("UNIVERSITY ROLL",M+2,y+8,7.3f,MUTED,true);
        write(clip(get(p,"roll"),370,11),M+2,y+24,11,INK,true);y+=34;
        write("ADMISSION NO",M+2,y+8,7.3f,MUTED,true);
        write(clip(get(p,"admission"),365,9.6f),M+2,y+23,9.6f,INK,false);y+=32;
        write("FATHER'S NAME",M+2,y+8,7.3f,MUTED,true);
        write(clip(get(p,"father"),360,9.6f),M+2,y+23,9.6f,INK,false);y+=33;
        y=Math.max(y,photoTop+140);ensure(25);
        pairValues("Date of birth",get(p,"dob"),"Year of admission",get(p,"admissionYear"));
        pairValues("Category",get(p,"category"),"Course",first(p,"course","program"));
        pairValues("Current semester",get(p,"semester"),"Session",get(p,"session"));
        multilineField("Correspondence address (parents)",get(p,"correspondenceAddress"),8.2f);
        multilineField("Permanent address (parents)",get(p,"permanentAddress"),8.2f);
        // URLs are implementation metadata; reports contain the portrait itself.
        multilineField("Section :-",get(p,"section"),9.2f);
        if(!get(p,"college").isEmpty())multilineField("Institute",get(p,"college"),8.2f);
        ensure(15);rect(M,y,R,y+1,LINE);y+=15;
    }
    private static String first(JSONObject p,String a,String b){String s=get(p,a);return s.isEmpty()?get(p,b):s;}
    private static String normalizeSemester(String semester){
        String val=clean(semester).toUpperCase(Locale.ROOT).replace("SEMESTER","SEM").replaceAll("\\s+", " ").trim();
        Matcher m=Pattern.compile("(?:SEM\\s*[-:]?\\s*)?(\\d{1,2}|X|IX|VIII|VII|VI|V|IV|III|II|I)$").matcher(val);
        if(m.find()){String n=m.group(1);String[] roman={"I","II","III","IV","V","VI","VII","VIII","IX","X"};
            for(int i=0;i<roman.length;i++)if(n.equals(roman[i]))return "Semester "+(i+1);
            try{return "Semester "+Integer.parseInt(n);}catch(Exception ignored){}
        }
        return val.isEmpty()?"Semester unspecified":clean(semester);
    }
    private static String subjectCode(JSONObject s){
        String code=get(s,"code").toUpperCase(Locale.ROOT).replaceAll("\\s+","");
        if(code.isEmpty()){
            Matcher m=Pattern.compile("\\(([A-Za-z]{2,8}[-/]?\\d{2,5}[A-Za-z]?)\\)$").matcher(get(s,"name"));
            if(m.find())code=m.group(1).toUpperCase(Locale.ROOT);
        }
        return code;
    }
    private static String assessment(JSONObject result,JSONObject subject){
        String kind=(get(subject,"examType")+" "+get(result,"exam")).toUpperCase(Locale.ROOT)
                .replaceAll("[._-]+"," ").replaceAll("\\s+"," ").trim();
        if(kind.matches(".*\\b(SESSIONAL|SESSIONAL|ST|MIDTERM|MID TERM|INTERNAL TEST|CLASS TEST|CT)\\s*1\\b.*"))return "st1";
        if(kind.matches(".*\\b(SESSIONAL|SESSIONAL|ST|MIDTERM|MID TERM|INTERNAL TEST|CLASS TEST|CT)\\s*2\\b.*"))return "st2";
        if(kind.matches(".*\\bPUT\\b.*")||kind.contains("PRE UNIVERSITY")||kind.contains("PREUNIVERSITY"))return "put";
        return "other";
    }
    private static String collegeMarks(JSONObject s){String marks=get(s,"marks"),maximum=get(s,"maxMarks");
        return marks+(maximum.isEmpty()?"":"/"+maximum);
    }
    private static String aktuMarks(JSONObject s){
        String internal=get(s,"internal"),external=get(s,"external"),grade=get(s,"grade"),back=get(s,"backPaper");
        ArrayList<String> a=new ArrayList<>();
        if(!internal.isEmpty())a.add("I:"+internal);
        if(!external.isEmpty())a.add("E:"+external);
        if(!back.isEmpty()&&!back.equals("--")&&!back.equals("-"))a.add("B:"+back);
        if(!grade.isEmpty())a.add("G:"+grade);
        if(a.isEmpty())return get(s,"marks");
        return String.join(" ",a);
    }
    private static void append(Subject x,String field,String val){
        val=clean(val);if(val.isEmpty())return;
        if(field.equals("aktu"))x.aktu=addOnce(x.aktu,val);
        else if(field.equals("st1"))x.st1=addOnce(x.st1,val);
        else if(field.equals("st2"))x.st2=addOnce(x.st2,val);
        else if(field.equals("put"))x.put=addOnce(x.put,val);
        else x.other=addOnce(x.other,val);
    }
    private static String addOnce(String old,String value){
        if(old.isEmpty())return value;if(old.equals(value)||(" · "+old+" · ").contains(" · "+value+" · "))return old;
        return old+" · "+value;
    }
    static final class Subject {String name="",code="",aktu="",st1="",st2="",put="",other="";}
    static final class Semester {
        String name,sgpa="",cgpa="",status="",marks="",session="";
        final LinkedHashMap<String,Subject> subjects=new LinkedHashMap<>();
        Semester(String value){name=value;}
    }
    private static LinkedHashMap<String,Semester> combine(JSONArray results){
        LinkedHashMap<String,Semester> semesters=new LinkedHashMap<>();
        for(int i=0;i<results.length();i++){
            JSONObject result=results.optJSONObject(i);if(result==null)continue;
            String semester=normalizeSemester(get(result,"semester"));
            Semester group=semesters.get(semester);if(group==null){group=new Semester(semester);semesters.put(semester,group);}
            boolean university=get(result,"source").equals("aktu");
            if(university){if(!get(result,"sgpa").isEmpty())group.sgpa=get(result,"sgpa");
                if(!get(result,"cgpa").isEmpty())group.cgpa=get(result,"cgpa");
                if(!get(result,"status").isEmpty())group.status=get(result,"status");
                if(!get(result,"marksTotal").isEmpty())group.marks=get(result,"marksTotal");
            }
            if(group.session.isEmpty())group.session=get(result,"session");
            JSONArray subjects=result.optJSONArray("subjects");if(subjects==null)continue;
            for(int j=0;j<subjects.length();j++){
                JSONObject s=subjects.optJSONObject(j);if(s==null)continue;
                String code=subjectCode(s),name=get(s,"name");if(name.isEmpty()&&code.isEmpty())continue;
                // Only identical normalized codes are merged; same-name fallbacks stay in the semester.
                String key=code.isEmpty()?"NAME:"+name.toUpperCase(Locale.ROOT):"CODE:"+code;
                Subject row=group.subjects.get(key);if(row==null){row=new Subject();row.name=name;row.code=code;group.subjects.put(key,row);}
                if(row.name.isEmpty()&&!name.isEmpty())row.name=name;
                if(university)append(row,"aktu",aktuMarks(s));
                else append(row,assessment(result,s),collegeMarks(s));
            }
        }
        return semesters;
    }
    private void semesterHeader(Semester g){ensure(61);
        rect(M,y,R,y+34,PALE);write(clip(g.name,210,11.5f),M+8,y+14,11.5f,INK,true);
        if(!g.sgpa.isEmpty()){write("SGPA",M+259,y+12,7.7f,MUTED,true);write(clip(g.sgpa,58,18),M+302,y+23,18,ACCENT,true);}
        if(!g.status.isEmpty())write(clip(g.status,143,8.3f),M+386,y+21,8.3f,INK,true);
        y+=42;
        if(!g.session.isEmpty()||!g.marks.isEmpty()||!g.cgpa.isEmpty()){
            String label=(g.session.isEmpty()?"":"Session: "+g.session)+(g.marks.isEmpty()?"":"    University marks: "+g.marks)+(g.cgpa.isEmpty()?"":"    CGPA: "+g.cgpa);
            write(clip(label,R-M-10,7.7f),M+5,y+7,7.7f,MUTED,false);y+=17;
        }
    }
    private void head(){ensure(26);rect(M,y,R,y+24,Color.rgb(235,239,250));
        write("SUBJECT / CODE",M+5,y+15,7.3f,ACCENT,true);
        write("AKTU",M+200,y+15,7.3f,ACCENT,true);
        write("ST1",M+317,y+15,7.3f,ACCENT,true);
        write("ST2",M+380,y+15,7.3f,ACCENT,true);
        write("PUT",M+442,y+15,7.3f,ACCENT,true);
        write("OTHER",M+485,y+15,7.3f,ACCENT,true);y+=28;
    }
    private void row(Subject r){
        ArrayList<String> title=lines(r.name.isEmpty()?r.code:r.name,183,8.1f,2);
        ArrayList<String> akt=lines(r.aktu,106,7.7f,3);
        int h=Math.max(30,Math.max(title.size()*11+(!r.code.isEmpty()?11:0)+5,akt.size()*10+9));
        if(y+h>MAXY){newPage();head();}
        int top=y;
        for(int k=0;k<title.size();k++)write(title.get(k),M+5,top+12+k*10,8.1f,INK,k==0);
        if(!r.code.isEmpty())write(clip(r.code,181,7.3f),M+5,top+12+10*title.size(),7.3f,MUTED,false);
        for(int k=0;k<akt.size();k++)write(akt.get(k),M+200,top+12+k*10,7.7f,INK,k==0);
        write(clip(r.st1.isEmpty()?"—":r.st1,57,8.0f),M+317,top+13,8,INK,true);
        write(clip(r.st2.isEmpty()?"—":r.st2,57,8.0f),M+380,top+13,8,INK,true);
        write(clip(r.put.isEmpty()?"—":r.put,40,8.0f),M+442,top+13,8,INK,true);
        write(clip(r.other.isEmpty()?"—":r.other,48,7.5f),M+485,top+13,7.5f,INK,false);
        y+=h;rect(M,y,R,y+0.7f,LINE);y+=3;
    }
    static byte[] render(String payload)throws Exception{return render(payload,null);}
    static byte[] render(String payload,Bitmap photo)throws Exception{
        JSONObject obj=new JSONObject(payload);JSONObject person=obj.optJSONObject("candidate");JSONArray results=obj.optJSONArray("results");
        if(person==null||results==null)throw new IllegalArgumentException("Candidate and result data required");
        if(results.length()>160)throw new IllegalArgumentException("Too many result entries");
        CandidateReport report=new CandidateReport();try{
            report.newPage();report.identity(person,photo);
            LinkedHashMap<String,Semester> semesters=combine(results);
            report.ensure(25);report.write("CONSOLIDATED SUBJECT RESULTS",M,report.y+12,11.3f,INK,true);report.y+=29;
            if(semesters.isEmpty()){report.write("No saved exam results",M+4,report.y+12,9,MUTED,false);report.y+=20;}
            for(Map.Entry<String,Semester> e:semesters.entrySet()){
                Semester sem=e.getValue();report.semesterHeader(sem);
                report.head();
                if(sem.subjects.isEmpty()){report.ensure(20);report.write("No subject marks captured",M+6,report.y+12,8,MUTED,false);report.y+=23;}
                else for(Subject row:sem.subjects.values())report.row(row);
                report.y+=13;
            }
            report.finish();ByteArrayOutputStream out=new ByteArrayOutputStream();report.doc.writeTo(out);return out.toByteArray();
        }finally{report.doc.close();}
    }
}
