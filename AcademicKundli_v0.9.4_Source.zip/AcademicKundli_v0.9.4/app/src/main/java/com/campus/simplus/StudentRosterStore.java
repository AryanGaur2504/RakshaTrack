package com.campus.simplus;

import android.content.Context;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.xml.parsers.DocumentBuilderFactory;

/**
 * Strict offline XLSX reader and encrypted local multi-student roster.
 * The spreadsheet is never uploaded to a server. No third-party SDK or network access.
 */
final class StudentRosterStore {
    private static final String ALIAS="SIMPLUS_ROSTER_V1";
    private static final String FILE="roster.sec";
    static final String[] HEADERS={"Name","University Roll No","Admission No","Father's Name",
       "Date of Birth","Year of Admission","Category","Course","Current Semester","Session",
       "Correspondence Address (Parents)","Permanent Address (Parents)","Photo URL"};
    static final String[] FIELDS={"name","roll","admission","father","dob","admissionYear","category",
       "course","semester","session","correspondenceAddress","permanentAddress","photoUrl"};
    private static final int MAX_FILE=96*1024*1024,MAX_XML=12*1024*1024,MAX_TOTAL_XML=28*1024*1024,MAX_ROWS=2500;
    private final Context context;
    private JSONArray roster=new JSONArray();
    private int selected=-1;
    StudentRosterStore(Context ctx){context=ctx.getApplicationContext();load();}
    synchronized JSONObject selected(){return selected>=0&&selected<roster.length()?roster.optJSONObject(selected):null;}
    synchronized int count(){return roster.length();}
    synchronized JSONObject at(int index){return index>=0&&index<roster.length()?roster.optJSONObject(index):null;}
    synchronized int indexOfKey(String key){
        if(key==null||key.isEmpty())return -1;
        for(int i=0;i<roster.length();i++){
            JSONObject person=roster.optJSONObject(i);
            if(person!=null&&key.equals(person.optString("studentKey","")))return i;
        }
        return -1;
    }

    synchronized JSONObject snapshot(){
        JSONObject out=new JSONObject();JSONArray list=new JSONArray();
        try {
            out.put("selected",selected);
            out.put("count",roster.length());
            for(int i=0;i<Math.min(25,roster.length());i++){
                JSONObject row=roster.optJSONObject(i);if(row==null)continue;
                list.put(new JSONObject().put("index",i).put("name",row.optString("name"))
                    .put("roll",row.optString("roll")).put("admission",row.optString("admission"))
                    .put("semester",row.optString("semester")));
            }
            out.put("students",list);
            if(selected()!=null)out.put("student",new JSONObject(selected().toString()));
        }catch(Exception ignored){}
        return out;
    }
    synchronized JSONObject choose(int index)throws Exception{
        if(index<0||index>=roster.length())throw new IllegalArgumentException("Student does not exist");
        selected=index;context.getSharedPreferences("simplus-roster-ui",0).edit().putInt("selected",index).apply();return snapshot();
    }
    private static String normalized(String s){return (s==null?"":s).trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
    private static String stableKey(JSONObject person,int position){
        String roll=normalized(person.optString("roll"));
        if(!roll.isEmpty())return "roll:"+roll;
        String admission=normalized(person.optString("admission"));
        if(!admission.isEmpty())return "admission:"+admission;
        return "pending:"+normalized(person.optString("name"))+"|"+normalized(person.optString("dob"))+"|"+
            normalized(person.optString("father"))+"|"+position;
    }
    synchronized JSONObject importXlsx(Uri uri)throws Exception{return importXlsx(uri,false);}
    synchronized JSONObject importXlsx(Uri uri,boolean extend)throws Exception{
        JSONArray entries=LargeXlsxReader.load(context,uri);
        if(entries.length()==0)throw new IllegalArgumentException("No student records found");
        JSONArray previous=roster;int previousSelection=selected;
        JSONArray updated=new JSONArray();java.util.HashSet<String> known=new java.util.HashSet<>();
        if(extend)for(int i=0;i<roster.length();i++){
            JSONObject student=roster.optJSONObject(i);if(student==null)continue;
            String key=student.optString("studentKey",stableKey(student,i));
            try{student.put("studentKey",key);}catch(Exception ignored){}
            known.add(key);updated.put(student);
        }
        int added=0,skipped=0;
        for(int i=0;i<entries.length();i++){
            JSONObject student=entries.optJSONObject(i);if(student==null)continue;
            String key=stableKey(student,i);
            if(!known.add(key)){skipped++;continue;}
            student.put("studentKey",key);updated.put(student);added++;
        }
        if(updated.length()==0)throw new IllegalArgumentException("No student rows to import");
        if(updated.length()>LargeXlsxReader.MAX_STUDENTS)throw new IllegalArgumentException("Combined roster exceeds 50,000 students");
        roster=updated;selected=extend&&previousSelection>=0?previousSelection:0;
        try {save();}catch(Exception e){
            roster=previous;selected=previousSelection;
            throw new IllegalArgumentException("Could not save imported students securely: "+e.getMessage());
        }
        context.getSharedPreferences("simplus-roster-ui",0).edit().putInt("selected",selected).apply();
        JSONObject snap=snapshot();snap.put("added",added);snap.put("duplicatesSkipped",skipped);
        snap.put("mode",extend?"extend":"replace");return snap;
    }
    synchronized JSONObject search(String q,int limit){
        String needle=q==null?"":q.trim().toLowerCase(Locale.ROOT);
        int take=Math.min(40,Math.max(1,limit));int matches=0;
        JSONArray list=new JSONArray();
        for(int i=0;i<roster.length();i++){
            JSONObject person=roster.optJSONObject(i);if(person==null)continue;
            String name=person.optString("name"),roll=person.optString("roll"),admission=person.optString("admission");
            if(!needle.isEmpty()&&!name.toLowerCase(Locale.ROOT).contains(needle)&&!roll.toLowerCase(Locale.ROOT).contains(needle)&&!admission.toLowerCase(Locale.ROOT).contains(needle))continue;
            matches++;
            if(list.length()<take)try{list.put(new JSONObject().put("index",i).put("name",name).put("roll",roll).put("admission",admission));}catch(Exception ignored){}
        }
        JSONObject result=new JSONObject();
        try{result.put("query",q==null?"":q);result.put("count",matches);result.put("matches",list);result.put("total",roster.length());}catch(Exception ignored){}
        return result;
    }
    private static int sheetNumber(String value){String n=value.replaceAll("\\D+"," ").trim();try{return Integer.parseInt(n);}catch(Exception ignored){return Integer.MAX_VALUE;}}
    private static Document document(byte[] raw)throws Exception{
        if(raw==null)return null;
        // Excel OOXML worksheets require no document type declarations or entity expansion.
        String xml=new String(raw,StandardCharsets.UTF_8);
        if(xml.contains("<!DOCTYPE")||xml.contains("<!ENTITY"))
            throw new IllegalArgumentException("Workbook contains unsupported XML declarations");
        DocumentBuilderFactory fac=DocumentBuilderFactory.newInstance();fac.setNamespaceAware(true);
        try{fac.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true);}catch(Exception ignored){}
        try{fac.setFeature("http://xml.org/sax/features/external-general-entities",false);}catch(Exception ignored){}
        try{fac.setFeature("http://xml.org/sax/features/external-parameter-entities",false);}catch(Exception ignored){}
        try{fac.setXIncludeAware(false);}catch(Exception ignored){}
        fac.setExpandEntityReferences(false);
        return fac.newDocumentBuilder().parse(new ByteArrayInputStream(raw));
    }
    private static NodeList nodes(Node e,String name){return ((Element)e).getElementsByTagNameNS("*",name);}
    private static String firstText(Node e,String name){
        NodeList n=nodes(e,name);return n.getLength()>0?n.item(0).getTextContent():"";
    }
    private static ArrayList<String> readShared(byte[] raw)throws Exception{
        ArrayList<String> ss=new ArrayList<>();Document doc=document(raw);if(doc==null)return ss;
        NodeList entries=doc.getElementsByTagNameNS("*","si");
        if(entries.getLength()>100000)throw new IllegalArgumentException("Workbook string table too large");
        for(int i=0;i<entries.getLength();i++){
            NodeList parts=nodes(entries.item(i),"t");StringBuilder content=new StringBuilder();
            for(int k=0;k<parts.getLength();k++)content.append(parts.item(k).getTextContent());
            ss.add(content.toString());
        }
        return ss;
    }
    private static boolean readDateSystem(byte[] raw)throws Exception{
        Document d=document(raw);if(d==null)return false;
        NodeList n=d.getElementsByTagNameNS("*","workbookPr");
        if(n.getLength()==0)return false;
        String value=((Element)n.item(0)).getAttribute("date1904");return "1".equals(value)||"true".equalsIgnoreCase(value);
    }
    private static String norm(String s){return s.replace('\u2019','\'').replaceAll("[^a-zA-Z0-9]","").toLowerCase(Locale.ROOT);}
    private static int colIndex(String ref){int number=0;for(int i=0;i<ref.length();i++){char c=Character.toUpperCase(ref.charAt(i));if(c<'A'||c>'Z')break;number=number*26+c-'A'+1;}return number-1;}
    private static String cellValue(Element cell,ArrayList<String> strings){
        String type=cell.getAttribute("t"),v=firstText(cell,"v");
        if("s".equals(type)){
            try{int i=Integer.parseInt(v);return i>=0&&i<strings.size()?strings.get(i):"";}catch(Exception ignored){return "";}
        }
        if("inlineStr".equals(type)){
            StringBuilder buf=new StringBuilder();NodeList parts=nodes(cell,"t");
            for(int i=0;i<parts.getLength();i++)buf.append(parts.item(i).getTextContent());
            return buf.toString();
        }
        if("b".equals(type))return "1".equals(v)?"Yes":"No";
        if(v.matches("[-+]?\\d+\\.0+"))return v.replaceFirst("\\.0+$","");
        return v;
    }
    private static String dateValue(String value,boolean date1904){
        value=value.trim();
        if(value.matches("\\d{4,6}(?:\\.0+)?")){
            try{
                long days=Math.round(Double.parseDouble(value));
                if(days>10000&&days<180000){
                    Calendar c=Calendar.getInstance(TimeZone.getTimeZone("UTC"),Locale.US);c.clear();
                    c.set(1899,Calendar.DECEMBER,30);c.add(Calendar.DATE,(int)days+(date1904?1462:0));
                    SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(c.getTime());
                }
            }catch(Exception ignored){}
        }
        String[] formats={"dd/MM/yyyy","d/M/yyyy","yyyy-MM-dd","dd-MM-yyyy","dd.MM.yyyy"};
        for(String format:formats){try{SimpleDateFormat f=new SimpleDateFormat(format,Locale.US);f.setLenient(false);
            java.util.Date date=f.parse(value);if(date!=null&&f.format(date).equals(value)){
                SimpleDateFormat out=new SimpleDateFormat("dd/MM/yyyy",Locale.US);return out.format(date);
            }
        }catch(Exception ignored){}}
        return value;
    }
    // The order of the 13 columns is fixed, but their headings can be omitted.
    // When headings exist, allow common "No." / "Number" and DOB variants.
    private static boolean headerCell(int i, String value) {
        String v=norm(value);
        if(v.equals(norm(HEADERS[i])))return true;
        switch(i) {
            case 1:return v.equals("universityrollnumber")||v.equals("universityroll")||v.equals("rollno")||v.equals("rollnumber")||v.equals("akturollno");
            case 2:return v.equals("admissionnumber")||v.equals("admissionid")||v.equals("admissionno");
            case 3:return v.equals("fathername")||v.equals("fathersname")||v.equals("parentsname");
            case 4:return v.equals("dob")||v.equals("birthdate")||v.equals("dateofbirth");
            case 5:return v.equals("admissionyear")||v.equals("joiningyear")||v.equals("yearofjoining");
            case 8:return v.equals("semester")||v.equals("currentsem")||v.equals("currentsemester");
            case 10:return v.equals("correspondenceaddress")||v.equals("parentcorrespondenceaddress");
            case 11:return v.equals("permanentaddress")||v.equals("parentpermanentaddress");
            case 12:return v.equals("photo")||v.equals("photourl")||v.equals("photographurl")||v.equals("imageurl");
            default:return false;
        }
    }
    private static boolean looksLikeStudent(String[] v) {
        String name=v[0].trim(),roll=v[1].trim().replaceAll("\\.0+$","");
        if(name.length()<2||name.length()>180||name.matches(".*[<>].*"))return false;
        if(!name.matches(".*[\\p{L}].*"))return false;
        if(roll.length()<5||roll.length()>36||!roll.matches("[\\p{L}0-9_./-]+"))return false;
        if(norm(name).equals("name")||norm(name).startsWith("studentname"))return false;
        // Do not silently treat a partially matching header as a person.
        int matches=0;for(int i=0;i<13;i++)if(headerCell(i,v[i]))matches++;
        return matches<4;
    }
    private static JSONArray readSheet(byte[] raw,ArrayList<String> strings,boolean date1904)throws Exception{
        Document doc=document(raw);if(doc==null)throw new IllegalArgumentException("No worksheet found");
        NodeList rows=doc.getElementsByTagNameNS("*","row");if(rows.getLength()>MAX_ROWS+60)throw new IllegalArgumentException("Workbook contains too many rows");
        JSONArray entries=new JSONArray();HashSet<String> found=new HashSet<>();boolean started=false;
        String issue="No student rows found. Check that Name and University Roll No are columns A and B.";
        for(int j=0;j<rows.getLength();j++){
            Node row=rows.item(j);NodeList cells=nodes(row,"c");String[] values=new String[13];
            for(int k=0;k<values.length;k++)values[k]="";
            for(int i=0;i<cells.getLength();i++){
                Element cell=(Element)cells.item(i);int index=colIndex(cell.getAttribute("r"));
                if(index>=0&&index<13)values[index]=cellValue(cell,strings).trim().replaceAll("[\\u0000-\\u001F]"," ");
            }
            boolean blank=true;for(String value:values)if(!value.isEmpty()){blank=false;break;}
            if(blank)continue;
            int headerMatches=0;for(int i=0;i<13;i++)if(headerCell(i,values[i]))headerMatches++;
            if(!started){
                if(headerMatches>=9){started=true;continue;}
                if(headerMatches>=4){
                    issue="Column heading mismatch in worksheet row "+(j+1)+". Ensure 13 columns in the requested order (Name, University Roll No, Admission No, Father's Name, DOB, …, Photo URL).";
                    continue;
                }
                if(looksLikeStudent(values))started=true;
                else {if(j>40)break;continue;}
            } else if(headerMatches>=9) {continue;} // repeated header when printed/split
            if(!looksLikeStudent(values)){
                throw new IllegalArgumentException("Row "+(j+1)+" is not a student. Name must be column A and University Roll No column B.");
            }
            String roll=values[1].replaceAll("\\.0+$","");
            if(!found.add(roll.toUpperCase(Locale.ROOT)))throw new IllegalArgumentException("Duplicate University Roll No in row "+(j+1)+": "+roll);
            JSONObject record=new JSONObject();
            try{
                for(int i=0;i<13;i++){
                    String value=values[i].length()>1500?values[i].substring(0,1500):values[i];
                    if(i==4)value=dateValue(value,date1904);
                    record.put(FIELDS[i],value);
                }
                entries.put(record);
            }catch(Exception e){throw new IllegalArgumentException("Could not import student in row "+(j+1));}
            if(entries.length()>MAX_ROWS)throw new IllegalArgumentException("Too many student records");
        }
        if(entries.length()==0)throw new IllegalArgumentException(issue);
        return entries;
    }
    private SecretKey secret()throws Exception{
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        if(ks.containsAlias(ALIAS))return (SecretKey)ks.getKey(ALIAS,null);
        KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        generator.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
              .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
        return generator.generateKey();
    }
    private void save()throws Exception{
        JSONObject content=new JSONObject().put("students",roster).put("selected",selected);
        Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,secret());
        byte[] encrypted=cipher.doFinal(content.toString().getBytes(StandardCharsets.UTF_8));
        File temp=new File(context.getFilesDir(),FILE+".tmp"),finalFile=new File(context.getFilesDir(),FILE);
        try(OutputStream out=new FileOutputStream(temp)){
            out.write(cipher.getIV());out.write(encrypted);out.flush();
        }
        if(!temp.renameTo(finalFile)){
            try(InputStream in=new java.io.FileInputStream(temp);OutputStream out=new FileOutputStream(finalFile)){
                byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);
            }
            temp.delete();
        }
    }
    private void load(){
        File f=new File(context.getFilesDir(),FILE);if(!f.exists())return;
        try(InputStream in=new java.io.FileInputStream(f)){
            ByteArrayOutputStream data=new ByteArrayOutputStream();byte[] buffer=new byte[4096];int n;
            while((n=in.read(buffer))!=-1){if(data.size()+n>MAX_FILE)throw new Exception("Roster file too large");data.write(buffer,0,n);}
            byte[] full=data.toByteArray();if(full.length<28)throw new Exception("Corrupt file");
            byte[] nonce=java.util.Arrays.copyOfRange(full,0,12);
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,secret(),new GCMParameterSpec(128,nonce));
            byte[] plain=cipher.doFinal(full,12,full.length-12);
            JSONObject obj=new JSONObject(new String(plain,StandardCharsets.UTF_8));
            roster=obj.getJSONArray("students");
            for(int i=0;i<roster.length();i++){
                JSONObject row=roster.optJSONObject(i);
                if(row!=null&&!row.has("studentKey"))row.put("studentKey",stableKey(row,i));
            }
            selected=context.getSharedPreferences("simplus-roster-ui",0).getInt("selected",obj.optInt("selected",0));
            if(selected>=roster.length()||selected<0)selected=roster.length()>0?0:-1;
        }catch(Exception ignored){roster=new JSONArray();selected=-1;}
    }
}
