/* SIM+ attendance engine: runs completely on device, with no external JS dependencies. */
(function(root){
  'use strict';
  const DAY = 86400000;
  const str = v => String(v === undefined || v === null ? '' : v).trim();
  const norm = v => str(v).replace(/\s+/g,' ').toLowerCase();
  const num = v => { const m=str(v).replace(/,/g,'').match(/-?\d+(?:\.\d+)?/); return m?Number(m[0]):NaN; };
  const iso = d => [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
  function parseDate(v){
    v = str(v).replace(/\s+/g,' '); if(!v)return null;
    let m=v.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if(m){const d=new Date(+m[1],+m[2]-1,+m[3]); return valid(d,+m[1],+m[2],+m[3])?iso(d):null;}
    m=v.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})/);
    if(m){const d=new Date(+m[3],+m[2]-1,+m[1]);return valid(d,+m[3],+m[2],+m[1])?iso(d):null;}
    m=v.match(/^(\d{1,2})\s+([A-Za-z]+)\s+(\d{4})/);
    if(m){const d=new Date(v);return !isNaN(d.getTime())?iso(d):null;}
    return null;
  }
  const valid=(d,y,m,day)=>d.getFullYear()===y&&d.getMonth()+1===m&&d.getDate()===day;
  function rangeParts(start,end,maxDays=30){
    if(!start||!end)throw new Error('Select both dates before syncing.');
    const first=parseDate(start),last=parseDate(end);
    if(!first||!last)throw new Error('Choose dates from the calendar.');
    const localDate=isoDay=>{const [y,m,d]=isoDay.split('-').map(Number);return new Date(y,m-1,d,12,0,0,0);};
    const a=localDate(first),z=localDate(last);
    if(isNaN(a.getTime())||isNaN(z.getTime())||a>z)throw new Error('Select a valid start and end date.');
    const parts=[];
    for(let p=new Date(a);p<=z;p.setDate(p.getDate()+maxDays)){
      const last=new Date(p);last.setDate(last.getDate()+maxDays-1);
      if(last>z)last.setTime(z.getTime());
      parts.push({from:iso(p),to:iso(last),done:false});
      if(parts.length>240)throw new Error('Choose a shorter range.');
    }
    return parts;
  }
  function predict(present,total,target){
    present=Number(present);total=Number(total);target=Number(target);
    if(![present,total,target].every(Number.isFinite)||present<0||total<0||present>total||target<1||target>100)return null;
    const pct=total?present/total*100:0;
    const already=pct+1e-9>=target&&total>0;
    const bunk=already?Math.max(0,Math.floor((present*100/target-total)+1e-9)):0;
    const need=already?0:target===100?(present===total?0:null):Math.max(0,Math.ceil((target*total-100*present)/(100-target)-1e-9));
    return {present,total,target,pct,bunk,need,atTarget:already};
  }
  const isPresent = s => /^(p|pr|present|yes|attended|on duty|od)$/i.test(str(s));
  const isAbsent = s => /^(a|ab|absent|no|missed)$/i.test(str(s));
  function cleanSubject(x){return str(x).replace(/\s+/g,' ').replace(/\s*\(\s*\d+(?:\.\d+)?\s*%\s*\)\s*$/,'').slice(0,110);}
  function safeCell(x){return str(x).replace(/[\u0000-\u001F\u007F]/g,' ').trim().slice(0,160);}
  // SIM Attendance Detail has several *different* tables. Date-wise contains
  // individual class statuses, while Subject/Monthly/Semester show percentages
  // only. Percentages cannot be reverse-engineered into class counts.
  function parseSnapshot(source){
    if(typeof source==='string')source=JSON.parse(source);
    if(!source||!Array.isArray(source.tables))throw new Error('Invalid ERP snapshot');
    const result={subjects:[],records:[],percentages:[],months:[],semesterPct:null,warnings:[],title:safeCell(source.title),path:str(source.url).slice(0,250)};
    const isToday=/\/TodayAttendence\/?$/i.test(result.path),todayPage=parseDate(source.pageDate);
    const subjectMap=new Map(),recordMap=new Map(),pctMap=new Map();
    const statusValue=s=>isPresent(s)?'P':isAbsent(s)?'A':/^(nm|not\s*marked|pending)$/i.test(str(s))?'NM':null;
    const headerIndex=(cells,re)=>cells.findIndex(x=>re.test(norm(x)));
    for(const rawTable of source.tables.slice(0,50)){
      const rows=(Array.isArray(rawTable)?rawTable:[]).map(r=>Array.isArray(r)?r.map(safeCell):[]).filter(r=>r.some(Boolean));
      if(!rows.length)continue;
      let headerAt=-1,cols=null;
      for(let i=0;i<Math.min(rows.length,8);i++){
        const r=rows[i];
        const subject=headerIndex(r,/^(subject|subject name|course|course name|paper|name of subject)$/);
        const date=headerIndex(r,/^(date|attendance date)$/);
        const status=headerIndex(r,/^status$/);
        const slot=headerIndex(r,/^(time\s*slot|time|period|lecture slot|slot)$/);
        const total=headerIndex(r,/^(total|total lectures|lectures held|total classes|total held|conducted)$/);
        const present=headerIndex(r,/^(attended|present|classes attended|lectures attended)$/);
        const percentage=headerIndex(r,/^(status|percentage|attendance percentage|attendance %)$/);
        const month=headerIndex(r,/^(month year|month|month\/year)$/);
        if(subject>=0 && date>=0 && status>=0) {
          headerAt=i;cols={kind:'dated',subject,date,status,slot};break;
        }
        if(isToday && subject>=0 && status<0 && r.some(x=>/lecture/i.test(x))) {headerAt=i;cols={kind:'todayWide',subject};break;}
        if(subject>=0 && total>=0 && present>=0) {
          headerAt=i;cols={kind:'totals',subject,total,present};break;
        }
        if(subject>=0 && status>=0) {
          const numericReport=rows.slice(i+1,i+4).some(x=>Number.isFinite(num(x[status])) && /^\s*\d{1,3}(?:\.\d+)?\s*%?\s*$/.test(str(x[status])));
          headerAt=i;cols={kind:numericReport?'subjectPct':'today',subject,status,slot};break;
        }
        if(month>=0 && status>=0){headerAt=i;cols={kind:'monthly',month,status};break;}
        if(status>=0 && headerIndex(r,/^semester$/)>=0){headerAt=i;cols={kind:'semester',status};break;}
      }
      if(headerAt<0)continue;
      for(let rowNo=headerAt+1;rowNo<rows.length;rowNo++){
        const r=rows[rowNo];
        if(!r.length)continue;
        if(cols.kind==='dated'||cols.kind==='today'){
          const day=cols.kind==='dated'?parseDate(r[cols.date]):todayPage;
          const subject=cleanSubject(r[cols.subject]);
          const status=statusValue(r[cols.status]);
          if(!day||!subject||/^(total|summary|subject name)$/i.test(subject)||!status)continue;
          const rawSlot=cols.slot>=0?str(r[cols.slot]):'';
          const code=rawSlot.match(/\b(?:P|L)\s*\d+\b/i);
          // The ERP date-wise report uses P1, P2 ...; preserve these ids so
          // repeated pulls update the same lecture rather than double count it.
          const slot=code?code[0].replace(/\s+/g,'').toUpperCase():rawSlot?rawSlot.slice(0,70):String(rowNo);
          const key=[day,norm(subject),norm(slot)].join('|');
          recordMap.set(key,{date:day,subject,status,slot,key,source:'erp'});
        } else if(cols.kind==='todayWide'){
          const day=todayPage,subject=cleanSubject(r[cols.subject]);if(!day||!subject)continue;
          for(let k=0;k<r.length;k++){if(k===cols.subject)continue;const status=statusValue(r[k]);if(!status)continue;
            const slot=String(k),key=[day,norm(subject),slot].join('|');recordMap.set(key,{date:day,subject,status,slot,key,source:'erp'});}
        } else if(cols.kind==='totals'){
          const name=cleanSubject(r[cols.subject]),total=num(r[cols.total]),present=num(r[cols.present]);
          if(!name||/^(total|grand total|overall|summary)$/i.test(name)||!Number.isInteger(total)||!Number.isInteger(present)||present<0||total<0||present>total||total>5000)continue;
          subjectMap.set(norm(name),{name,present,total,source:'erp-summary'});
        } else if(cols.kind==='subjectPct'){
          const name=cleanSubject(r[cols.subject]),percent=num(r[cols.status]);
          if(!name||!Number.isFinite(percent)||percent<0||percent>100)continue;
          if(/^(total|grand total|overall)$/i.test(name))result.semesterPct=percent;
          else pctMap.set(norm(name),{name,pct:percent});
        } else if(cols.kind==='monthly'){
          const name=str(r[cols.month]),pct=num(r[cols.status]);
          if(Number.isFinite(pct)&&pct>=0&&pct<=100){
            if(/total/i.test(name))result.semesterPct=pct;
            else result.months.push({month:name,pct});
          }
        } else if(cols.kind==='semester'){
          const pct=num(r[cols.status]);
          if(Number.isFinite(pct)&&pct>=0&&pct<=100)result.semesterPct=pct;
        }
      }
    }
    result.subjects=[...subjectMap.values()];
    result.records=[...recordMap.values()];
    result.percentages=[...pctMap.values()];
    if(!result.subjects.length&&!result.records.length&&!result.percentages.length&&result.semesterPct===null)result.warnings.push('No supported attendance table detected.');
    return result;
  }
  function fromRecords(records){
    const map=new Map();
    for(const r of records){
      if(r.status!=='P'&&r.status!=='A')continue; // NM is not an absence.
      if(!r.date||!r.subject)continue;
      const key=norm(r.subject);
      if(!map.has(key))map.set(key,{name:r.subject,present:0,total:0,source:'erp-datewise'});
      const s=map.get(key);s.total++;if(r.status==='P')s.present++;
    }
    return [...map.values()].sort((a,b)=>a.name.localeCompare(b.name));
  }
  function summary(subjects){let present=0,total=0;for(const s of subjects){present+=Number(s.present)||0;total+=Number(s.total)||0;}return {present,total};}
  const api={rangeParts,predict,parseSnapshot,parseDate,iso,summary,fromRecords};
  if (typeof module!=='undefined' && module.exports) module.exports=api; else root.SimEngine=api;
})(typeof module!=='undefined'&&module.exports?module.exports:window);
