/* DOM-only AKTU One View capture adapted from the user's working MV3 extension.
   Run after the user opens their own result; no credentials, CAPTCHA or cookies read. */
(function(){'use strict';
const tidy=v=>String(v==null?'':v).replace(/\s+/g,' ').trim().slice(0,300);
const value=id=>tidy(document.getElementById(id)?.textContent);
const getCells=row=>[...row.querySelectorAll('th,td')].filter(c=>c.closest('tr')===row).map(c=>tidy(c.textContent));
function subjects(table){
 if(!table)return [];
 const rows=[...table.querySelectorAll('tr')].filter(r=>r.closest('table')===table);
 if(rows.length<2)return [];
 const header=getCells(rows[0]).map((h,i)=>h||'Column_'+(i+1));
 return rows.slice(1).map(row=>{const cells=getCells(row),item={};cells.forEach((v,i)=>{item[header[i]||'Column_'+(i+1)]=v;});return item;}).filter(r=>Object.values(r).some(Boolean));
}
function semesterLabel(prefix,index,region){
 for(const suffix of ['_lblSemesterId','_lblSemester','_lblSem','_lblYearSem']){
  const v=value(prefix+suffix);if(v&&!/select|^\s*-+\s*$/i.test(v))return {text:/^(?:\d{1,2}|[IVX]{1,6})$/i.test(v)?'Semester '+v:v.replace(/^sem\s+/i,'Semester '),confirmed:true};
 }
 // The extension's global body fallback can merge semesters; inspect only this card.
 const heading=tidy(region?.querySelector('h1,h2,h3,h4,legend,.semester,.semester-title')?.textContent||'');
 const m=heading.match(/\b(?:semester|sem)\s*[:\-]?\s*(\d{1,2}|[IVX]{1,6})\b/i);
 if(m)return {text:'Semester '+m[1],confirmed:true};
 return {text:'Unlabelled semester '+(index+1),confirmed:false};
}
const rollNo=value('lblRollNo'),name=value('lblFullName');
if(!rollNo&&!name)return JSON.stringify({ready:false,reason:'AKTU candidate header not loaded'});
const sgpaEls=[...document.querySelectorAll("span[id$='_lblSGPA'],label[id$='_lblSGPA']")];
const tables=[...document.querySelectorAll("table[id*='grdViewSubjectMarksheet']")];
const used=new Set(),semesters=[];
for(const [index,el] of sgpaEls.entries()){
 const prefix=el.id.replace(/_lblSGPA$/,'');
 let table=document.getElementById(prefix+'_ctl00_grdViewSubjectMarksheet');
 const region=el.closest('section,article,.card,.panel,.tab-pane,fieldset')||el.parentElement?.parentElement||null;
 if(!table&&region)table=region.querySelector("table[id*='grdViewSubjectMarksheet']");
 if(!table)table=tables[index]||null;
 if(table)used.add(table);
 const sem=semesterLabel(prefix,index,region);
 semesters.push({semester:sem.text,confirmedSemester:sem.confirmed,sgpa:tidy(el.textContent),subjects:subjects(table)});
}
for(const [index,table] of tables.entries())if(!used.has(table)){
 const prefix=table.id.replace(/_ctl00_grdViewSubjectMarksheet.*$/,'');
 const sem=semesterLabel(prefix,semesters.length,table.closest('section,article,.panel,.card'));
 semesters.push({semester:sem.text,confirmedSemester:sem.confirmed,sgpa:value(prefix+'_lblSGPA'),subjects:subjects(table)});
}
const ready=semesters.some(s=>s.subjects.length>0);
return JSON.stringify({ready,source:'AKTU One View',rollNo,name,fatherName:value('lblFatherName'),enrollmentNo:value('lblEnrollmentNo'),semesters,capturedAt:new Date().toISOString()});
})()
