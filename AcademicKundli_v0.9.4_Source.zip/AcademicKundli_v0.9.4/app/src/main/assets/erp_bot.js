/* Runs inside the student's *authenticated* official-ERP WebView. No cookies,
 * credentials, tokens, or CAPTCHA values are accessed or exported. It acts only
 * upon an explicit Sync button tap in the local companion app. */
(function(A, P) {
 'use strict';
 const output = o => JSON.stringify(o);
 const trim = s => String(s == null ? '' : s).replace(/\s+/g,' ').trim();
 const norm = s => trim(s).toLowerCase();
 const visible = el => !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length) && !el.disabled;
 const cell = el => trim(el.innerText || el.textContent || '').slice(0,250);
 const attendancePath = /\/Student\//i.test(location.pathname) && /attend/i.test(location.pathname);
 const isLogin = !!document.querySelector('input[type="password"]');
 if(isLogin) return output({state:'login',message:'Log in to the original ERP and solve its CAPTCHA. Sync will resume after login.'});
 if(A==='probe') {
   return output({state:'ready',attendancePath, path:location.pathname});
 }
 if(!attendancePath) return output({state:'not-attendance',path:location.pathname});
 const candidates = [...document.querySelectorAll('a,button,input[type="button"],input[type="submit"],[role="tab"],li[onclick],div[onclick]')].filter(visible);
 const textFor = el => trim(el.value || el.innerText || el.getAttribute('aria-label') || '').toLowerCase();
 if(A==='open-date') {
   const dates = candidates.filter(x=>/\bdate\s*wise\b/i.test(textFor(x)));
   const best = dates.find(x=>/^(date\s*wise|date\s*wise\s*attendance)$/.test(textFor(x))) || dates[0];
   if(!best) return output({state:'missing-tab',message:'Could not locate Date Wise attendance tab on this page.'});
   best.click();
   return output({state:'clicked-tab'});
 }
 function editable() {
   return [...document.querySelectorAll('input')].filter(e=>visible(e) && !e.readOnly && !['hidden','button','submit','reset','checkbox','radio','password','file'].includes((e.type||'').toLowerCase()) && ['text','date','search'].includes((e.type||'text').toLowerCase()));
 }
 function findDateFields() {
   const arr=editable();
   const meta = e => norm([e.id,e.name,e.placeholder,e.className,e.getAttribute('aria-label'),e.parentElement?.innerText.slice(0,80)].join(' '));
   const tagged = arr.filter(e=>/\b(date|from|to|start|end)\b/.test(meta(e))||e.type==='date'||/datepicker/i.test(meta(e)));
   let from=tagged.find(e=>/\b(from|start)\b/.test(meta(e)));
   let to=tagged.find(e=>e!==from&&/\b(to|end)\b/.test(meta(e)));
   // The SIM Date Wise tab shown by the student has exactly two editable date
   // fields under its heading. Never fall back to unrelated login inputs.
   if(!from || !to) {
     const anchor=[...document.querySelectorAll('h1,h2,h3,h4,b,strong,span,div,p')].find(e=>visible(e)&&/^(date\s*wise\s*attendance)$/i.test(trim(e.textContent)));
     if(anchor){
       const all = arr.filter(e=>{const a=anchor.getBoundingClientRect(),b=e.getBoundingClientRect();return b.top>=a.top&&b.top<a.top+380;});
       if(all.length===2) {from=all[0];to=all[1];}
     }
   }
   if((!from||!to||from===to) && arr.length===2){from=arr[0];to=arr[1];}
   return {from,to,available:arr.length};
 }
 const emit = (el,iso) => {
   const y=iso.slice(0,4),m=iso.slice(5,7),d=iso.slice(8,10);
   const isDate=el.type==='date';
   const formatted=isDate?iso:(d+'/'+m+'/'+y);
   const desc=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value');
   if(desc&&desc.set) desc.set.call(el,formatted); else el.value=formatted;
   el.dispatchEvent(new Event('input',{bubbles:true}));
   el.dispatchEvent(new Event('change',{bubbles:true}));
   // Some versions of SIM use jQuery datepicker; update its internal selected
   // date when available, without changing any other form or invoking login.
   try {if(window.jQuery && window.jQuery(el).data('datepicker')) window.jQuery(el).datepicker('setDate',new Date(Number(y),Number(m)-1,Number(d)));}catch(_e){}
 };
 if(A==='fill-submit') {
   const f=findDateFields();
   if(!f.from||!f.to) return output({state:'missing-fields',count:f.available,message:'Date fields not found. ERP layout may have changed.'});
   const show=candidates.find(el=>/^show$/i.test(textFor(el)))||candidates.find(el=>/^(search|view|submit|generate|display)$/i.test(textFor(el)));
   if(!show)return output({state:'missing-show',message:'Date Wise Show button not found.'});
   emit(f.from,P.from);emit(f.to,P.to);
   // Never click if the fields failed to take the requested values.
   if(!f.from.value||!f.to.value)return output({state:'bad-fields'});
   show.click();
   return output({state:'submitted',from:P.from,to:P.to});
 }
 if(A==='read') {
   const tables = [...document.querySelectorAll('table')].filter(visible).slice(0,50).map(table => [...table.querySelectorAll('tr')].slice(0,1600).map(tr => [...tr.querySelectorAll('th,td')].map(cell)));
   let recognized=false;
   for(const table of tables) {
     for(const row of table.slice(0,6)) {
       const normalized=row.map(norm);
       if(normalized.some(x=>/^date$/.test(x)||/^attendance date$/.test(x))&&normalized.some(x=>/subject/.test(x))&&normalized.some(x=>/^status$/.test(x))){recognized=true;break;}
     }
   }
   const noRows = /(?:no\s+records?\s+found|no\s+data\s+(?:found|available)|no\s+attendance\s+found|nothing\s+to\s+display)/i.test(document.body.innerText.slice(0,16000));
   const current=findDateFields();
   const values={from:current.from?.value||'',to:current.to?.value||''};
   const snapshot={title:document.title||'',url:location.pathname,tables,pageDate:(() => {const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');})(),capturedAt:new Date().toISOString()};
   return output({state:recognized?'table':noRows?'empty':'not-ready',values,snapshot});
 }
 return output({state:'unknown-command'});
})('__ACTION__',__PARAMS__)
