(function(){'use strict';
const name=document.getElementById('lblFullName'),roll=document.getElementById('lblRollNo');
const tables=[...document.querySelectorAll("table[id*='grdViewSubjectMarksheet']")];
const marks=tables.filter(t=>t.querySelectorAll('tr').length>=2);
const ready=!!(name||roll)&&marks.length>0;
const sig=[name?.textContent||'',roll?.textContent||'',...marks.map(t=>t.textContent?.slice(0,18000)||''),
 ...document.querySelectorAll("[id$='_lblSGPA']")].map(e=>typeof e==='string'?e:(e.textContent||''));
let h=2166136261;for(const s of sig.join('|')){h^=s.charCodeAt(0);h=Math.imul(h,16777619);}
return JSON.stringify({ready,signature:ready?String(h>>>0):'',tables:marks.length});
})()