/* Authorized visible StudentOfficial data only: Section / Group Name. */
(function(){'use strict';
 if(location.protocol!=='https:'||location.hostname!=='glbg.servergi.com'||location.port!=='8072'||!/\/Student\/StudentOfficial/i.test(location.pathname))return JSON.stringify({state:'wrong-page'});
 const text=x=>String(x==null?'':x).replace(/\s+/g,' ').trim().slice(0,140);
 const sectionLabel=x=>/^(?:group(?:\s+name)?|section(?:\s+name)?|student\s+group|class\s+section)\s*[:：-]?$/i.test(text(x));
 const rollLabel=x=>/^(?:university\s+)?roll\s*(?:no\.?|number)?\s*[:：-]?$/i.test(text(x));
 const result={state:'ok',section:'',roll:''};
 for(const row of document.querySelectorAll('tr')){
  const cells=[...row.querySelectorAll('td,th')];
  for(let i=0;i<cells.length-1;i++){
   const label=text(cells[i].textContent);
   const element=cells[i+1].querySelector('input:not([type=password]),select');
   const value=text(element?(element.value||element.selectedOptions?.[0]?.textContent):cells[i+1].textContent);
   if(sectionLabel(label)&&value&&!/select|choose|password|captcha/i.test(value))result.section=value;
   if(rollLabel(label)&&/^\d{8,18}$/.test(value))result.roll=value;
  }
 }
 if(!result.section){
  for(const e of document.querySelectorAll('input:not([type=password]),select,span')){
   const name=[e.id,e.getAttribute('name'),e.getAttribute('aria-label'),e.labels?.[0]?.textContent].filter(Boolean).join(' ');
   if(/group(?:name)?|section/i.test(name)){
    const value=text(e.value||e.selectedOptions?.[0]?.textContent||e.textContent);
    if(value&&!/select|choose|password|captcha/i.test(value)){result.section=value;break;}
   }
  }
 }
 return JSON.stringify(result);
})()
