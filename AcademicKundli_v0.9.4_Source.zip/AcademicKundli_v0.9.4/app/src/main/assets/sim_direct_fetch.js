/* Direct, first-party SIM ExamResult retrieval in the *already-authenticated* WebView.
 * WebView fetch shares the exact portal cookie jar; no cookies, passwords or ASP.NET
 * token values leave this page. The Android host observes only redacted marks rows.
 * A fresh GET supplies unique WebForms state for every POST (verified in the user's
 * authenticated collector diagnostic, Nov 2026). */
(function(){'use strict';
const expectedRoll='__EXPECTED_ROLL__',expectedAdmission='__EXPECTED_ADMISSION__';
const origin='https://glbg.servergi.com:8072', endpoint=origin+'/ISIMGLB/Student/ExamResult';
const job={state:'running',started:Date.now(),message:'Connecting to authenticated SIM…',total:0,completed:0,results:[],error:''};
window.__simDirectFetchJob=job;
const trim=v=>String(v==null?'':v).replace(/\s+/g,' ').trim().slice(0,350);
const err=e=>String(e&&e.message||e||'Unexpected response').slice(0,170);
const cleanDigits=v=>String(v||'').replace(/\D/g,'');
function auth(doc,response){
 if(!response.ok||response.url.includes('/Login')||!doc.querySelector('#MCPH1_SCPH_ddldrp')||!doc.querySelector('#MCPH1_SCPH_btnRun'))throw Error('SIM authentication required, session expired, or page unavailable (HTTP '+response.status+')');
 const roll=cleanDigits(doc.querySelector('#MCPH1_SCPH_txtRollNo')?.textContent);
 const admission=trim(doc.querySelector('#MCPH1_SCPH_txtAdmNo')?.textContent);
 if(expectedRoll&&roll&&expectedRoll!==roll)throw Error('Authenticated SIM roll number differs from the selected student');
 if(expectedAdmission&&admission&&expectedAdmission.toLowerCase()!==admission.toLowerCase())throw Error('Authenticated SIM admission number differs from the selected student');
}
function parse(html){return new DOMParser().parseFromString(html,'text/html');}
function rowCells(row){return [...row.children].filter(x=>/^(TH|TD)$/i.test(x.tagName)).map(x=>trim(x.textContent));}
function snapshot(doc,semester){
 const current=doc.querySelector('#MCPH1_SCPH_ddldrp')?.value||'';
 if(current!==semester.value)throw Error('Semester mismatch: expected '+semester.value+', ERP returned '+current);
 const grid=doc.querySelector('table#MCPH1_SCPH_gvExamDetail');
 if(!grid)return null;
 const rows=[...grid.rows].slice(0,251).map(rowCells).filter(r=>r.length);
 if(rows.length<2||rows[0].indexOf('Subject Name')<0||rows[0].indexOf('Marks Obtain')<0)return null;
 const profile={roll:trim(doc.querySelector('#MCPH1_SCPH_txtRollNo')?.textContent),admission:trim(doc.querySelector('#MCPH1_SCPH_txtAdmNo')?.textContent)};
 return {title:'ExamResult',url:'/ISIMGLB/Student/ExamResult',profile,tables:[rows],tableMeta:[{heading:'Subjectwise Result',semesterContext:'Semester: '+semester.label}],
  selections:[{id:'MCPH1_SCPH_ddldrp',label:'Semester',valueText:semester.label}],scanContext:{semester:semester.label,exam:'All assessments'},capturedAt:new Date().toISOString()};
}
async function load(){
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),28000);
 try{
  const response=await fetch(endpoint,{credentials:'include',cache:'no-store',redirect:'follow',signal:controller.signal,headers:{Accept:'text/html,application/xhtml+xml'}});
  const html=await response.text();const doc=parse(html);auth(doc,response);return doc;
 }finally{clearTimeout(timeout);}
}
async function submit(doc,semester){
 const form=doc.querySelector('form#form1')||doc.querySelector('form');
 const select=doc.querySelector('#MCPH1_SCPH_ddldrp');const btn=doc.querySelector('#MCPH1_SCPH_btnRun');
 if(!form||!select||!select.name||!btn||!btn.name)throw Error('SIM ASP.NET Show form is missing');
 const input=new URLSearchParams(new FormData(form));
 // All ASP.NET hidden fields are from this fresh GET only; never persisted.
 input.set(select.name,semester.value);
 input.set(btn.name,btn.value||'Show');
 const formAction=new URL(form.getAttribute('action')||endpoint,endpoint);
 if(formAction.origin!==origin||!formAction.pathname.startsWith('/ISIMGLB/Student/'))throw Error('Unexpected SIM form destination');
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),40000);
 try{
  const response=await fetch(formAction.href,{method:'POST',credentials:'include',cache:'no-store',redirect:'follow',signal:controller.signal,
   headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',Accept:'text/html,application/xhtml+xml'},body:input.toString()});
  const html=await response.text();const result=parse(html);auth(result,response);return {doc:result,snapshot:snapshot(result,semester)};
 }finally{clearTimeout(timeout);}
}
(async()=>{try{
 if(location.origin!==origin||!location.pathname.startsWith('/ISIMGLB/'))throw Error('Open an authenticated SIM page before fetching results');
 const initial=await load(),select=initial.querySelector('#MCPH1_SCPH_ddldrp');
 const semesters=[...select.options].map(o=>({value:o.value,label:trim(o.textContent)})).filter(x=>/\bsem(?:ester)?\s*(?:[IVX]+|\d+)/i.test(x.label)&&x.value&&!/select/i.test(x.value)).slice(0,14);
 if(!semesters.length)throw Error('No published SIM semesters found');
 job.total=semesters.length;
 let page=initial;
 for(let i=0;i<semesters.length;i++){
  const sem=semesters[i],started=Date.now();job.message='Fetching '+sem.label+' ('+(i+1)+'/'+semesters.length+')';
  try{
   let fetched;
   try{fetched=await submit(page,sem);}
   catch(firstError){
    // WebForms sometimes invalidates its state after a POST; refresh tokens once.
    // Never reuse stale ViewState, and keep the already-proven request as fallback.
    page=await load();fetched=await submit(page,sem);
   }
   page=fetched.doc;
   job.results.push({semester:sem.label,status:fetched.snapshot?'captured':'no-results',snapshot:fetched.snapshot,elapsedMs:Date.now()-started});
  }catch(e){const message=err(e);
   job.results.push({semester:sem.label,status:'unresolved',reason:message,elapsedMs:Date.now()-started});
   try{page=await load();}catch(ignore){}
   if(/authentication|required|differs|expired/i.test(message)){job.state='auth-required';job.error=message;break;}
  }
  job.completed++;
 }
 job.elapsedMs=Date.now()-job.started;
 if(job.state==='running')job.state='done';job.message='SIM result requests completed';
}catch(e){job.state='error';job.error=err(e);job.message='SIM direct fetch unavailable';}})();
return JSON.stringify({state:'started'});
})()
