(function(){'use strict';
const E=window.SimEngine, X=window.SimExams;
const STORE='simplus:v1:private', EXAMS='simplus:v3:results';
const STAR_ROOT='academickundli:v1:starred:', VERSION='AcademicKundli 0.9.4';
let primaryKey='',primaryProfile=null,primaryRosterIndex=-1,viewOnly=false,previewPerson=null,starred={},pendingStarRefresh='';
const studentId=p=>String(p?.studentKey||p?.roll||p?.admission||'').trim();
const isReadOnly=()=>viewOnly&&!!primaryKey;
const starsKey=()=>STAR_ROOT+encodeURIComponent(primaryKey);
function readStars(){try{const o=JSON.parse(localStorage.getItem(starsKey())||'{}');starred=o&&typeof o==='object'&&!Array.isArray(o)?o:{};}catch(e){starred={};}}
function saveStars(){if(primaryKey)localStorage.setItem(starsKey(),JSON.stringify(starred));}
function hideSplash(){document.getElementById('splashScreen')?.classList.add('is-hidden');}
let activeAttendanceKey=STORE,activeResultsKey=EXAMS;
let simScanReport=[];
let rosterReady=false,rosterStudents=[],rosterSelected=-1,rosterProfile=null;
let rosterImporting=false,rosterImportError='',rosterImportNote='';
let rosterCount=0,studentSearchOpen=false,studentQuery='',studentMatches=[],studentMatchCount=0,studentSearchTimer=null;
let collection={active:false,stage:'idle',message:''},dailySubjectFilter='all';
let onboardingError='',onboardingPassword='',rosterGateRendering=false;
const now=()=>E.iso(new Date());
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pct=(n,places=1)=>Number.isFinite(n)?Number(n).toFixed(places)+'%':'—';
const dateHuman=s=>{if(!s)return 'Not set';const [y,m,d]=s.split('-');return [d,m,y].filter(Boolean).join('/');};
const shortDay=s=>{const d=new Date(s+'T12:00:00');return isNaN(d)?s:d.toLocaleDateString('en-IN',{day:'numeric',month:'short'});};
const safeSubject=s=>esc(String(s||'').slice(0,110));
const defaultState={setup:false,start:'',target:75,dark:false,workspaceReady:false,subjects:[],records:[],windows:[],lastSync:'',lastReport:'',selectedSubject:'all',rangeEnd:now(),aktuNotice:'',semesterPct:null,monthly:[],subjectPcts:[],profile:{name:'',roll:'',program:'',semester:'',college:'',session:'',admission:'',father:''}};
let state={...defaultState}, resultState={records:[],lastSync:'',source:'',dobReady:false};
try{let stored=JSON.parse(localStorage.getItem(STORE)||'{}');if(stored&&typeof stored==='object')state={...defaultState,...stored,profile:{...defaultState.profile,...(stored.profile||{})}};}catch(e){}
try{let stored=JSON.parse(localStorage.getItem(EXAMS)||'{}');if(stored&&typeof stored==='object')resultState={...resultState,...stored,records:Array.isArray(stored.records)?stored.records:[]};}catch(e){}
const PAGES={home:['Good to see you,','Your semester at a glance'],attendance:['Your presence, explained',''],results:['Every result, one place',''],profile:['Your workspace',''],about:['About AcademicKundli','How this companion handles your data']};
let page='home',attTab='subjects',examTab='college',historyFilter='all',modalOpen=false;
const icons={home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',attendance:'<path d="M3 3v18h18M7 16l4-5 3 2 5-7"/>',results:'<path d="M7 2h10l4 4v16H3V2h4Zm0 5h10M7 12h10M7 17h7"/>',star:'<path d="m12 2 3.1 6.5 7.2 1-5.2 5 1.2 7.2L12 18l-6.3 3.5 1.2-7.2-5.2-5 7.2-1z"/>',about:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v1"/>',profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-5 3-7 8-7s8 2 8 7"/>',chevron:'<path d="m9 18 6-6-6-6"/>',refresh:'<path d="M20 7v5h-5M4 17v-5h5"/><path d="M5 9a8 8 0 0 1 14-2l1 5M4 12l1 5a8 8 0 0 0 14-2"/>',graduation:'<path d="m2 10 10-5 10 5-10 5-10-5Zm4 3v5c3 3 9 3 12 0v-5M22 10v7"/>',calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4M17 3v4M3 10h18"/>'};
function icon(name){return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.home}</svg>`;}
function native(method,...args){try{if(window.Native&&typeof Native[method]==='function'){Native[method](...args);return true;}}catch(e){toast('App bridge unavailable: '+e.message);}return false;}
function persist(){
 if(isReadOnly())return;
 const saved={...state,profile:{...(state.profile||{})}};
 for(const field of ['dob','correspondenceAddress','permanentAddress','photoUrl'])delete saved.profile[field];
 localStorage.setItem(activeAttendanceKey,JSON.stringify(saved));
}
function persistResults(){if(!isReadOnly())localStorage.setItem(activeResultsKey,JSON.stringify(resultState));}
function resetScope(profile){
 let record={};try{record=JSON.parse(localStorage.getItem(activeAttendanceKey)||'{}')||{};}catch(e){}
 state={...defaultState,rangeEnd:now(),...record,profile:{...defaultState.profile,...(record.profile||{})}};
 let rs={};try{rs=JSON.parse(localStorage.getItem(activeResultsKey)||'{}')||{};}catch(e){}
 resultState={records:[],lastSync:'',source:'',dobReady:false,...rs,records:Array.isArray(rs.records)?rs.records:[]};
 if(profile)state.profile={...state.profile,...profile,program:profile.course||state.profile.program};
 persist();
}
function consumeRoster(snapshot){
 hideSplash();
 const freshKey=String(snapshot.primaryKey||'');
 if(primaryKey!==freshKey){primaryKey=freshKey;readStars();}
 const items=Array.isArray(snapshot.students)?snapshot.students:[];
 if(isReadOnly()&&previewPerson){rosterStudents=items;rosterCount=Number(snapshot.count)||items.length;rosterReady=true;render();return;}
 rosterCount=Number(snapshot.count)||items.length;
 const person=snapshot.student||null,idx=Number(snapshot.selected);
 primaryProfile=person;primaryRosterIndex=idx;viewOnly=false;previewPerson=null;
 const changed=person&&(rosterSelected!==idx||!rosterProfile||rosterProfile.studentKey!==person.studentKey);
 if(changed){
   const wasActive=rosterSelected>=0,roll=String(person.roll||'').trim();
   const scope=String(person.studentKey||roll||person.admission||'student-'+idx);
   const sameOld=!wasActive&&roll&&(String(state.profile.roll||'').trim()===roll);
   if(wasActive){persist();persistResults();}
   activeAttendanceKey=STORE+':student:'+encodeURIComponent(scope);
   activeResultsKey=EXAMS+':student:'+encodeURIComponent(scope);
   if(sameOld&&!localStorage.getItem(activeAttendanceKey)){
     localStorage.setItem(activeAttendanceKey,localStorage.getItem(STORE)||'{}');
     localStorage.setItem(activeResultsKey,localStorage.getItem(EXAMS)||'{}');
   }
   resetScope(person);
 }else if(person){
   state.profile={...state.profile,...person,program:person.course||state.profile.program};
 }
 rosterStudents=items;rosterSelected=person&&idx>=0?idx:-1;rosterProfile=person;
 if(changed){studentSearchOpen=false;studentQuery='';studentMatches=[];}
 rosterReady=true;
 if(rosterSelected>=0)page='home';
 render();
}
window.extendStudentExcel=()=>{if(isReadOnly())return toast('Read-only view.');
  rosterImportError='';rosterImportNote='Choose an additional Excel file. Existing students will be preserved.';
  renderRosterGate();if(!native('extendRoster'))window.onRosterImportError('The Android roster importer is unavailable.');
};
window.importStudentExcel=()=>{if(isReadOnly())return toast('Read-only view.');if(primaryKey)return toast('Log out before replacing the student roster.');
  rosterImportError='';rosterImportNote='Choose an Excel .xlsx file from your phone or Drive.';
  renderRosterGate();
  if(!native('importRoster'))window.onRosterImportError('Android file picker is not available.');
};
window.chooseStudent=index=>{if(!Number.isInteger(Number(index)))return;native(primaryKey?'previewRosterStudent':'selectRosterStudent',Number(index));};
window.onPreviewStudent=person=>{if(!primaryKey||!person)return;if(!isReadOnly()){persist();persistResults();}viewOnly=true;previewPerson=person;rosterProfile=person;const scope=studentId(person);activeAttendanceKey=STORE+':student:'+encodeURIComponent(scope);activeResultsKey=EXAMS+':student:'+encodeURIComponent(scope);resetScope(person);const entry=starred[scope];if(entry?.attendance){state={...defaultState,...entry.attendance,profile:{...defaultState.profile,...person,...(entry.attendance.profile||{})}};resultState={records:[],lastSync:'',...entry.results};}state.workspaceReady=true;studentSearchOpen=false;page='profile';render();};
window.backToPrimary=()=>{viewOnly=false;previewPerson=null;native('endRosterPreview');};
window.toggleStudentSearch=()=>{studentSearchOpen=!studentSearchOpen;studentQuery='';studentMatches=[];renderStudentPicker();if(studentSearchOpen){document.getElementById('studentSearchInput')?.focus();window.queryStudents('');}};
window.queryStudents=value=>{
 studentQuery=String(value||'').slice(0,80);if(studentSearchTimer)clearTimeout(studentSearchTimer);
 studentSearchTimer=setTimeout(()=>{if(!native('searchRosterStudents',studentQuery)){
  window.onRosterSearchResults({query:studentQuery,matches:rosterStudents.filter(x=>[x.name,x.roll].some(t=>String(t||'').toLowerCase().includes(studentQuery.toLowerCase()))).slice(0,30),count:rosterStudents.length});
 }},130);
};
window.onRosterSearchResults=payload=>{
 if(String(payload.query||'')!==studentQuery)return;
 studentMatches=Array.isArray(payload.matches)?payload.matches:[];studentMatchCount=Number(payload.count)||0;
 updateStudentSearchResults();updateOnboardMatches();
};
function updateStudentSearchResults(){
 const out=document.getElementById('studentSearchResults');if(!out)return;
 out.innerHTML=`<div class="student-search-meta">${studentMatchCount} match${studentMatchCount===1?'':'es'}${studentMatchCount>studentMatches.length?` · Showing first ${studentMatches.length}`:''}</div>${studentMatches.length?studentMatches.map(s=>`<button type="button" class="student-search-row" onclick="chooseStudent(${Number(s.index)})"><strong>${esc(s.name)} <span>(${esc(s.roll||(s.admission?'Admission '+s.admission:'Pending university roll'))})</span></strong><small>${s.roll?'University roll number':'Admission number'} ${esc(s.roll||s.admission||'Pending')}</small></button>`).join(''):'<div class="student-search-empty">No students match this search.</div>'}`;
}

window.toggleOnboardSearch=()=>{studentSearchOpen=!studentSearchOpen;studentQuery='';renderRosterGate();if(studentSearchOpen)document.getElementById('onboardStudentSearch')?.focus();};
window.searchOnboardStudent=(value)=>{
 studentQuery=String(value||'').slice(0,80);
 // Keep the onboarding input stable while receiving asynchronous bounded search matches.
 if(studentSearchTimer)clearTimeout(studentSearchTimer);
 studentSearchTimer=setTimeout(()=>{native('searchRosterStudents',studentQuery);},110);
};
function updateOnboardMatches(){
 const output=document.getElementById('onboardStudentMatches');if(!output)return;
 output.innerHTML=studentMatches.length?studentMatches.map(s=>`<button type="button" class="welcome-student" onclick="chooseStudent(${Number(s.index)})"><span class="avatar-initials">${esc((s.name||'S').split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase())}</span><span class="welcome-student-info"><strong>${esc(s.name)}</strong><small>${esc(s.roll||s.admission||'Roll pending')}</small></span><span class="student-arrow">›</span></button>`).join(''):'<p class="welcome-empty">No matching students.</p>';
}
window.onRosterLoaded=consumeRoster;
window.onRosterImportStarted=()=>{rosterImporting=true;rosterImportError='';rosterImportNote='Reading and validating your workbook…';renderRosterGate();};
window.onRosterImported=s=>{rosterImporting=false;rosterImportError='';rosterImportNote='';consumeRoster(s);toast(`${Number(s.added||0)} students added · ${Number(s.duplicatesSkipped||0)} duplicates skipped · ${rosterCount} total.`);};
window.onRosterSelected=s=>{viewOnly=false;previewPerson=null;consumeRoster(s);onboardingError='';};
window.onLoggedOut=()=>{viewOnly=false;previewPerson=null;primaryKey='';primaryProfile=null;pendingStarRefresh='';state.workspaceReady=false;persist();page='home';native('requestRoster');};
window.onRosterImportError=reason=>{
  rosterImporting=false;rosterImportNote='';
  rosterImportError=String(reason||'The file could not be opened.').slice(0,600);
  renderRosterGate();toast('Excel import failed: '+rosterImportError);
};
window.onRosterPickerCancelled=()=>{rosterImporting=false;rosterImportNote='';renderRosterGate();};
function renderRosterGate(){
 const gate=document.getElementById('rosterGate');if(!gate)return;
 const show=!rosterReady||!rosterProfile||(!primaryKey&&!collection.active)||(!state.workspaceReady&&!collection.active&&!isReadOnly());
 gate.classList.toggle('hidden',!show);
 if(!show)return;
 const hasStudent=!!rosterProfile,waiting=!rosterReady;
 const name=esc(rosterProfile?.name||'');
 gate.innerHTML=`<section class="welcome-stage">
  <div class="welcome-brand"><span class="welcome-logo"><img src="logo.svg" alt="AcademicKundli logo"></span><strong>AcademicKundli</strong></div>
  <div class="welcome-hero"><span class="eyebrow">GL BAJAJ · STUDENT COMPANION</span><h2>Your whole semester,<br>in your pocket.</h2><p>One sign-in. Attendance, results and your academic profile — all in one private workspace.</p></div>
  <div class="welcome-steps"><div><b>1</b> Import Excel</div><div><b>2</b> Pick yourself</div><div><b>3</b> Connect</div></div>
  ${rosterImportError?`<div class="roster-import-error" role="alert"><strong>Excel import failed</strong><p>${esc(rosterImportError)}</p></div>`:''}
  ${rosterImportNote?`<div class="roster-import-note" role="status">${esc(rosterImportNote)}</div>`:''}
  ${waiting?'<div class="welcome-wait">Reading your saved student list…</div>':hasStudent?'':`<div class="welcome-import-actions"><button class="action ghost" onclick="importStudentExcel()">${rosterCount?'Replace Excel list':'Import student Excel (.xlsx)'}</button>${rosterCount?'<button class="action ghost" onclick="extendStudentExcel()">+ Extend list</button>':''}</div>`}
  ${rosterReady&&rosterCount&&(!hasStudent||studentSearchOpen)?`<div class="welcome-choose"><label for="onboardStudentSearch">FIND YOUR NAME</label><div class="welcome-search"><span>⌕</span><input type="search" id="onboardStudentSearch" placeholder="Name, admission or university roll number" autocomplete="off" oninput="window.searchOnboardStudent(this.value)" value="${esc(studentQuery)}"></div><div class="welcome-results" id="onboardStudentMatches"></div></div>`:''}
  ${hasStudent?`<div class="welcome-selected"><span class="avatar-initials">${esc((rosterProfile.name||'S').split(/\s+/).slice(0,2).map(x=>x[0]||'').join('').toUpperCase())}</span><div><small>SELECTED STUDENT</small><strong>${name}</strong><span>${esc(rosterProfile.roll||rosterProfile.admission||'University roll pending')}</span></div>${primaryKey?'':`<button type="button" class="change-student" onclick="toggleOnboardSearch()">${studentSearchOpen?'Done':'Change'}</button>`}</div>
   <div class="connect-form"><h3>Connect your academic records</h3><label>Semester start date<input id="oneTapStart" type="date" value="${esc(state.start||'')}" max="${now()}"></label><label>SIM password <small>optional, only if changed</small><input id="oneTapSimPassword" type="password" placeholder="Default: date of birth" autocomplete="off" autocapitalize="off"></label>${onboardingError?`<div class="roster-import-error">${esc(onboardingError)}</div>`:''}<button class="action primary onboard-continue" onclick="startFullCollection()">Continue securely <span>→</span></button><p>We will open the official portal only when verification is required. Your password is not saved.</p></div>`:''}
  <p class="welcome-footer">Developed by Aryan Gaur · Unofficial student app · Official college and university portals remain authoritative</p>
 </section>`;
 if(rosterReady&&rosterCount){const q=studentQuery;window.searchOnboardStudent(q);}
}
function renderStudentPicker(){
 const banner=document.getElementById('studentBanner');if(!banner)return;
 if(!rosterReady||!rosterProfile){banner.innerHTML='';return;}
 const name=rosterProfile.name||'Student',roll=rosterProfile.roll||'';
 if(isReadOnly()){banner.innerHTML=`<div class="view-only-banner"><span>Viewing ${esc(name)} (read-only)</span><button type="button" onclick="backToPrimary()">Back to my profile</button></div>`;return;}
 banner.innerHTML=`<div class="roster-toolbar"><div class="roster-current"><span class="overline">PRIMARY USER · ${rosterCount.toLocaleString('en-IN')} IMPORTED</span><strong>${esc(name)} <span>(${esc(roll||(rosterProfile.admission?'Admission '+rosterProfile.admission:'Roll pending'))})</span></strong></div><div class="roster-tools"><button type="button" class="action small" onclick="toggleStudentSearch()" aria-expanded="${studentSearchOpen}">${studentSearchOpen?'Close search':'Search students'}</button><button class="action small ghost" onclick="extendStudentExcel()">+ Extend list</button>${primaryKey?'':`<button class="action ghost small" onclick="importStudentExcel()">Replace Excel</button>`}</div></div>${studentSearchOpen?`<div class="student-search-box"><label for="studentSearchInput">Search by name or university roll number</label><input id="studentSearchInput" type="search" autocomplete="off" autocorrect="off" spellcheck="false" placeholder="e.g. Joe" value="${esc(studentQuery)}" oninput="queryStudents(this.value)"><div id="studentSearchResults" class="student-search-results" role="listbox"><div class="student-search-meta">Searching…</div></div></div>`:''}`;
 if(studentSearchOpen&&studentMatches.length)updateStudentSearchResults();
}

function toast(message){const t=document.getElementById('toast');t.textContent=String(message);t.classList.remove('hidden');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>t.classList.add('hidden'),4100);}
function button(label,func='syncAttendance()',type='primary',extra=''){return `<button class="action ${type}" ${extra} onclick="${func}">${label}</button>`;}
function empty(iconSymbol,title,subtitle,btnText,fn){return `<div class="empty-state"><span class="empty-symbol">${iconSymbol}</span><h3>${esc(title)}</h3><p>${esc(subtitle)}</p>${btnText?button(esc(btnText),fn):''}</div>`;}
function num(n){return Number(n||0).toLocaleString('en-IN');}
function color(n){return n>=state.target?'good':n>=state.target-10?'warning':'bad';}
function stats(){const totals=E.summary(state.subjects);const from=E.fromRecords(state.records);const parsed=E.summary(from);const use=totals.total?totals:parsed;return {present:use.present,total:use.total,analysis:use.total?E.predict(use.present,use.total,state.target):null};}
function officialPct(){if(Number.isFinite(Number(state.semesterPct))&&state.semesterPct!==null)return Number(state.semesterPct);const s=stats();return s.analysis?s.analysis.pct:null;}
function displayPcts(){
 const byName=new Map();
 for(const s of (state.subjects||[])){if(Number(s.total)>0)byName.set(String(s.name||'').toLowerCase().replace(/[^a-z0-9]/g,''),s);}
 const marked=E.fromRecords(state.records||[]);
 for(const s of marked){const key=String(s.name||'').toLowerCase().replace(/[^a-z0-9]/g,'');if(!byName.has(key))byName.set(key,s);}
 const windowsComplete=(state.windows||[]).length>0&&state.windows.every(w=>w.done)&&(!state.start||state.windows[0].from<=state.start)&&state.windows[state.windows.length-1].to>=now();
 const visible=(state.subjectPcts&&state.subjectPcts.length)?state.subjectPcts.map(s=>{
  const key=String(s.name||'').toLowerCase().replace(/[^a-z0-9]/g,'');
  const counts=byName.get(key);
  return {...s,source:'ERP percentage',present:counts?.present,total:counts?.total,countsComplete:!!counts&&windowsComplete};
 }):[...byName.values()].map(s=>({...s,pct:100*s.present/s.total,source:'Fetched lecture records',countsComplete:windowsComplete}));
 return visible;
}
function dataNote(){return state.semesterPct!==null?'Official ERP semester percentage':state.windows.length&&state.windows.every(w=>w.done)?'Calculated from synchronized lecture records':'From saved lectures — may be incomplete';}
function donut(value,label){const v=Number.isFinite(value)?Math.max(0,Math.min(100,value)):0,arc=(v*339.292/100).toFixed(2);return `<div class="donut"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="54" fill="none" stroke="currentColor" opacity=".08" stroke-width="8"/><circle cx="60" cy="60" r="54" fill="none" stroke="#7777ed" stroke-width="8" stroke-linecap="round" stroke-dasharray="${arc} 339.292"/></svg><div class="inside"><strong>${pct(value)}</strong><small>${esc(label)}</small></div></div>`;}
function isStarred(person){return !!(primaryKey&&person&&starred[studentId(person)]);}
function captureStarSnapshot(id){const rec=starred[id];if(!rec||isReadOnly()||id!==studentId(rosterProfile))return;
 const attendance={...state,profile:{...state.profile}};
 for(const sensitive of ['dob','correspondenceAddress','permanentAddress','photoUrl'])delete attendance.profile[sensitive];
 rec.attendance=attendance;rec.results=JSON.parse(JSON.stringify(resultState));
 rec.updatedAt=new Date().toISOString();rec.hasAttendance=!!(state.lastSync||state.records.length||state.subjects.length);
 rec.hasResults=!!(resultState.lastSync||resultState.records.length);rec.status=rec.hasAttendance&&rec.hasResults?'complete':'partial';saveStars();render();
}
function maybeFetchStar(id){if(isReadOnly()||id!==studentId(rosterProfile))return;
 const rec=starred[id];if(!rec||rec.fetchAttempted)return;
 rec.fetchAttempted=true;saveStars();
 if(!E.parseDate(state.start)){toast('Saved available records. Set your semester start date before refreshing missing attendance/results.');return;}
 if(collection.active){toast('Saved available records. The current collection will complete first.');pendingStarRefresh=id;return;}
 pendingStarRefresh=id;
 if(!native('startFullCollection',state.start,'')){pendingStarRefresh='';toast('Automatic collection requires the Android app.');}
}
window.toggleStar=()=>{
 if(!primaryKey)return toast('Log in to establish the primary user before saving students.');
 const student=rosterProfile,id=studentId(student);if(!id)return toast('Student ID is missing.');
 if(starred[id]){if(!confirm('Unstar this student and permanently remove their locally saved starred attendance/results snapshot?'))return;delete starred[id];if(id!==studentId(primaryProfile)){localStorage.removeItem(STORE+':student:'+encodeURIComponent(id));localStorage.removeItem(EXAMS+':student:'+encodeURIComponent(id));if(isReadOnly()){resetScope(rosterProfile);state.workspaceReady=true;}}saveStars();toast('Saved starred data removed.');render();return;}
 const snapshot={...student};for(const k of ['dob','correspondenceAddress','permanentAddress','photoUrl'])delete snapshot[k];
 starred[id]={id,person:snapshot,createdAt:new Date().toISOString(),updatedAt:'',fetchAttempted:false,status:'pending',attendance:null,results:null};
 if(isReadOnly()){
   const rec=starred[id];const existingRecords=(state.records||[]).length+(resultState.records||[]).length;
   if(existingRecords){rec.attendance={...state};rec.results=JSON.parse(JSON.stringify(resultState));rec.updatedAt=new Date().toISOString();rec.status='cached';}
   saveStars();toast(existingRecords?'Saved existing on-device data.':'Star saved. Other students cannot be fetched with the primary user’s login.');render();return;
 }
 captureStarSnapshot(id);maybeFetchStar(id);toast('Student starred. Attendance/results are captured once, with official login if required.');
};
function starTime(iso){if(!iso)return 'Not fetched';const dt=new Date(iso);return Number.isFinite(dt.getTime())?dt.toLocaleString('en-IN',{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'}):'Not fetched';}
function starredSection(){if(!primaryKey)return '';
 const rows=Object.values(starred).filter(r=>r&&r.id&&r.person);
 return `<section class="panel"><div class="section-top"><h2 class="section-title">★ Starred Students</h2><span class="badge purple">${rows.length} saved</span></div>
 ${rows.length?`<div class="starred-students">${rows.map(r=>`<div class="starred-row"><div class="student-meta"><strong>${esc(r.person.name||'Student')}</strong><small>${esc(r.person.roll||r.person.admission||'No ID')} · Last updated: ${esc(starTime(r.updatedAt))}<br>${esc(r.status||'pending')} · ${r.hasAttendance?'Attendance saved':'Attendance unavailable'} · ${r.hasResults?'Results saved':'Results unavailable'}</small></div><button class="starred-open" onclick="openStarred('${encodeURIComponent(r.id)}')">Open</button><button title="Fetch only when requested" onclick="refreshStarred('${encodeURIComponent(r.id)}')" aria-label="Refresh ${esc(r.person.name||'student')}">↻ Refresh</button></div>`).join('')}</div>`:'<p class="subtle small">Star a student from their profile to save an offline snapshot here.</p>'}
 <p class="starred-note">Saved records open offline. No automatic refresh runs when opening a starred student.</p></section>`;
}
window.openStarred=encoded=>{const id=decodeURIComponent(encoded),r=starred[id];if(!r)return toast('Student is no longer starred.');
 if(primaryKey&&id===studentId(primaryProfile))return window.backToPrimary();
 // Locate the actual roster row; use its verified native index, not a guessed or reused login.
 if(!native('previewRosterStudentByKey',id))toast('Student viewer requires the Android app.');
};
window.refreshStarred=encoded=>{const id=decodeURIComponent(encoded),r=starred[id];if(!r)return;
 if(id!==studentId(primaryProfile))return toast('Only the primary user’s ERP can be refreshed in this session. Log out and authenticate as that student to fetch their records.');
 if(isReadOnly()){window.backToPrimary();return toast('Return to your profile, then refresh.');}
 const start=E.parseDate(state.start);if(!start)return toast('Set your semester start date to refresh records.');
 if(collection.active)return toast('A collection is already active.');
 pendingStarRefresh=id;r.fetchAttempted=true;saveStars();
 if(!native('startFullCollection',start,'')){pendingStarRefresh='';toast('Android bridge unavailable.');}
};
function aboutView(){return `<div class="stack"><div class="panel" style="text-align:center"><img src="logo.svg" alt="AcademicKundli logo" width="100" height="100"><h2>AcademicKundli</h2><p class="subtle">${VERSION}</p><strong>Developed by Aryan Gaur</strong></div><div class="panel"><h2 class="section-title">How your data works</h2><p>AcademicKundli is an independent GL Bajaj academic companion. The college SIM and AKTU portals remain authoritative. Starred student snapshots stay on this device, are not automatically refreshed, and disappear from the starred store when unstarred.</p><p>Switch Student is read-only. Only logging out of the ERP session and signing in again can change the primary user. CAPTCHA and official verification remain on their respective websites.</p><div class="actions">${isReadOnly()?'':button('Logout','logout()','ghost')}</div></div></div>`;}
window.logout=()=>{if(isReadOnly())return toast('Back to my profile before logging out.');if(!confirm('Log out of the primary ERP session? Your starred offline snapshots will remain saved on this device.'))return;native('logoutPrimary');};
function renderNav(){const nav=[['home','Home'],['attendance','Attendance'],['results','Results'],['profile','Profile'],['about','About']];let content=nav.map(([id,label])=>`<button class="nav-link ${page===id?'active':''}" onclick="navigate('${id}')">${icon(id)}${label}</button>`).join('');document.getElementById('desktopNav').innerHTML=content;document.getElementById('mobileNav').innerHTML=nav.map(([id,label])=>`<button class="${page===id?'active':''}" onclick="navigate('${id}')">${icon(id)}<span>${label}</span></button>`).join('');}
function render(){document.body.classList.toggle('darkmode',state.dark);renderNav();const [title,subtitle]=PAGES[page];document.getElementById('pageTitle').textContent=page==='home'?`${title} ${(state.profile.name||'').trim().split(/\s+/)[0]||'there'}`:title;document.getElementById('pageSubtitle').textContent=subtitle;document.getElementById('themeToggle').textContent=state.dark?'☀':'◐';document.getElementById('themeToggle').disabled=isReadOnly();document.getElementById('studentBanner').style.display=isReadOnly()||page==='profile'?'':'none';document.getElementById('content').innerHTML=({home:homeView,attendance:attendanceView,results:resultsView,profile:profileView,about:aboutView})[page]();renderStudentPicker();renderRosterGate();}
window.navigate=p=>{if(!PAGES[p])return;page=p;closeSheet();window.scrollTo(0,0);render();};
window.toggleTheme=()=>{if(isReadOnly())return toast('Settings are disabled in read-only view.');state.dark=!state.dark;persist();render();};
function lastSyncLabel(){return state.lastSync?new Date(state.lastSync).toLocaleString('en-IN',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'}):'Not synced yet';}
function greeting(){const hour=new Date().getHours();return hour<12?'Good morning':hour<17?'Good afternoon':'Good evening';}
function sourceCard(title,subtitle,action,fn,emoji){return `<button class="nav-card" onclick="${fn}"><span class="symbol">${emoji}</span><span style="flex:1"><strong>${esc(title)}</strong><small>${esc(subtitle)}</small></span><span class="arrow">›</span></button>`;}
function recentWeek(){
 const days=['S','M','T','W','T','F','S'],out=[];
 for(let n=6;n>=0;n--){let day=new Date();day.setHours(12,0,0,0);day.setDate(day.getDate()-n);const date=E.iso(day);
 const rows=state.records.filter(r=>r.date===date&&['P','A','NM'].includes(r.status));
 const status=rows.some(x=>x.status==='A')?'A':rows.some(x=>x.status==='P')?'P':rows.some(x=>x.status==='NM')?'NM':'–';
 out.push(`<div class="week-day"><span class="day-status ${status==='P'?'present':status==='A'?'absent':'unmarked'}">${status==='NM'?'–':status}</span><small>${days[day.getDay()]}</small></div>`);
 }
 return out.join('');
}
function homeView(){const o=officialPct(),items=displayPcts(),s=stats();const current=Number.isFinite(o);
 const below=items.filter(x=>Number.isFinite(Number(x.pct))&&x.pct<state.target).sort((a,b)=>a.pct-b.pct);
 let targetText=!current?'Sync attendance to see your progress':o>=state.target?'Above your '+state.target+'% target':'Below your '+state.target+'% target';
 let forecast=s.analysis&&s.total>0&&(!state.windows.length||state.windows.every(x=>x.done))?(s.analysis.bunk>0?`You can miss ${s.analysis.bunk} more lectures and stay on target.`:`Attend ${s.analysis.need||0} in a row to reach the target.`):'Detailed predictions appear after marked lecture history is synced.';
 return `<div class="home-workspace stack">
  ${state.aktuNotice?`<div class="info-box" role="status"><strong>AKTU temporarily unavailable</strong><p>${esc(state.aktuNotice)}</p><div class="actions" style="margin-top:9px"><button class="action small" onclick="setExamTab('aktu');navigate('results')">Retry from Results</button><button class="action small ghost" onclick="dismissAktuNotice()">Dismiss</button></div></div>`:''}
  <div class="home-attendance-panel"><div class="home-ring">${donut(o,'')}</div><div class="home-attendance-copy"><span>OVERALL ATTENDANCE</span><strong>${targetText}</strong><p>${esc(forecast)}</p></div></div>
  ${starredSection()}
  <div class="home-actions">${isReadOnly()?'':`<button onclick="syncAttendance()">${icon('refresh')}<strong>Sync</strong></button>`}<button onclick="setAttTab('predictor');navigate('attendance')">◎<strong>Predictor</strong></button><button onclick="navigate('results')">${icon('results')}<strong>Results</strong></button></div>
  <div class="panel week-card"><div class="section-top"><h2 class="section-title">Last 7 days</h2><span class="subtle small">P present · A absent</span></div><div class="week-grid">${recentWeek()}</div></div>
  <div class="section home-needs"><div class="section-top"><h2 class="section-title">${below.length?'Needs attention':'Your subjects'}</h2><button class="see-all" onclick="navigate('attendance');setAttTab('subjects')">See all</button></div>
  ${items.length?`<div class="attention-list">${(below.length?below:items).slice(0,4).map(s=>`<button class="attention-card" onclick="navigate('attendance');setAttTab('subjects')"><span class="attention-percent ${color(Number(s.pct))}">${pct(s.pct,0)}</span><span class="attention-copy"><strong>${safeSubject(s.name)}</strong><small>${s.present!=null&&s.total?`<span>${num(s.present)} of ${num(s.total)} lectures marked</span>`:s.pct<state.target?'Below attendance target':'On track'}</small></span><span class="attention-arrow">›</span></button>`).join('')}</div>`:empty('◎','Attendance not synced yet','Your official subject attendance will appear here after verification.','','')}
  </div>
  <div class="home-last-update">Last refreshed ${lastSyncLabel()} · ${esc(dataNote())}</div>
 </div>`;
}
function subjectRow(s){
 const n=Number(s.pct),cls=color(n);
 const complete=!!s.countsComplete&&Number(s.total)>0;
 const prediction=complete?E.predict(s.present,s.total,state.target):null;
 const note=prediction?(prediction.atTarget?`Can miss ${prediction.bunk} more lecture${prediction.bunk===1?'':'s'}`:`Attend ${prediction.need===null?'more':prediction.need+' in a row'} to reach ${state.target}%`):'Bunk count available after full date-wise sync';
 return `<div class="subject-item"><div><h3>${safeSubject(s.name)}</h3><small>${s.total!=null?`${s.present}/${s.total} fetched classes`:'Official attendance percentage'}</small><div class="meter ${cls==='good'?'teal':cls==='bad'?'red':''}"><i style="width:${Math.max(0,Math.min(100,n))}%"></i></div><p class="subject-bunk ${prediction?'verified':'pending'}">${esc(note)}</p></div><div><div class="pct numbers">${pct(n)}</div><div style="text-align:right;margin-top:5px"><span class="badge ${cls}">${n>=state.target?'On track':'Below target'}</span></div></div></div>`;
}
function dailyChart(){const days=[];for(let d=13;d>=0;d--){const x=new Date();x.setHours(12,0,0,0);x.setDate(x.getDate()-d);const id=E.iso(x);const rows=state.records.filter(r=>r.date===id&&['P','A'].includes(r.status));const present=rows.filter(r=>r.status==='P').length,ratio=rows.length?present/rows.length:0;days.push(`<div class="heatcell ${!rows.length?'':ratio>=.75?'good':ratio>=.5?'mid':'bad'}" title="${id}: ${present}/${rows.length}" aria-label="${id}: ${present} present of ${rows.length}"></div>`);}return `<div class="heatmap">${days.join('')}</div><div class="heatmap-caption"><span>Last 14 days · blank = no marked classes</span><span>Today</span></div>`;}
function attendanceView(){const options=isReadOnly()?['subjects','daily','predictor']:['subjects','daily','predictor','sync'];return `<div class="stack"><div class="segmented" role="tablist">${options.map(x=>`<button class="${attTab===x?'active':''}" onclick="setAttTab('${x}')">${{subjects:'Subjects',daily:'Daily',predictor:'Predictor',sync:'Sync'}[x]}</button>`).join('')}</div>${({subjects:subjectAttendance,daily:dailyAttendance,predictor:predictionAttendance,sync:syncAttendanceView})[attTab]()}</div>`;}
window.setAttTab=x=>{if(isReadOnly()&&x==='sync')return toast('Sync is disabled while viewing another student.');attTab=x;render();};
function subjectAttendance(){const items=displayPcts(),o=officialPct();return `<div class="panel"><div class="row between wrap"><div><div class="overline">CURRENT SEMESTER</div><h2 class="panel-title" style="margin:8px 0 6px">Overall attendance</h2><div class="subtle small">${esc(dataNote())}</div></div>${donut(o,'of lectures')}</div><div class="grid g2" style="margin-top:14px"><div class="course-info"><span>Target</span><strong>${state.target}%</strong></div><div class="course-info"><span>Last synced</span><strong>${lastSyncLabel()}</strong></div></div></div><div class="panel"><div class="section-top"><h2 class="section-title">Subject breakdown</h2><span class="badge purple">${items.length} subjects</span></div>${items.length?items.map(subjectRow).join(''):empty('▦','No subject data','Sync from the official ERP to populate this list.','Fetch attendance','syncAttendance()')}</div><div class="panel"><div class="section-top"><h2 class="section-title">Recent attendance pattern</h2></div>${dailyChart()}<p class="subtle small">Each square represents a day with available P/A lecture records.</p></div>`;}
function dailyAttendance(){let rows=state.records.filter(r=>!state.start||r.date>=state.start).filter(r=>r.date<=(state.rangeEnd||now()));if(dailySubjectFilter!=='all')rows=rows.filter(r=>r.subject===dailySubjectFilter);if(historyFilter!=='all')rows=rows.filter(r=>r.status===historyFilter);const days={};for(const r of rows) {if(!days[r.date])days[r.date]=[];days[r.date].push(r);}const sorted=Object.keys(days).sort().reverse();return `<div class="panel"><div class="section-top"><h2 class="section-title">Lecture history</h2><span class="badge purple">${rows.length} entries</span></div><div class="row between wrap" style="margin-bottom:17px"><div class="segmented"><button class="${historyFilter==='all'?'active':''}" onclick="setHistoryFilter('all')">All</button><button class="${historyFilter==='P'?'active':''}" onclick="setHistoryFilter('P')">Present</button><button class="${historyFilter==='A'?'active':''}" onclick="setHistoryFilter('A')">Absent</button></div>${button('Today on ERP','openToday()','small')}</div><label class="daily-subject-select">Subject <select aria-label="Filter daily attendance by subject" onchange="setDailySubjectFilter(this.value)"><option value="all">All subjects</option>${[...new Set(state.records.map(r=>String(r.subject||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b)).map(name=>`<option value="${esc(name)}" ${dailySubjectFilter===name?'selected':''}>${esc(name)}</option>`).join('')}</select></label>${sorted.length?sorted.slice(0,90).map(date=>`<div class="timeline-day"><header><strong>${shortDay(date)}</strong><span class="badge">${days[date].filter(r=>r.status==='P').length}/${days[date].filter(r=>['P','A'].includes(r.status)).length} present</span></header>${days[date].map(r=>`<div class="class-card"><div class="class-dot ${r.status}"></div><div class="detail"><strong>${safeSubject(r.subject)}</strong><small>${esc(r.slot||'Lecture slot')}</small></div><span class="status ${r.status}">${r.status==='P'?'Present':r.status==='A'?'Absent':'Not marked'}</span></div>`).join('')}</div>`).join(''):empty('◷','Nothing here yet','Daily records appear after fetching date-wise attendance from SIM.','Sync history','setAttTab(\'sync\')')}</div>`;}
window.setHistoryFilter=x=>{historyFilter=x;render();};
window.setDailySubjectFilter=x=>{dailySubjectFilter=String(x||'all');render();};
function predictionAttendance(){const s=stats();const p=s.analysis,official=officialPct();const canPredict=p&&s.total>0&&(!state.windows.length||state.windows.every(w=>w.done));return `<div class="panel"><div class="row between"><h2 class="section-title">Attendance predictor</h2><span class="badge purple">${state.target}% goal</span></div><p class="subtle small" style="line-height:1.6">Based only on complete, individually marked P/A lecture records, not percentages. Official rules may differ.</p>${canPredict?`<div class="grid g2" style="margin-top:18px"><div class="course-info"><span>Extra classes you can miss</span><strong style="font-size:29px">${num(p.bunk)}</strong></div><div class="course-info"><span>Classes to attend consecutively</span><strong style="font-size:29px">${p.need===null?'Not attainable at 100%':num(p.need)}</strong></div></div><div class="info-box" style="margin-top:14px">Computed from ${num(s.present)} present / ${num(s.total)} marked classes. ${state.semesterPct!==null?'Official ERP percentage: '+pct(official)+'.':''} Verify that all semester date windows have been retrieved.</div>`:empty('◎','Prediction needs complete class counts','SIM reports percentages in some views. Sync the full Date Wise attendance first; no class counts are invented.','Fetch semester','setAttTab(\'sync\')')}</div><div class="panel"><h2 class="section-title">Target control</h2><div class="fields" style="margin-top:14px"><label class="field">Minimum attendance (%)<input id="newTarget" type="number" min="1" max="100" value="${state.target}"></label><div class="center">${button('Save target','saveTarget()')}</div></div></div>`;}
window.saveTarget=()=>{if(isReadOnly())return toast('Read-only view.');const v=Number(document.getElementById('newTarget')?.value);if(!Number.isFinite(v)||v<1||v>100)return toast('Target must be 1–100%.');state.target=v;persist();render();toast('Target saved');};
function syncAttendanceView(){const windows=state.windows||[],completed=windows.filter(w=>w.done).length;return `<div class="panel"><h2 class="section-title">Auto-sync real attendance</h2><p class="subtle small" style="line-height:1.6">Log into the original SIM website once. The app requests each supported 30-day window, reads returned lecture rows, and keeps your session on this device.</p><div class="fields" style="margin:17px 0"><label class="field">From <input type="date" id="attendanceFrom" value="${esc(state.start||'')}" max="${now()}"></label><label class="field">To <input type="date" id="attendanceTo" value="${esc(state.rangeEnd||now())}" max="${now()}"></label></div><div class="actions">${button(icon('refresh')+' Start full sync','syncAttendance()')}${button('Open college ERP','openCollege()','ghost')}</div>${windows.length?`<div class="info-box" style="margin-top:16px">${completed}/${windows.length} date windows completed. Missing windows are not counted as fetched data.</div>`:''}</div><div class="panel"><h2 class="section-title">Import details</h2><div class="list"><div class="list-item"><div><strong>Last ERP refresh</strong><div class="meta">Actual records only</div></div><div class="right">${lastSyncLabel()}</div></div><div class="list-item"><div><strong>Fetched lecture entries</strong><div class="meta">P / A / NM</div></div><div class="right numbers">${state.records.length}</div></div><div class="list-item"><div><strong>30-day intervals</strong><div class="meta">Most recent requested range</div></div><div class="right numbers">${completed}/${windows.length}</div></div></div></div>`;}
window.syncAttendance=()=>{if(isReadOnly())return toast('Read-only students cannot fetch ERP records.');let f=E.parseDate(document.getElementById('attendanceFrom')?.value||state.start),t=E.parseDate(document.getElementById('attendanceTo')?.value||state.rangeEnd||now());if(!f||!t)return toast('Choose both From and To dates.');if(f>t)return toast('From date must be before To date.');if(t>now())return toast('The end date cannot be in the future.');let parts;try{parts=E.rangeParts(f,t);}catch(e){return toast(e.message);}const old=state.windows||[];state.windows=parts.map(p=>({...p,done:!!old.find(w=>w.from===p.from&&w.to===p.to&&w.done)}));state.rangeEnd=t;persist();if(native('startAutoSync',f,t)){document.getElementById('syncBanner').classList.remove('hidden');document.getElementById('syncMessage').textContent='Starting college ERP sync…';}else toast('Auto-sync is only available in the Android app.');};
window.cancelSync=()=>{native('stopAutoSync');document.getElementById('syncBanner').classList.add('hidden');};
window.openToday=()=>isReadOnly()?toast('Read-only view.'):native('showToday');
window.openCollege=()=>isReadOnly()?toast('Read-only view.'):native('showErp');
window.openCollegeResult=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('openCollegeResult'))toast('Update the Android app to use result capture.');};
window.openCourse=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('openCourse'))toast('Update the Android app for Course profile sync.');};
window.openAktu=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');const roll=state.profile.roll||'';if(!native('openAktu',roll))toast('Update the Android app to open AKTU.');};
window.scanCollegeResults=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('scanCollegeResults'))toast('Result scanning requires the updated Android app.');};
window.captureResult=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('captureCurrentResult'))toast('Result capture requires the updated Android app.');};
window.captureProfile=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('captureStudentProfile'))toast('Profile capture requires the updated Android app.');};
window.prepareAktu=()=>{if(isReadOnly())return toast('Read-only view: portal actions are disabled.');if(!native('prefillAktu',state.profile.roll||''))toast('Open AKTU first.');};
function sourceName(src){return src==='aktu'?'AKTU One View':'College SIM';}
function uniqueSubjects(records){const set=new Set();for(const r of records)for(const x of (r.subjects||[]))set.add(String(x.code||x.name||'').toLowerCase());return set.size;}
function semRecords(source,sem){return resultState.records.filter(r=>r.source===source&&String(r.semester||'Semester unavailable')===sem);}
function resultSummaryCard(recs,sem){
 const isAktu=recs[0]?.source==='aktu';
 const sgpa=recs.map(x=>x.sgpa).find(v=>v!==''&&v!=null),cgpa=recs.map(x=>x.cgpa).find(Boolean),total=recs.map(x=>x.marksTotal).find(Boolean);
 const status=recs.map(x=>x.status).find(Boolean),subjects=uniqueSubjects(recs),count=recs.reduce((n,r)=>n+(r.subjects||[]).length,0);
 const types=[...new Set(recs.flatMap(x=>(x.subjects||[]).map(s=>s.examType).filter(Boolean)))];
 return `<article class="result-sem-card result-sem-modern" aria-label="${esc(sem)}">
  <div class="result-sem-head"><div><span class="overline">${isAktu?'AKTU UNIVERSITY':'SIM INTERNAL ASSESSMENTS'}</span><h3>${esc(sem)}</h3><p>${subjects} subject${subjects===1?'':'s'} · ${count} verified entr${count===1?'y':'ies'}</p></div>
  ${isAktu?`<div class="sgpa-highlight"><span>SGPA</span><strong>${esc(sgpa||'—')}</strong></div>`:`<div class="semester-icon">▤</div>`}</div>
  <div class="semester-pill-row">${status?`<span class="semester-pill status">${esc(status)}</span>`:''}${cgpa?`<span class="semester-pill">CGPA ${esc(cgpa)}</span>`:''}${total?`<span class="semester-pill">${esc(total)} marks</span>`:''}${types.slice(0,3).map(t=>`<span class="semester-pill">${esc(t)}</span>`).join('')}</div>
  <button class="result-open" onclick="showSemester('${encodeURIComponent(sem)}')">Explore subjects & marks <span aria-hidden="true">→</span></button>
 </article>`;
}
function semesterCards(records){const groups=new Map();for(const r of records){const key=String(r.semester||'Semester unavailable');if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);}return [...groups].sort((a,b)=>b[0].localeCompare(a[0],undefined,{numeric:true})).map(([sem,list])=>resultSummaryCard(list,sem)).join('');}
function examEntry(r){const rows=r.subjects||[];const types=[...new Set(rows.map(s=>s.examType).filter(Boolean))];return `<div class="result-exam-entry"><div><strong>${esc(r.exam||'Exam result')}</strong><small>${esc(r.session||'')}${rows.length?' · '+rows.length+' assessment entries':''}${types.length?' · '+types.slice(0,3).map(esc).join(', '):''}</small></div>${button('View details',`showExam('${encodeURIComponent(r.id)}')`,'small')}</div>`;}
function semesterSubjectView(matches){
 const source=matches[0]?.source||'college';
 const rows=matches.flatMap(r=>(r.subjects||[]).map(s=>({...s,exam:r.exam,semester:r.semester})));
 if(!rows.length)return '<div class="info-box">The official portal did not provide subject-level marks for this result.</div>';
 if(source==='aktu')return `<div class="subject-list">${rows.map(s=>`<div class="subject-search-item" data-search="${esc([s.name,s.code,s.subjectType].join(' ').toLowerCase())}">${resultSubjectCard(s,source)}</div>`).join('')}</div>`;
 const groups=new Map();for(const item of rows){const key=String(item.code||item.name).toLowerCase();if(!groups.has(key))groups.set(key,[]);groups.get(key).push(item);}
 return `<div class="subject-list">${[...groups.values()].map(items=>{
   const s=items[0];return `<article class="college-subject-group subject-search-item" data-search="${esc([s.name,s.code,...items.map(x=>x.examType)].join(' ').toLowerCase())}">
    <div class="subject-group-title"><div><h4>${esc(s.name||s.code||'Subject')}</h4><p>${esc(s.code||'')} · ${items.length} exam entr${items.length===1?'y':'ies'}</p></div></div>
    <div class="assessment-grid">${items.map(it=>{
      const n=Number(it.marks),max=Number(it.maxMarks),good=Number.isFinite(n)&&Number.isFinite(max)&&max>0;
      const v=good?Math.min(100,Math.max(0,100*n/max)):null;
      return `<div class="assessment-card"><div class="assessment-heading">${esc(it.examType||it.exam||'Assessment')}</div>
       <div class="assessment-score"><strong>${esc(it.marks||'—')}</strong><span>${esc(it.maxMarks?'/ '+it.maxMarks:'marks')}</span></div>
       ${v!==null?`<div class="marks-progress"><div style="width:${v}%"></div></div>`:''}
       <div class="assessment-footer">${esc([it.examMonth,it.marksType].filter(Boolean).join(' · '))}</div></div>`;
    }).join('')}</div>
  </article>`;}).join('')}</div>`;
}
window.filterResultSubjects=value=>{const q=String(value||'').trim().toLowerCase();for(const el of document.querySelectorAll('.subject-search-item'))el.hidden=!!q&&!(el.getAttribute('data-search')||'').includes(q);};
window.showSemester=encoded=>{
 const sem=decodeURIComponent(encoded),matches=semRecords(examTab,sem);if(!matches.length)return;
 const sgpa=matches.map(r=>r.sgpa).find(Boolean),cgpa=matches.map(r=>r.cgpa).find(Boolean),result=matches.map(r=>r.status).find(Boolean);
 const sum=matches.map(r=>r.marksTotal).find(Boolean),date=matches.map(r=>r.resultDate).find(Boolean);
 const isAktu=examTab==='aktu',n=uniqueSubjects(matches);
 showSheet(`<div class="result-sheet academic-sheet"><div class="sheet-topline"><span class="overline">${esc(sourceName(examTab))} · AUTHENTIC RECORDS</span><button class="sheet-dismiss" onclick="closeSheet()" aria-label="Close">✕</button></div>
 <div class="academic-sheet-hero"><span class="overline">ACADEMIC SCORECARD</span><h2>${esc(sem)}</h2><p>${n} subjects ${sum?' · '+esc(sum)+' marks':''}${date?' · Declared '+esc(date):''}</p>
 ${isAktu?`<div class="headline-sgpa"><span>SEMESTER GRADE POINT AVERAGE</span><strong>${esc(sgpa||'—')}</strong><small>${esc(result||'Official AKTU scorecard')}${cgpa?' · CGPA '+esc(cgpa):''}</small></div>`:''}</div>
 <div class="result-summary-pills">${[result?['Result',result]:null,cgpa?['CGPA',cgpa]:null,sum?['Marks',sum]:null].filter(Boolean).map(([a,b])=>`<div><span>${esc(a)}</span><strong>${esc(b)}</strong></div>`).join('')}</div>
 <div class="subject-search"><span aria-hidden="true">⌕</span><input aria-label="Search subjects" placeholder="Find subject or exam…" oninput="filterResultSubjects(this.value)"></div>
 ${semesterSubjectView(matches)}
 <div class="actions" style="margin-top:18px">${button('Save compact PDF','downloadReport()')}</div>
 <p class="result-hint">Missing values are shown as —. Grades and marks are taken from the original result page, not estimated.</p></div>`);
};
function resultsView(){
 const matching=resultState.records.filter(x=>x.source===examTab);
 const semesters=new Set(matching.map(x=>x.semester||'Semester unavailable'));
 const selected=examTab==='aktu';
 const refresh=selected?'openAktu()':'scanCollegeResults()';
 return `<div class="stack result-workspace">
  <div class="result-switch" role="tablist" aria-label="Result source"><button role="tab" aria-selected="${!selected}" class="${!selected?'current':''}" onclick="setExamTab('college')">▤ College SIM</button><button role="tab" aria-selected="${selected}" class="${selected?'current':''}" onclick="setExamTab('aktu')">AKTU One View</button></div>
  ${selected&&state.aktuNotice?`<div class="info-box" role="status">${esc(state.aktuNotice)} <button class="action small" onclick="openAktu()">Retry AKTU One View</button></div>`:''}
  <div class="result-brief">${matching.length?`${semesters.size} semester${semesters.size===1?'':'s'} · ${uniqueSubjects(matching)} subjects`:'Published results appear here once captured.'}</div>
  <div class="result-sem-list">${matching.length?semesterCards(matching):empty('▤','No official results captured',selected?'Complete AKTU verification to retrieve the university scorecard.':'No confirmed SIM subject-marks table has been retrieved.',isReadOnly()?'':'Open official portal',refresh)}</div>
  ${isReadOnly()?'':`<details class="refresh-panel"><summary>${icon('refresh')} Refresh academic records</summary><p>Only results actually published by the official portal will be imported. Verification is completed on the official page.</p>
   <div class="actions">${isReadOnly()?'':button(selected?'Open AKTU verification':'Scan available SIM results',refresh)}${isReadOnly()?'':button('Capture currently visible result','captureResult()','ghost')}</div>
   ${!selected&&simScanReport.length?`<div class="scan-audit">${simScanReport.map(x=>`<div class="scan-audit-entry"><strong>${esc(x.semester||'Semester')}</strong><span class="badge">${x.state==='verified'?'Imported':x.state==='no-results'?'Unreleased':'Not verified'}</span><small>${esc(x.reason||'')}</small></div>`).join('')}</div>`:''}
  </details>`}
  <div class="report-cover"><div class="overline">YOUR ACADEMIC TRANSCRIPT</div><h3>Candidate result report</h3><p>Profile, photograph and consolidated subject-wise marks from verified sources.</p>${isReadOnly()?'':button('Export results PDF','downloadReport()')}</div>
 </div>`;
}
window.setExamTab=x=>{if(!['college','aktu'].includes(x))return;examTab=x;render();};
window.dismissAktuNotice=()=>{if(isReadOnly())return;state.aktuNotice='';persist();render();};
function resultSubjectCard(s,src){
 const parts=[];const actual=s.marks!==undefined&&s.marks!==null?String(s.marks):'';
 if(src==='aktu'){
  if(s.internal!==undefined&&s.internal!=='')parts.push(['Internal',s.internal]);
  if(s.external!==undefined&&s.external!=='')parts.push(['External',s.external]);
  if(s.backPaper&&s.backPaper!=='--')parts.push(['Back paper',s.backPaper]);
  if(s.credits)parts.push(['Credits',s.credits]);
 }else{
  if(actual)parts.push(['Obtained',actual]);
  if(s.maxMarks)parts.push(['Maximum',s.maxMarks]);
  if(s.minMarks)parts.push(['Minimum',s.minMarks]);
 }
 const amount=(src==='college'&&Number.isFinite(Number(actual))&&Number.isFinite(Number(s.maxMarks))&&Number(s.maxMarks)>0)?Math.max(0,Math.min(100,(Number(actual)/Number(s.maxMarks))*100)):null;
 return `<article class="subject-result-card"><div class="subject-result-header"><div><h4>${esc(s.name||s.code||'Subject')}</h4><p>${esc([s.code,s.subjectType,s.examType,s.examMonth].filter(Boolean).join(' · ')||'Official result entry')}</p></div>${s.grade?`<span class="grade-bubble">${esc(s.grade)}</span>`:''}</div>
 <div class="result-values">${parts.map(([k,v])=>`<div><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('')}${s.result?`<div><span>Result</span><strong>${esc(s.result)}</strong></div>`:''}</div>
 ${amount!==null?`<div class="marks-progress"><div style="width:${amount}%"></div></div>`:''}</article>`;
}
window.showExam=encoded=>{const id=decodeURIComponent(encoded),r=resultState.records.find(x=>x.id===id);if(!r)return;
 const grouped=new Map();for(const s of (r.subjects||[])){const key=r.source==='aktu'?'University subjects':s.examType||'Other assessment';if(!grouped.has(key))grouped.set(key,[]);grouped.get(key).push(s);}
 const summary=[['SGPA',r.sgpa],['CGPA',r.cgpa],['Total marks',r.marksTotal],['Result',r.status],['Declared',r.resultDate]].filter(x=>x[1]);
 const blocks=[...grouped].map(([name,arr])=>`<section class="result-subject-group"><h3>${esc(name)} <small>${arr.length} subject${arr.length===1?'':'s'}</small></h3>${arr.map(s=>resultSubjectCard(s,r.source)).join('')}</section>`).join('');
 showSheet(`<div class="result-sheet"><div class="sheet-topline"><span class="overline">${esc(sourceName(r.source))} · ${esc(r.session||'')}</span><button class="sheet-dismiss" onclick="closeSheet()" aria-label="Close">✕</button></div><h2>${esc(r.semester||'Semester results')}</h2><p>${esc(r.exam||'Published examination records')}</p>${summary.length?`<div class="result-detail-stats">${summary.map(([k,v])=>`<div><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('')}</div>`:''}${blocks||'<div class="info-box">No subject-level marks were included in this captured summary.</div>'}<div class="actions" style="margin-top:20px">${isReadOnly()?'':button('Export academic PDF','downloadReport()')}</div></div>`);
};
function reportData(){return {candidate:{name:state.profile.name||'',father:state.profile.father||'',roll:state.profile.roll||'',program:state.profile.program||'',semester:state.profile.semester||'',college:state.profile.college||'',session:state.profile.session||'',admission:state.profile.admission||'',dob:state.profile.dob||'',admissionYear:state.profile.admissionYear||'',category:state.profile.category||'',correspondenceAddress:state.profile.correspondenceAddress||'',permanentAddress:state.profile.permanentAddress||'',photoUrl:state.profile.photoUrl||'',section:state.profile.section||''},generatedAt:new Date().toISOString(),results:resultState.records.map(r=>({source:r.source,semester:r.semester,exam:r.exam,session:r.session,sgpa:r.sgpa,cgpa:r.cgpa,status:r.status,marksTotal:r.marksTotal,resultDate:r.resultDate,subjects:(r.subjects||[]).map(s=>({code:s.code,name:s.name,marks:s.marks,grade:s.grade,credits:s.credits,total:s.total,result:s.result,examType:s.examType,examMonth:s.examMonth,marksType:s.marksType,minMarks:s.minMarks,maxMarks:s.maxMarks,internal:s.internal,external:s.external,backPaper:s.backPaper,subjectType:s.subjectType}))}))};}
window.downloadReport=()=>{if(isReadOnly())return toast('PDF export is disabled in read-only view.');if(!rosterProfile)return toast('Import an Excel and select a student before exporting.');const raw=JSON.stringify(reportData());if(!native('exportCandidateReport',raw))toast('PDF export requires the updated Android app.');};
function profileView(){const p=state.profile;
const items=[['Full name',p.name],['University roll no.',p.roll],['Admission no.',p.admission],['Father’s name',p.father],['Date of birth',p.dob],['Year of admission',p.admissionYear],['Category',p.category],['Course',p.course||p.program],['Current semester',p.semester],['Session',p.session],['Correspondence address (parents)',p.correspondenceAddress],['Permanent address (parents)',p.permanentAddress],['Section :-',p.section]];
const photo=isReadOnly()?'':String(p.photoUrl||'');let safePhoto='';try{const url=new URL(photo);if(url.protocol==='https:'&&url.hostname)safePhoto=url.href;}catch(e){}
return `<div class="stack"><div class="panel"><div class="row align-start" style="gap:16px;margin-bottom:18px"><div class="roster-avatar">${safePhoto?`<img src="${esc(safePhoto)}" alt="Student portrait" loading="lazy" onload="if(window.Native&amp;&amp;Native.cacheStudentPhoto)Native.cacheStudentPhoto(this.getAttribute('src'))" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span class="photo-fallback" style="display:none">PHOTO<br>UNAVAILABLE</span>`:'<span class="photo-fallback">PHOTO<br>UNAVAILABLE</span>'}</div><div><h2 style="margin:0 0 6px">${esc(p.name||'Student profile')}</h2><div class="subtle small">${esc(p.roll||'No roll number')}</div><div class="badge" style="margin-top:8px">${esc(p.semester||'Semester not set')}</div></div><button class="star-button ${isStarred(rosterProfile)?'active':''}" aria-label="${isStarred(rosterProfile)?'Unstar':'Star'} student" title="${isStarred(rosterProfile)?'Remove from starred students':'Save student'}" onclick="toggleStar()">${isStarred(rosterProfile)?'★':'☆'}</button></div><div class="course-grid">${items.map(([label,val])=>`<div class="course-info"><span>${esc(label)}</span><strong>${esc(val||'Not supplied')}</strong></div>`).join('')}</div><div class="actions" style="margin-top:20px">${isReadOnly()?'':button('Generate comprehensive PDF','downloadReport()')}${button(isReadOnly()?'Back to my profile':'Switch student (view-only)',isReadOnly()?'backToPrimary()':'switchActiveStudent()','ghost')}${isReadOnly()?'':button('Extend student list','extendStudentExcel()','ghost')}</div><div class="tiny-line">Student details come from your encrypted Excel roster. Photo loading contacts its host only when displayed or exported. SIM/AKTU marks are captured separately from official authenticated pages.</div></div>${isReadOnly()?`<div class="read-only-hint">Student switching is view-only. Academic records are loaded from locally saved snapshots; no ERP requests are made.</div>`:`<div class="panel"><h2 class="section-title">Attendance preferences</h2><div class="fields" style="margin:17px 0"><label class="field">Semester start<input type="date" id="semesterStart" value="${esc(state.start||'')}" max="${now()}"></label><label class="field">Attendance target (%)<input type="number" id="goalTarget" min="1" max="100" value="${state.target}"></label></div>${button('Save preferences','savePreferences()')}</div><div class="panel"><h2 class="section-title">Official academic portals</h2><p class="tiny-line">Selecting a different student does not log into their ERP account. Other students remain view-only. To authenticate as someone else, log out first and complete their own official login and CAPTCHA. AKTU roll and DOB are prepared only for the primary user.</p><div class="actions">${button('SIM ERP login','openCollege()')}${button('AKTU One View','openAktu()','ghost')}</div><div class="actions" style="margin-top:15px">${button('Export attendance backup','backupLocal()','ghost')}${button('Restore old backup','restoreLocal()','ghost')}${button('Clear cached results','clearResults()','ghost')}</div></div>`}</div>`;}
window.savePreferences=()=>{if(isReadOnly())return toast('Settings are disabled in read-only view.');
 const raw=document.getElementById('semesterStart')?.value||'',s=E.parseDate(raw);
 const t=Number(document.getElementById('goalTarget')?.value);
 if(!s)return toast('Choose the semester start date using the calendar.');
 if(s>now())return toast('Semester start cannot be after today.');
 if(!Number.isFinite(t)||t<1||t>100)return toast('Attendance target must be from 1% to 100%.');
 state.start=s;state.target=t;state.setup=true;persist();render();toast('Preferences saved');
};
window.backupLocal=()=>{if(isReadOnly())return toast('Read-only view.');const raw=JSON.stringify({...state,format:'SIM+1'},null,2);if(navigator.clipboard&&window.isSecureContext)navigator.clipboard.writeText(raw).then(()=>toast('Backup copied to clipboard')).catch(()=>prompt('Copy this local backup:',raw));else prompt('Copy this local backup:',raw);};
window.restoreLocal=()=>{if(isReadOnly())return toast('Read-only view.');const raw=prompt('Paste the SIM+ attendance JSON from your previous app:');if(!raw)return;try{const obj=JSON.parse(raw);if(obj.format!=='SIM+1'||!Array.isArray(obj.records)||!Array.isArray(obj.subjects))throw Error();if(!confirm('Replace this app’s attendance cache with the backup? Exam results remain unchanged.'))return;for(const k of ['start','target','setup','dark','subjects','records','windows','lastSync','lastReport','selectedSubject','rangeEnd','semesterPct','monthly','subjectPcts'])if(Object.hasOwn(obj,k))state[k]=obj[k];persist();render();toast('Previous SIM+ attendance restored');}catch(e){toast('Unrecognized SIM+ backup');}};
window.switchActiveStudent=()=>{
 if(collection.active)return toast('Finish the current collection before switching views.');
 if(isReadOnly())return window.backToPrimary();
 studentSearchOpen=true;studentQuery='';studentMatches=[];studentMatchCount=0;
 page='profile';render();
 document.getElementById('studentSearchInput')?.focus();window.queryStudents('');
};
window.clearResults=()=>{if(isReadOnly())return toast('Read-only view.');if(!confirm('Remove all locally saved exam results?'))return;resultState.records=[];resultState.lastSync='';persistResults();render();toast('Saved results cleared');};
window.clearAttendance=()=>{if(isReadOnly())return toast('Read-only view.');if(!confirm('Remove attendance records and synchronization history?'))return;state.records=[];state.subjects=[];state.subjectPcts=[];state.semesterPct=null;state.monthly=[];state.windows=[];state.lastSync='';persist();render();toast('Attendance cache cleared');};
function showSheet(html){document.getElementById('sheetBody').innerHTML=html;document.getElementById('modalBackdrop').classList.remove('hidden');modalOpen=true;}
window.closeSheet=ev=>{if(ev&&ev.target!==document.getElementById('modalBackdrop'))return;document.getElementById('modalBackdrop').classList.add('hidden');modalOpen=false;};
window.onSyncStatus=obj=>{const running=!obj.done;const bar=document.getElementById('syncBanner');bar.classList.toggle('hidden',!running);document.getElementById('syncMessage').textContent=obj.message||'Sync in progress';if(obj.done){toast(obj.message||'Sync finished');render();}};
window.receiveAutoWindow=(from,to,raw)=>{if(isReadOnly())return;try{const d=E.parseSnapshot(raw);const valid=d.records.filter(r=>r.date>=from&&r.date<=to&&['P','A','NM'].includes(r.status));const map=new Map(state.records.map(r=>[r.key,r]));valid.forEach(r=>map.set(r.key,{...r,source:'erp-auto'}));state.records=[...map.values()].sort((a,b)=>a.date.localeCompare(b.date));state.subjects=E.fromRecords(state.records);const w=state.windows.find(w=>w.from===from&&w.to===to);if(w)w.done=true;state.lastSync=new Date().toISOString();persist();render();}catch(e){toast('Unable to parse ERP history. No data added.');}};
window.receiveErpSnapshot=raw=>{if(isReadOnly())return;try{const d=E.parseSnapshot(raw);let fetched=false;const map=new Map(state.records.map(r=>[r.key,r]));d.records.forEach(r=>{map.set(r.key,r);fetched=true;});state.records=[...map.values()];if(d.subjects.length){state.subjects=d.subjects;fetched=true;}else if(d.records.length)state.subjects=E.fromRecords(state.records);if(d.percentages.length){state.subjectPcts=d.percentages;fetched=true;}if(d.semesterPct!==null){state.semesterPct=d.semesterPct;fetched=true;}if(d.months.length)state.monthly=d.months;if(!fetched)return toast('No recognized ERP attendance records found');state.lastSync=new Date().toISOString();persist();render();toast('Attendance captured from official ERP');}catch(e){toast('ERP attendance table was not recognized');}};
window.receiveAktuExtensionCapture=raw=>{if(isReadOnly())return;
 try{
  const data=typeof raw==='string'?JSON.parse(raw):raw;
  if(!data.ready||!Array.isArray(data.semesters))return false;
  const normRoll=v=>String(v||'').replace(/\D/g,'');
  const expected=normRoll(rosterProfile?.roll||state.profile.roll);
  const actual=normRoll(data.rollNo);
  if(expected&&actual&&actual!==expected){toast('AKTU result belongs to another student; not imported.');return false;}
  const merged=new Map(resultState.records.map(r=>[r.id,r]));let captured=0;
  const pick=(obj,re)=>{for(const [k,v] of Object.entries(obj))if(re.test(String(k).replace(/\s+/g,' ').trim()))return String(v||'').trim().slice(0,140);return '';};
  data.semesters.forEach((sem,i)=>{
   const semester=String(sem.semester||`Unlabelled semester ${i+1}`).trim();
   const subjects=(Array.isArray(sem.subjects)?sem.subjects:[]).map(item=>{
    const name=pick(item,/^(subject\s*name|name\s*of\s*subject|paper\s*name|subject|name)$/i);
    const code=pick(item,/^(subject\s*code|paper\s*code|course\s*code|code)$/i);
    const internal=pick(item,/^(internal(?:\s*marks)?|ia)$/i);
    const external=pick(item,/^(external(?:\s*marks)?|end\s*sem(?:ester)?)$/i);
    const backPaper=pick(item,/^(back\s*paper(?:\s*marks)?|carry\s*over)$/i);
    const grade=pick(item,/^(grade|letter\s*grade)$/i);
    const marks=pick(item,/^(marks|marks\s*obtained|total\s*marks\s*obtained|obtained)$/i);
    if(!name&&!code)return null;
    if(!internal&&!external&&!backPaper&&!grade&&!marks)return null;
    return {name:name||code,code,internal,external,backPaper,grade,marks,credits:pick(item,/^credits?$/i),examType:'University result',marksType:'',examMonth:'',result:'',subjectType:pick(item,/^(type|subject\s*type)$/i)};
   }).filter(Boolean);
   if(!subjects.length)return;
   const id=['aktu',semester.toLowerCase().replace(/[^a-z0-9]/g,'-'),actual||expected||''].join('|');
   merged.set(id,{id,source:'aktu',semester,exam:'University result',session:'',sgpa:String(sem.sgpa||'').trim(),cgpa:'',status:'',subjects});captured++;
  });
  if(!captured)return false;
  resultState.records=[...merged.values()].sort((a,b)=>String(b.semester||'').localeCompare(a.semester||'',undefined,{numeric:true}));
  resultState.lastSync=new Date().toISOString();resultState.source='aktu';persistResults();
  examTab='aktu';page='results';render();toast(`AKTU One View: ${captured} semester result(s) captured`);return true;
 }catch(e){toast('AKTU capture error: '+String(e.message||e).slice(0,100));return false;}
};
window.receiveExamSnapshot=(source,raw)=>{if(isReadOnly())return;try{const snap=typeof raw==='string'?JSON.parse(raw):raw;const parsed=X.parseSnapshot(snap,source);
 const identity=snap.profile||{};let identityChanged=false;
 if(rosterProfile&&identity.roll){
   const normRoll=x=>String(x||'').replace(/\D/g,'');
   const original=String(rosterProfile.roll||'').trim(),studentAdmission=String(rosterProfile.admission||'').trim();
   if((original&&normRoll(identity.roll)!==normRoll(original))||(!original&&studentAdmission&&identity.admission&&identity.admission.trim().toLowerCase()!==studentAdmission.toLowerCase())){
     toast('ERP result belongs to a different student. Sign in with the selected student’s account.');return;
   }
 }

 if(source==='college'&&!rosterProfile){for(const k of ['name','father','roll','program','admission'])if(typeof identity[k]==='string'&&identity[k].trim()){state.profile[k]=identity[k].trim().slice(0,110);identityChanged=true;}}
 if(identityChanged)persist();
 if(!parsed.results.length){if(identityChanged)render();return false;}
 const byId=new Map(resultState.records.map(r=>[r.id,r]));
 for(const r of parsed.results){const previous=byId.get(r.id);if(previous&&previous.subjects?.length){const key=s=>[s.code||s.name,s.examType,s.marksType,s.examMonth].map(x=>String(x||'').toLowerCase()).join('|');const existing=new Map(previous.subjects.map(s=>[key(s),s]));r.subjects.forEach(s=>existing.set(key(s),s));r.subjects=[...existing.values()];}
 byId.set(r.id,r);}
 resultState.records=Array.from(byId.values()).sort((a,b)=>String(b.semester||'').localeCompare(a.semester||'',undefined,{numeric:true}));resultState.lastSync=new Date().toISOString();resultState.source=source;
 persistResults();examTab=source;page='results';render();toast(`Imported ${parsed.results.length} official result record(s)`);return true;
 }catch(e){toast('Could not parse official result: '+String(e.message||e).slice(0,80));return false;}};
window.receiveStudentProfile=raw=>{if(isReadOnly())return;try{const d=typeof raw==='string'?JSON.parse(raw):raw;
if(rosterProfile&&rosterProfile.roll&&d.roll&&String(d.roll).replace(/\D/g,'')!==String(rosterProfile.roll).replace(/\D/g,''))return toast('ERP is signed in as another student. Switch to the correct account.');
if(rosterProfile)return toast('Excel profile retained. SIM authentication can be used for results.');
const p=state.profile||{};for(const k of ['name','father','roll','program','semester','college','session','admission']){if(typeof d[k]==='string'&&d[k].trim())p[k]=d[k].trim().slice(0,100);}state.profile=p;persist();if('dobReady' in d){resultState.dobReady=!!d.dobReady;persistResults();}render();toast('Student details refreshed from SIM');}catch(e){toast('Could not read the student profile');}};
window.onOfficialSection=obj=>{if(isReadOnly())return;
 const section=String(obj?.section||'').trim();if(!section)return;
 state.profile.section=section.slice(0,90);persist();if(page==='profile')render();
 toast('Section :- '+section);
};
window.onCollectionProgress=obj=>{
 collection={active:!!obj.active,stage:String(obj.stage||''),message:String(obj.message||'')};
 const bar=document.getElementById('syncBanner');
 if(bar){bar.classList.toggle('hidden',!collection.active);document.getElementById('syncMessage').textContent=collection.message;}
 if(obj.done){
  if(obj.stage==='complete'){
    state.workspaceReady=true;onboardingError='';
    state.aktuNotice=/AKTU.*(unavailable|did not load|skipped)/i.test(collection.message)?collection.message:'';
    persist();page='home';if(pendingStarRefresh){const id=pendingStarRefresh;pendingStarRefresh='';captureStarSnapshot(id);}
  }
  else if(obj.stage==='cancelled'){onboardingError='Connection stopped. Previously saved records remain available.';persist();pendingStarRefresh='';}
  toast(collection.message);
 }
 renderRosterGate();
 if(page==='home')render();
};
window.cancelFullCollection=()=>{native('cancelFullCollection');native('stopAutoSync');};
window.startFullCollection=()=>{if(isReadOnly())return toast('Read-only view.');
 if(!rosterProfile)return toast('Select a student first.');
 const date=E.parseDate(document.getElementById('oneTapStart')?.value||state.start);
 if(!date||date>now()){onboardingError='Select a valid semester start date.';renderRosterGate();return;}
 const pw=document.getElementById('oneTapSimPassword');
 const password=(pw?.value||'').slice(0,100);
 if(pw)pw.value='';
 state.start=date;state.setup=true;state.aktuNotice='';persist();
 if(native('startFullCollection',date,password)){
   collection={active:true,stage:'attendance',message:'Connecting to the official portal…'};onboardingError='';
   render();
 }else toast('One-tap collection requires the updated Android app.');
};
window.onExamScanProgress=obj=>{if(Array.isArray(obj.semesters))simScanReport=obj.semesters;const bar=document.getElementById('syncBanner');bar.classList.toggle('hidden',!!obj.done);document.getElementById('syncMessage').textContent=obj.message||'Reading available exams';if(obj.done){render();toast(obj.message||'Exam scan complete');}};
render();
if(!window.Native)hideSplash();
})();
