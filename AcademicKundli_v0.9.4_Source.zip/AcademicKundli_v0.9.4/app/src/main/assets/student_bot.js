/* Runs only on official SIM student pages; extracts identity fields, not login data.
   DOB is separately encrypted by the Android layer; not passed to the app UI. */
(function(){'use strict';
const text=x=>String(x==null?'':x).replace(/\s+/g,' ').trim().slice(0,170);
const wanted={name:/^(student\s*)?name$/i,roll:/^(university\s*)?roll\s*(no\.?|number)?$/i,program:/^(program|course|branch)$/i,semester:/^(semester|sem)$/i,college:/^(college|institute|institution)$/i,session:/^(session|academic\s*session)$/i,admission:/^admission\s*(no\.?|number)?$/i,dob:/^(d\.?o\.?b\.?|date\s*of\s*birth|birth\s*date)$/i};
const output={};const candidate=(v,k)=>{v=text(v);if(!v||v.length>120||v.toLowerCase()==k||/choose|select|password|captcha/i.test(v))return;
if(k==='roll'&&!/\d{8,16}/.test(v))return;
if(k==='dob'&&!/\b\d{1,2}[\-/.]\d{1,2}[\-/.]\d{4}\b|\b\d{4}[\-/.]\d{1,2}[\-/.]\d{1,2}\b/.test(v))return;
if(!output[k])output[k]=v;};
function identify(label,v){label=text(label).replace(/[:：]\s*$/,'');for(const [key,re] of Object.entries(wanted))if(re.test(label))candidate(v,key);}
for(const tr of [...document.querySelectorAll('tr')].slice(0,250)){
const cells=[...tr.querySelectorAll('td,th')];for(let i=0;i<cells.length-1;i++){
 let next=cells[i+1];let val=next.querySelector('input,textarea,select');identify(cells[i].textContent,val?(val.value||val.selectedOptions?.[0]?.textContent||''):next.textContent);
}}
for(const input of [...document.querySelectorAll('input:not([type=password]):not([type=hidden]),select')].slice(0,160)){
const parent=input.closest('td,div,section')||input.parentElement;const label=document.querySelector(`label[for="${CSS.escape(input.id||'________')}"]`);let txt=label?.textContent||'';
if(!txt&&parent){const probe=parent.previousElementSibling?.textContent||parent.querySelector('label')?.textContent||'';txt=text(probe);}
identify(txt,input.value||input.selectedOptions?.[0]?.textContent||'');
}
// Search a few one-line profile fields where the website uses text-only labels.
const body=text((document.body.innerText||'').slice(0,8000));
for(const [key,re] of Object.entries({roll:/\broll\s*no\.?\s*[:：]\s*(\d{8,16})/i,dob:/\b(?:date\s*of\s*birth|d\.o\.b)\s*[:：]\s*(\d{2}[/-]\d{2}[/-]\d{4})/i})) {const m=body.match(re);if(m)candidate(m[1],key);}
return JSON.stringify(output);
})()
