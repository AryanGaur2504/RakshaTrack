const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
const script=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/sim_fill.js'),'utf8');
function check(domain='glbg.servergi.com',existing=false,dob='01122003'){
 const fields=[
   {id:'txtAdmissionNo',name:'txtAdmissionNo',type:'text',value:existing?'MANUAL':'',label:'Admission No'},
   {id:'txtPassword',name:'txtPassword',type:'password',value:'',label:'Password'},
   {id:'txtCaptcha',name:'txtCaptcha',type:'text',value:'',label:'Captcha'}
 ].map(o=>({...o,offsetWidth:100,disabled:false,readOnly:false,getClientRects(){return [{}]},
   getAttribute(){return null},closest(){return null},dispatchEvent(){},parentElement:null,labels:[]}));
 const document={querySelectorAll(q){if(q==='input')return fields;return []},querySelector(){return null}};
 const location={protocol:'https:',hostname:domain,port:'8072',pathname:'/ISIMGLB/Login'};
 const sandbox={document,location,Date,HTMLInputElement:function(){},Event:class{constructor(type){this.type=type}},CSS:{escape:x=>x}};
 sandbox.HTMLInputElement.prototype={};
 const raw=vm.runInNewContext(script.replace("'__ADMISSION__'",JSON.stringify('STUDENT001')).replace("'__DOB__'",JSON.stringify(dob)).replace("'__PASSWORD__'",JSON.stringify('')),sandbox);
 return {out:JSON.parse(raw),fields};
}
let t=check();assert.equal(t.out.stage,'login');assert.equal(t.fields[0].value,'STUDENT001');assert.equal(t.fields[1].value,'01122003');assert.equal(t.fields[2].value,'');
t=check('untrusted.example');assert.equal(t.out.stage,'unavailable');assert.equal(t.fields[0].value,'');
t=check('glbg.servergi.com',true);assert.equal(t.fields[0].value,'MANUAL','Must not overwrite user input');
t=check('glbg.servergi.com',false,'31022003');assert.equal(t.out.dobAvailable,false);assert.equal(t.fields[1].value,'');
console.log('SIM admission/DOB (DDMMYYYY) autofill tests passed');
