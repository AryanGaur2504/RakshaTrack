const assert=require('node:assert/strict');
const E=require('../app/src/main/assets/engine.js');
assert.equal(E.rangeParts('2026-08-01','2026-10-29').length,3);
assert.deepEqual(E.rangeParts('2026-01-01','2026-01-31').map(p=>[p.from,p.to]),[['2026-01-01','2026-01-30'],['2026-01-31','2026-01-31']]);
assert.deepEqual(E.rangeParts('2024-02-28','2024-03-02').map(x=>x.from),['2024-02-28']);
assert.deepEqual(E.predict(75,100,75),{present:75,total:100,target:75,pct:75,bunk:0,need:0,atTarget:true});
assert.equal(E.predict(90,100,75).bunk,20);
assert.equal(E.predict(60,100,75).need,60);
assert.equal(E.predict(60,100,100).need,null);
assert.equal(E.predict(0,0,75).need,0);
assert.equal(E.predict(101,100,75),null);
assert.equal(E.parseDate('02/11/2026'),'2026-11-02');
const s=E.parseSnapshot({title:'Attendance',tables:[[['Subject','Total Lectures','Attended'],['Data Structures','40','35'],['Java','30','24'],['Total','70','59']],[['Date','Subject','Status'],['01/11/2026','Java','P'],['02/11/2026','Java','A']]]});
assert.equal(s.subjects.length,2);assert.equal(s.records.length,2);assert.equal(s.records[0].status,'P');
console.log('SIM+ engine tests passed');
const todays=E.parseSnapshot({url:'/ISIMGLB/Student/TodayAttendence',pageDate:'2026-11-02',tables:[[['Subject','Lecture 1','Lecture 2'],['Database Management','P','A'],['Artificial Intelligence','P','P']]]});
assert.equal(todays.records.length,4);
assert.equal(todays.records.filter(x=>x.status==='P').length,3);
assert.equal(todays.records[0].date,'2026-11-02');

// Structure transcribed from the student's SIM screenshots (test fixtures,
// never shipped as app data). Date-wise: Date, Subject Name, Time Slot, Status.
const realShape = {
 url:'/ISIMGLB/Student/TodayAttendence',pageDate:'2026-11-02',
 tables:[[
 ['SNo.','Session','Program','Semester','Date','Subject Name','Time Slot','Attendance Type','Status'],
 ['1','2025','B.TECH(CSAIML)','Sem III','05/10/2026','Data Structure (BCS-301)','(P2) 10:01 AM-10:50 AM','Lecture','A'],
 ['2','2025','B.TECH(CSAIML)','Sem III','05/10/2026','Web Designing Workshop (BCS-353)','(P3) 10:51 AM-11:40 AM','Practical','P'],
 ['3','2025','B.TECH(CSAIML)','Sem III','05/10/2026','Web Designing Workshop (BCS-353)','(P4) 11:41 AM-12:30 PM','Practical','NM'],
 ['4','2025','B.TECH(CSAIML)','Sem III','06/10/2026','Data Structure (BCS-301)','(P1) 09:10 AM-10:00 AM','Lecture','P']
 ]]};
const parsed = E.parseSnapshot(realShape);
assert.equal(parsed.records.length,4);
assert.equal(parsed.records[0].date,'2026-10-05');
assert.equal(parsed.records[0].slot,'P2');
assert.equal(parsed.records[2].status,'NM');
assert.deepEqual(E.fromRecords(parsed.records).map(x=>[x.name,x.present,x.total]),[
 ['Data Structure (BCS-301)',1,2],['Web Designing Workshop (BCS-353)',1,1]]);
const pctOnly=E.parseSnapshot({tables:[[
 ['SNo.','Session','Program','Semester','Subject','Status'],
 ['1','2025','B.TECH','Sem III','Data Structure (BCS-301)','86.96'],
 ['2','2025','B.TECH','Sem III','Total','92.08']
 ]]});
assert.equal(pctOnly.records.length,0);
assert.equal(pctOnly.subjects.length,0); // no invented present/total counts
assert.equal(pctOnly.percentages[0].pct,86.96);
assert.equal(pctOnly.semesterPct,92.08);
const todayNM=E.parseSnapshot({url:'/ISIMGLB/Student/TodayAttendence',pageDate:'2026-11-02',tables:[[
 ['SNo.','Session','Program','Semester','Subject Name','Time Slot','Attendance Type','Status'],
 ['1','2025','B.Tech','Sem III','Data Structure (BCS-301)','09:10 AM-10:00 AM','L','NM']
 ]]});
assert.equal(todayNM.records[0].status,'NM');
assert.equal(E.fromRecords(todayNM.records).length,0);
console.log('Real ERP table-shape, NM, and percentage-only tests passed');
