const assert=require('node:assert/strict');
const X=require('../app/src/main/assets/exam_engine');
const college={title:'EXAM RESULT',url:'/ISIMGLB/Student/ExamResult',headings:['Exam Result','Semester III - Sessional 1'],selections:[{label:'Semester',valueText:'Sem III'},{label:'Exam',valueText:'Sessional I'}],tables:[[['SNo','Subject Code','Subject Name','Internal Marks','External Marks','Grade','Result'],['1','BCS-301','Data Structure','23','60','A','PASS'],['2','BCS-302','Computer Organization','24','58','B+','PASS']]]};
const c=X.parseSnapshot(college,'college');assert.equal(c.results.length,1);assert.equal(c.results[0].subjects.length,2);assert.equal(c.results[0].semester,'Sem III');assert.equal(c.results[0].subjects[0].marks,'23 + 60');
const aktu={title:'One View',headings:['Semester II','Result Status: PASS','SGPA: 8.32','CGPA: 8.12'],tables:[[['Subject Code','Subject Name','Credits','Grade'],['BAS201','Mathematics II','4','A'],['BAS202','Physics','4','B+']]]};
const a=X.parseSnapshot(aktu,'aktu');assert.equal(a.results.length,1);assert.equal(a.results[0].subjects[1].grade,'B+');assert.equal(a.results[0].sgpa,'8.32');
assert.equal(X.parseSnapshot({title:'Login',tables:[]},'college').results.length,0);
assert.equal(X.parseSnapshot({tables:[[ ['Hello'],['Please wait'] ]]},'aktu').results.length,0);
const summary={tables:[[ ['Semester','SGPA','CGPA','Result'],['Sem 1','8.15','8.15','PASS'],['Sem 2','8.43','8.29','PASS'] ]]};assert.equal(X.parseSnapshot(summary,'aktu').results.length,2);
console.log('SIM+ academic result parser tests passed');

// Reproduces the live SIM ExamResult table structure supplied by the student.
// Tests MUST NOT be used to populate app data.
const liveShape={title:'EXAM RESULT',scanContext:{semester:'Sem I',exam:'All displayed assessments'},tables:[
 [['Name','Candidate Example','Father Name','Parent Example','Branch','B.TECH'],['AdmissionNo','A-100','Roll No','0000000000']],
 [['SNo.','Subject Name','Exam Type','Min Marks','Max Marks','Marks Obtain','Marks Type','Exam Month'],
 ['1','Engineering Chemistry (BAS102)','Sessional 1','20','70','66','Regular Paper','Oct 2025'],
 ['2','Engineering Chemistry (BAS102)','Sessional 2','20','70','64','Regular Paper','Nov 2025'],
 ['3','Engineering Mathematics-I (BAS103)','Sessional 1','20','70','0','Regular Paper','Oct 2025']]]};
const r=X.parseSnapshot(liveShape,'college');
assert.equal(r.results.length,1);
assert.equal(r.results[0].semester,'Sem I');
assert.equal(r.results[0].subjects.length,3);
assert.equal(r.results[0].subjects[0].code,'BAS102');
assert.equal(r.results[0].subjects[0].examType,'Sessional 1');
assert.equal(r.results[0].subjects[1].examType,'Sessional 2');
assert.equal(r.results[0].subjects[1].examMonth,'Nov 2025');
assert.equal(r.results[0].subjects[0].minMarks,'20');
assert.equal(r.results[0].subjects[0].maxMarks,'70');
assert.equal(r.results[0].subjects[2].marks,'0');
assert.equal(r.results[0].subjects[0].marksType,'Regular Paper');
const sem2=X.parseSnapshot({...liveShape,scanContext:{semester:'Sem II',exam:'All displayed assessments'}},'college');
assert.notEqual(r.results[0].id,sem2.results[0].id,'Different semesters must never share the same saved result ID');
const filt=X.parseSnapshot({...liveShape,scanContext:{semester:'Sem I',exam:'Sessional 1'}},'college');
assert.notEqual(r.results[0].id,filt.results[0].id,'Different examination filters must not overwrite each other');
