const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const native=fs.readFileSync(path.join(__dirname,'../app/src/main/java/com/campus/simplus/AcademicFeatures.java'),'utf8');
const ui=fs.readFileSync(path.join(__dirname,'../app/src/main/assets/app.js'),'utf8');
assert.match(native,/scanRequestSerial/);assert.match(native,/ASP\.NET postbacks can destroy the JS context/);
assert.match(native,/"true"\.equals\(ack\)/);assert.match(native,/scanOutcome/);
assert.match(native,/scanStage="confirm-semester"/);
assert.match(ui,/if\(!parsed\.results\.length\)\{if\(identityChanged\)render\(\);return false;/);
assert.match(ui,/`Imported \$\{parsed\.results\.length\} official result record\(s\)`\);return true/);
console.log('SIM full-reload recovery and parse acknowledgment assertions passed');
