/* SIM regression: selecting a semester then pressing Show must never touch Exam Name. */
const assert=require('node:assert/strict'), vm=require('node:vm'),fs=require('node:fs');
const source=fs.readFileSync(require('node:path').join(__dirname,'../app/src/main/assets/result_scan.js'),'utf8');
function option(value,textContent){return {value,textContent};}
function field(id,label,options){return {id,name:id,options,value:'',disabled:false,offsetWidth:100,offsetHeight:25,getClientRects(){return [{}];},closest(){return {previousElementSibling:{textContent:label},textContent:label};},parentElement:{textContent:label},dispatchEvent(evt){if(this.id==='semester'&&evt.type==='change'){exam.options=[option('','--Select--'),option('E1','Sessional 1'),option('E2','Sessional 2')];}}};}
const sem=field('semester','Semester',[option('','--Select--'),option('S1','Sem I'),option('S2','Sem II')]);
const exam=field('exam','Exam Name',[option('','--Select--')]);
const button={value:'Show',offsetWidth:100,getClientRects(){return [{}];},click(){this.clicked=true;}};
const document={getElementById(id){return id==='MCPH1_SCPH_ddldrp'?sem:id==='MCPH1_SCPH_ddlExamName'?exam:id==='MCPH1_SCPH_btnRun'?button:null;},querySelector(){return null;},querySelectorAll(selector){if(selector==='select')return [sem,exam];if(selector==='table')return [];if(selector.includes('button'))return [button];return [];}};
const sandbox={document,Event:class{constructor(type){this.type=type;}}};
function run(action,args={}){const script=source.replace("'__ACTION__'",JSON.stringify(action)).replace('__ARGS__',JSON.stringify(args));return JSON.parse(vm.runInNewContext(script,sandbox));}
const initial=run('semesters');assert.deepEqual(initial.semester.options.map(x=>x.text),['Sem I','Sem II']);assert.equal(initial.exam.options.length,0,'Exam options are initially empty');
assert.equal(run('choose-semester',{field:initial.semester,value:'S1'}).state,'selected');
const selected=run('inspect');assert.equal(selected.semester.value,'S1');assert.equal(selected.exam.options.length,2,'Selecting semester reveals exam options');
assert.equal(run('show').state,'show-clicked');assert.equal(button.clicked,true);assert.equal(run('inspect').exam.value,'','Exam Name must remain untouched');
console.log('Semester-first SIM dropdown scanner tests passed');
